#!/bin/bash
# Descompactando o arquivo com as dependências
unzip files.zip
mv files/* .
# Realizando o build do commons
mvn install:install-file -Dfile=secret-manager-credentials-2.0.0-shaded.jar -DgroupId=br.com.natura.commercial.performance.commons -DartifactId=secret-manager-credentials -Dversion=2.0.0 -Dpackaging=jar -DgeneratePom=true
echo mvn install:install-file -Dfile=secret-manager-credentials-2.0.0-shaded.jar -DgroupId=br.com.natura.commercial.performance.commons -DartifactId=secret-manager-credentials -Dversion=2.0.0 -Dpackaging=jar -DgeneratePom=true
# Realizando o Build
mvn -f pom.xml clean install -Dmaven.test.skip=truen.test.skip=true