package br.com.natura.handlers.spark

import br.com.natura.settings.Settings
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.{Duration, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

object Spark {
  System.setProperty("hadoop.home.dir", Settings.winUtils)

  private def createSparkConf(serverAddress: String, username: String, password: String, inputConsistency: String, outputConsistency: String): SparkConf = {
    new SparkConf()
      .set("spark.cassandra.connection.host", serverAddress)
      .set("spark.cassandra.auth.username", username)
      .set("spark.cassandra.auth.password", password)
      .set("spark.cassandra.connection.port", "9042")
      .set("spark.cassandra.input.consistency.level", inputConsistency)
      .set("spark.cassandra.output.consistency.level", outputConsistency)
  }

  private val sparkConf: SparkConf = createSparkConf(
    Settings.scyllaServerAddress,
    Settings.scyllaUser,
    Settings.scyllaPass,
    Settings.scyllaInputConsistency,
    Settings.scyllaOutputConsistency
  )

  val sparkSession: SparkSession = SparkSession
    .builder()
    .config(sparkConf)
    .appName(Settings.appName)
    .getOrCreate()

  def getSparkSession: SparkSession = sparkSession

  def getSparkContext: SparkContext = getSparkSession.sparkContext

  def getStreamingContext(streamingApp: (SparkContext, Duration) => StreamingContext, batchDuration: Duration): StreamingContext = {
    val sc: SparkContext = getSparkContext
    val creatingFunc: () => StreamingContext = () => streamingApp(sc, batchDuration)
    StreamingContext.getActiveOrCreate(creatingFunc)
  }

}
