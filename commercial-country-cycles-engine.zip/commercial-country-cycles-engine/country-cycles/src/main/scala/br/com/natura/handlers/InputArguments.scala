package br.com.natura.handlers

import java.util.UUID

// recebe os argumentos do submit para processamento do processo

class InputArguments(args: Array[String]) {

  def getCountry: Int = {
    val country = args.find(_.startsWith("--country="))
    country match {
      case Some(value) => value.split("=")(1).toInt
      case None => throw new IllegalArgumentException("Country not found")
    }
  }

  def getUUID: UUID = {
    val uuid = args.find(_.startsWith("--uuid="))
    uuid match {
      case Some(value) => UUID.fromString(value.split("=")(1))
      case None => throw new IllegalArgumentException("UUID not found")
    }
  }

}
