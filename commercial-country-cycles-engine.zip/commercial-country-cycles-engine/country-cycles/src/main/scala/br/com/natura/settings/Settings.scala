package br.com.natura.settings

import br.com.natura.commercial.performance.commons.config.ImplicitsImport._
import br.com.natura.commercial.performance.commons.config.Credentials
import br.com.natura.commercial.performance.commons.db.{ScyllaDB}

import com.typesafe.config.ConfigFactory

object Settings {

  private val config = ConfigFactory.load()

  private val weblogGen = config.getConfig("country-cycles")
  private val hadoopSettings = config.getConfig("hadoop_settings")
  private val kafkaSettings = config.getConfig("kafka_settings")
  private val configs = config.getConfig("configs")
  private val scyllaSettings = config.getConfig("scylla_conn")
  private val environmentSettings = config.getConfig("environment")

  //////SECRET MANAGER ////////////////
  private val region =
    environmentSettings.getString("region")
  private val scyllaSecretName =
    environmentSettings.getString("scylla_secret_name")

  private val scylla_performance_credentials =
    Credentials.loadCredentials[ScyllaDB](
      scyllaSecretName,
      region
    )

  lazy val scyllaServerAddress: String = scylla_performance_credentials.host
  lazy val scyllaUser: String = scylla_performance_credentials.username
  lazy val scyllaPass: String = scylla_performance_credentials.password
  lazy val scyllaInputConsistency: String = scyllaSettings.getString("input_consistency")
  lazy val scyllaOutputConsistency: String = scyllaSettings.getString("output_consistency")

  lazy val offsetTable: String = configs.getString("offsetTable")
  lazy val processTable: String = configs.getString("processTable")

  lazy val appName: String = weblogGen.getString("appName")
  lazy val engineId: Int = weblogGen.getInt("engineId")

  lazy val logLevel: String = weblogGen.getString("logLevel")

  lazy val winUtils: String = hadoopSettings.getString("winUtils")

  lazy val kafka_topic_read: String = kafkaSettings.getString("kafka_topic_read")
  lazy val kafka_topic_failed: String = kafkaSettings.getString("kafka_topic_failed")
  lazy val kafkaCommit: String = kafkaSettings.getString("kafkaCommit")
  lazy val kafka_bootstrap_servers: String = kafkaSettings.getString("kafka_bootstrap_servers")
  lazy val kafka_microbatch_duration: Int = weblogGen.getInt("microbatch_duration")
  lazy val offset_reset: String = kafkaSettings.getString("offset_reset")

}
