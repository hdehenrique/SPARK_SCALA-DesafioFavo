package br.com.natura.app

import br.com.natura.domain.CountryCyclesEntity
import br.com.natura.handlers.InputArguments
import br.com.natura.handlers.spark.Spark
import br.com.natura.settings.Settings
import com.datastax.spark.connector.{SomeColumns, toRDDFunctions}
import org.apache.spark.sql.{Encoders, functions}
import org.apache.spark.sql.functions.{count, current_date, current_timestamp, from_json, lit}


object BatchApp extends App {

  // Schema for the country cycles
  private val countryCycleSchema = Encoders.product[CountryCyclesEntity].schema

  // Initializing the Spark Context and Spark Session
  val sc = Spark.getSparkContext
  val ss = Spark.getSparkSession
  private val inputArguments = new InputArguments(args)

  // Reading the country codes from the country_codes table
  private val contriesISO = ss.read.format("org.apache.spark.sql.cassandra")
    .options(Map("table" -> "country_codes", "keyspace" -> "performance"))
    .load()
    .select("country", "country_iso")

  // Extracting the country and process UUID from the input arguments
  private val country = inputArguments.getCountry
  private val processUUID = inputArguments.getUUID

  // Reading the offset from the control table
  private val offsetToProcess = ss.read.format("org.apache.spark.sql.cassandra")
    .options(Map("table" -> "country_cycles_offset_control", "keyspace" -> "performance"))
    .load()
    .where(s"country = '$country'")
    .select("partition", "offset")
    .collect()

  // Creating the offset string to be used in the Kafka read
  private val offsetString = if (offsetToProcess.isEmpty) Settings.offset_reset else {
    val offsets = offsetToProcess.map(row => s""""${row.getAs[Int]("partition")}":${row.getAs[Long]("offset")}""").mkString(",")
    s"""{"${Settings.kafka_topic_read}":{$offsets}}"""
  }

  // Reading the data from Kafka
  private val dataToProcess = ss.read.format("kafka")
    .option("kafka.bootstrap.servers", Settings.kafka_bootstrap_servers)
    .option("subscribe", Settings.kafka_topic_read)
    .option("startingOffsets", offsetString)
    .option("endingOffsets", "latest")
    .load()
    .cache()

  // Save the offset to the control table
  dataToProcess.groupBy("partition").agg(functions.max("offset").as("offset"))
    .withColumn("country", functions.lit(country))
    .withColumn("last_updated", current_timestamp())
    .write.format("org.apache.spark.sql.cassandra")
    .options(Map("table" -> "country_cycles_offset_control", "keyspace" -> "performance"))
    .mode("append")
    .save()

  // Parse json data to CountryCycle case class
  private val parsedData = dataToProcess
    .where(s"key = '$processUUID'")
    .selectExpr("CAST(value AS STRING)")
    .select(from_json(functions.col("value"), countryCycleSchema).as("data"))
    .select("data.*")
    .withColumnRenamed("country", "country_iso")
    .distinct()
    .cache()

  // Group data by country, company_id, business_model, operational_cycle and OperationID
  private val groupedData = parsedData.groupBy("country_iso", "company_id", "business_model", "operational_cycle")
    .agg(count("OperationID").as("operations_count"))
    .join(contriesISO, parsedData("country_iso") === contriesISO("country_iso"))
    .selectExpr("country", "company_id", "business_model", "operational_cycle", "operations_count")

  // Split data in two dataframes, one for insert and other for delete
  private val insert = groupedData.where("operations_count > 1")
  private val delete = groupedData.where("operations_count < 2")

  // Write data with operations_count bigger than 1 to the process table
  insert
    .drop("operations_count")
    .write.format("org.apache.spark.sql.cassandra")
    .options(Map("table" -> "commercial_country_cycles", "keyspace" -> "performance"))
    .mode("append")
    .save()

  // Delete data with operations_count smaller than 2 from the process table
  if (delete.count() > 0)
    delete
      .drop("operations_count")
      .rdd.map(row => (row.getAs[Int]("country"), row.getAs[Int]("company_id"), row.getAs[Int]("business_model"), row.getAs[Int]("operational_cycle")))
      .deleteFromCassandra("performance", "commercial_country_cycles")


}
