package br.com.natura.domain

case class CountryCyclesEntity(
                                country: String,
                                company_id: Int,
                                business_model: Int,
                                operational_cycle: Int,
                                OperationID: String
                              )
