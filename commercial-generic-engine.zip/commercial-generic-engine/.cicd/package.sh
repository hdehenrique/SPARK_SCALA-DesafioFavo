#!/usr/bin/env bash
set -ex

if [ -d function ]; then
  rm -rf function
fi

TMPDIR="./tmp"
mkdir -p ${TMPDIR}

grep -E 'Ubuntu|Debian' /etc/issue >/dev/null && export SYSTEM=true

if [ "$SYSTEM" == "true" ]; then
  pip3 install --platform manylinux2014_aarch64 -r requirements.txt --implementation cp --python-version 3.9 --only-binary=:all: --upgrade  -t ${TMPDIR}
else
  pip3 install --platform manylinux2014_aarch64 -r requirements.txt --implementation cp --python-version 3.9 --only-binary=:all: --upgrade  -t ${TMPDIR}
fi

cp -v app.py ${TMPDIR}
cp -R src ${TMPDIR}
origin_dir=$(pwd)
cd ${TMPDIR}

if [ -e "${origin_dir}"/function.zip ]; then
  rm -f "${origin_dir}"/function.zip
fi

zip "${origin_dir}"/function.zip * -r

cd "${origin_dir}"
rm -rf ${TMPDIR}