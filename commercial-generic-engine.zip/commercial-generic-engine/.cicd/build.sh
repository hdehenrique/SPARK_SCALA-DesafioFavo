echo "gerando pacote para deploy"

set -e



if [ -e function.zip ]; then

rm function.zip

rm -rf function

fi



echo "copiando arquivos"



mkdir function

find . -name \*.pyc -delete

cp -R src function/src

cp -R utils function/utils



cp constants.py function/

cp requirements.txt function/

cp app.py function/

echo "instalando pacotes..."



pip3 install -U -r requirements.txt --target=function




cd function && zip -r ../function.zip * .[^.]*