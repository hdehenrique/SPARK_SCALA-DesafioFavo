#!/bin/bash
# Discover and run all tests in the test directory
cd function || exit
python -m coverage run --rcfile=.coveragerc -m pytest -v --junit-xml=../reports/coverage/lcov-report/report.xml tests
python -m coverage html -d ../reports/coverage/lcov-report
python -m coverage lcov -o ../reports/coverage/lcov-report/coverage.lcov
python -m coverage xml -o ../reports/coverage/lcov-report/coverage.xml