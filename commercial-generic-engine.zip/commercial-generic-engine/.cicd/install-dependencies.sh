echo "copiando arquivos"

mkdir function

find . -name \*.pyc -delete

cp constants.py function/

cp requirements.txt function/

cp .coveragerc function/

cp app.py function/

cp -r src function/

cp -r tests function/

echo "instalando pacotes..."

pip3 install -U -r requirements.txt --target=function