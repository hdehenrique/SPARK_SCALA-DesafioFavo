import logging
from os import getenv
from typing import Dict, Optional

from src.commercial_generic_lambda.infrastructure.producers.services.producer import ProducerService
from src.commercial_generic_lambda.application.services.generic_lambda import GenericLambdaService
from src.commercial_generic_lambda.infrastructure.connections.services.connection import ConnectionService
from src.commercial_generic_lambda.infrastructure.events.services.event_provider import EventProvideService

logger = logging.getLogger()
logger.setLevel(logging.WARNING)

connections: Dict[str, ConnectionService] = {}
producerService: Optional[ProducerService] = None
bootstrap = getenv("failed_topic_bootstrap")


def handler(event, context):
    global connections
    global producerService

    if not producerService:
        producerService = ProducerService(bootstrap, logger)

    if producerService.check_idle_time():
        logger.warning(f"Reconnecting to {bootstrap} - {producerService.time_info()}")
        producerService.reconnect()

    producerService.set_last_used_time()

    producer = producerService.producer

    provider: EventProvideService = EventProvideService(event, logger, producer)

    parse_event = provider.parse_event()

    if provider.topic_name not in connections:
        try:
            connections[provider.topic_name] = ConnectionService(provider.topic_name, logger)
        except ValueError as e:
            logger.error(f"Error to create connection: {e}")
            parse_event.send_to_failed_topic(str(event), e)
            return
        except Exception as e:
            logger.error(f"Error to create connection: {e}")
            raise e

    if connections[provider.topic_name].check_idle_time():
        logger.warning(f"Reconnecting to {provider.topic_name} - {connections[provider.topic_name].time_info()}")
        try:
            connections[provider.topic_name].reconnect()
        except Exception as e:
            logger.error(f"Error to reconnect: {e}")
            parse_event.send_to_failed_topic(str(event), e)
            return

    connections[provider.topic_name].set_last_used_time()

    if connections[provider.topic_name].get_session().cluster.is_shard_aware():
        logger.warning(
            "Cluster is connected with shard aware")

    connection = connections[provider.topic_name]

    generic_service = GenericLambdaService(logger, parse_event, connection.get_session(), connection.get_tables())

    generic_service.handler()
