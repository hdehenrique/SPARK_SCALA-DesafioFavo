from logging import Logger

import pytest
from unittest.mock import Mock, call

from apollo_orm.orm.core import ORMInstance

from src.commercial_generic_lambda.application.services.generic_lambda import GenericLambdaService
from src.commercial_generic_lambda.infrastructure.events.interfaces.ievent import IEvent


@pytest.fixture
def mock_logger():
    return Mock(spec=Logger)


@pytest.fixture
def mock_event():
    return Mock(spec=IEvent)


@pytest.fixture
def mock_session():
    return Mock(spec=ORMInstance)


@pytest.fixture
def generic_lambda_service(mock_logger, mock_event, mock_session):
    return GenericLambdaService(mock_logger, mock_event, mock_session, ['table1', 'table2'])


def test_handler_calls_loop_through_event(generic_lambda_service):
    generic_lambda_service.handler()
    generic_lambda_service._loop_through_event.assert_called_once()


def test_loop_through_event_executes_query_for_each_message_in_each_table(generic_lambda_service, mock_event):
    mock_event.get_messages.return_value = ['message1', 'message2']
    generic_lambda_service._loop_through_event()
    assert generic_lambda_service._execute_query.call_args_list == [call('message1', 'table1'),
                                                                    call('message2', 'table1'),
                                                                    call('message1', 'table2'),
                                                                    call('message2', 'table2')]


def test_execute_query_inserts_message_and_waits_for_finish(generic_lambda_service, mock_session):
    generic_lambda_service._execute_query('message', 'table')
    mock_session.insert.assert_called_once_with('message', 'table', True)
    generic_lambda_service._wait_for_finish.assert_called_once()


def test_wait_for_finish_sleeps_until_process_finishes(generic_lambda_service):
    generic_lambda_service._in_process = [1]
    generic_lambda_service._wait_for_finish(1)
    assert generic_lambda_service._wait_for_finish.call_count == 1


def test_success_removes_process_and_releases_semaphore(generic_lambda_service, mock_session):
    generic_lambda_service._success(None, 'message', 'table', 1)
    assert 1 not in generic_lambda_service._in_process
    mock_session.release_semaphore.assert_called_once()


def test_failed_removes_process_releases_semaphore_and_sends_to_failed_topic(generic_lambda_service, mock_session,
                                                                             mock_event):
    generic_lambda_service._failed('error', 'message', 'table', 1)
    assert 1 not in generic_lambda_service._in_process
    mock_session.release_semaphore.assert_called_once()
    mock_event.send_to_failed_topic.assert_called_once_with('message - Table: table', 'error')
