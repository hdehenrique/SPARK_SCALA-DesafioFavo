import pytest
from unittest.mock import Mock
from src.commercial_generic_lambda.infrastructure.configs.services.config import ConfigService
from apollo_orm.domains.models.entities.connection_config.entity import ConnectionConfig
from apollo_orm.domains.models.entities.credentials.entity import Credentials


@pytest.fixture
def setup_config_service():
    credentials = Mock(spec=Credentials)
    tables = "table1,table2,table3"
    config_service = ConfigService(credentials, tables)
    return config_service, credentials, tables


def test_config_service_generates_correct_config(setup_config_service):
    config_service, credentials, tables = setup_config_service
    actual_config = config_service.config_generate()
    expected_config = ConnectionConfig(credentials, tables.split(","))
    assert isinstance(actual_config, ConnectionConfig)
    assert expected_config == actual_config


def test_config_service_handles_error_empty_tables():
    credentials = Mock(spec=Credentials)
    with pytest.raises(ValueError):
        config_service = ConfigService(credentials, "")
        config_service.config_generate()
    with pytest.raises(ValueError):
        config_service = ConfigService(credentials, " ")
        config_service.config_generate()


def test_config_service_handles_single_table():
    credentials = Mock(spec=Credentials)
    config_service = ConfigService(credentials, "table1")
    expected_config = ConnectionConfig(credentials, ["table1"])
    actual_config = config_service.config_generate()
    assert expected_config == actual_config
