import pytest
from unittest.mock import Mock, patch
from src.commercial_generic_lambda.infrastructure.events.services.event_provider import EventProvideService, \
    EventSourceException


@pytest.fixture
def setup_data():
    logger = Mock()
    producer = Mock()
    event = {}
    return logger, producer, event


def test_event_provider_service_with_sqs_event(setup_data):
    logger, producer, event = setup_data
    event = {
        'Records': [
            {
                'eventSourceARN': 'arn:aws:sqs:us-east-1:123456789012:MyQueue'
            }
        ]
    }
    event_provider_service = EventProvideService(event, logger, producer)
    assert event_provider_service.type_event == 'sqs'
    assert event_provider_service.topic_name == 'MyQueue'


def test_event_provider_service_with_kafka_event(setup_data):
    logger, producer, event = setup_data
    event = {
        'records': {
            '0': [
                {
                    'topic': 'MyTopic'
                }
            ]
        },
        'eventSource': 'aws:kafka'
    }
    event_provider_service = EventProvideService(event, logger, producer)
    assert event_provider_service.type_event == 'kafka'
    assert event_provider_service.topic_name == 'MyTopic'


def test_event_provider_service_with_unknown_event_source(setup_data):
    logger, producer, event = setup_data
    event = {
        'Records': [
            {
                'eventSourceARN': 'arn:aws:unknown:us-east-1:123456789012:MyQueue'
            }
        ]
    }
    with pytest.raises(EventSourceException):
        EventProvideService(event, logger, producer)


def test_parse_event_with_sqs_event(setup_data):
    logger, producer, event = setup_data
    event = {
        'Records': [
            {
                'eventSourceARN': 'arn:aws:sqs:us-east-1:123456789012:MyQueue'
            }
        ]
    }
    event_provider_service = EventProvideService(event, logger, producer)
    with patch(
            'src.commercial_generic_lambda.infrastructure.events.services.event_provider.SQSService') as mock_sqs_service:
        event_provider_service.parse_event()
        mock_sqs_service.assert_called_once_with(event, logger)


def test_parse_event_with_kafka_event(setup_data):
    logger, producer, event = setup_data
    event = {
        'records': {
            '0': [
                {
                    'topic': 'MyTopic'
                }
            ]
        },
        'eventSource': 'aws:kafka'
    }
    event_provider_service = EventProvideService(event, logger, producer)
    with patch(
            'src.commercial_generic_lambda.infrastructure.events.services.event_provider.MSKService') as mock_msk_service:
        event_provider_service.parse_event()
        mock_msk_service.assert_called_once_with(event, logger, 'MyTopic', producer)
