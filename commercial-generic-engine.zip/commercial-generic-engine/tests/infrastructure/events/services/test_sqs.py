import json
import pytest
from unittest.mock import Mock
from src.commercial_generic_lambda.infrastructure.events.services.sqs import SQSService


@pytest.fixture
def sqs_service():
    event = {
        "Records": [
            {"body": json.dumps({"Message": json.dumps({"key": "value"})})}
        ]
    }
    logger = Mock()
    return SQSService(event, logger)


def test_retrieves_event_correctly(sqs_service):
    current = sqs_service.get_event()
    expected = {
        "Records": [
            {"body": json.dumps({"Message": json.dumps({"key": "value"})})}
        ]
    }

    assert current == expected


def test_get_messages(sqs_service):
    current = list(sqs_service.get_messages())
    expected = [{"key": "value"}]

    assert current == expected


def test_get_messages_with_invalid_message(sqs_service):
    sqs_service._event = {
        "Records": [
            {"body": json.dumps({"Message": "invalid_message"})}
        ]
    }

    with pytest.raises(Exception):
        list(sqs_service.get_messages())


def test_send_to_failed_topic(sqs_service):
    with pytest.raises(Exception):
        sqs_service.send_to_failed_topic("message", Exception("error"))
