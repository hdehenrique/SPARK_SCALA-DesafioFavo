import pytest
from unittest.mock import Mock, patch
from src.commercial_generic_lambda.infrastructure.events.services.msk import MSKService


def test_msk_service_initialization():
    event = {"records": {}}
    logger = Mock()
    topic_name = "test_topic"
    producer = Mock()

    msk_service = MSKService(event, logger, topic_name, producer)

    assert msk_service.get_event() == event


@patch('src.commercial_generic_lambda.infrastructure.events.services.msk.getenv')
def test_send_to_failed_topic(getenv_mock):
    getenv_mock.return_value = "failed_topic"
    event = {"records": {}}
    logger = Mock()
    topic_name = "test_topic"
    producer = Mock()
    message = "test_message"
    error = Exception("test_exception")

    msk_service = MSKService(event, logger, topic_name, producer)
    msk_service.send_to_failed_topic(message, error)

    producer.send.assert_called_once()
    producer.flush.assert_called_once()


def test_get_messages_with_no_records():
    event = {"records": {}}
    logger = Mock()
    topic_name = "test_topic"
    producer = Mock()

    msk_service = MSKService(event, logger, topic_name, producer)
    messages = list(msk_service.get_messages())

    assert messages == []


def test_get_messages_with_records():
    event = {"records": {"0": [{"value": "eyJ0ZXN0IjogInZhbHVlIn0="}]}}
    logger = Mock()
    topic_name = "test_topic"
    producer = Mock()

    msk_service = MSKService(event, logger, topic_name, producer)
    messages = list(msk_service.get_messages())

    assert messages == [{"test": "value"}]


def test_get_messages_with_invalid_records():
    # this test must be call send_to_failed_topic
    event = {"records": {"0": [{"value": "invalid"}]}}
    logger = Mock()
    topic_name = "test_topic"
    producer = Mock()

    msk_service = MSKService(event, logger, topic_name, producer)
    messages = list(msk_service.get_messages())

    assert messages == []
    producer.send.assert_called_once()
    producer.flush.assert_called_once()


def test_get_messages_with_exception():
    # this test must be call send_to_failed_topic
    event = {"records": {"0": [{"value": "eyJ0ZXN0IjogInZhbHVlIn0="}]}}
    logger = Mock()
    topic_name = "test_topic"
    producer = Mock()
    producer.send.side_effect = Exception("test_exception")

    msk_service = MSKService(event, logger, topic_name, producer)
    messages = list(msk_service.get_messages())

    assert messages == [{"test": "value"}]
    with pytest.raises(Exception):
        producer.flush.assert_called_once()


def test_send_to_failed_topic_raises_specific_exception():
    event = {"records": {}}
    logger = Mock()
    topic_name = "test_topic"
    producer = Mock()
    producer.send.side_effect = Exception("test_exception")

    msk_service = MSKService(event, logger, topic_name, producer)
    with pytest.raises(Exception) as exc_info:
        msk_service.send_to_failed_topic("test_message", Exception("test_exception"))
    assert str(exc_info.value) == "test_exception"


def test_get_messages_calls_send_to_failed_topic_on_malformed_event():
    event = {"records": 'malformed_records'}
    logger = Mock()
    topic_name = "test_topic"
    producer = Mock()

    msk_service = MSKService(event, logger, topic_name, producer)

    with patch.object(msk_service, 'send_to_failed_topic') as mock_method:
        list(msk_service.get_messages())

    mock_method.assert_called_once()
