from unittest.mock import Mock, patch
from src.commercial_generic_lambda.infrastructure.connections.services.connection import ConnectionService

@patch.object(ConnectionService, 'open_connection')
@patch('src.commercial_generic_lambda.infrastructure.connections.services.connection.ConfigService')
@patch('src.commercial_generic_lambda.infrastructure.connections.services.connection.CredentialsService')
@patch('src.commercial_generic_lambda.infrastructure.connections.services.connection.Logger')
@patch('src.commercial_generic_lambda.infrastructure.connections.services.connection.getenv')
def test_connection_service(mock_getenv, mock_logger, mock_credentials_service, mock_open_connection, mock_config_service):
    # Configuração dos mocks
    mock_getenv.return_value = 'test_value'
    mock_logger.return_value.info.return_value = None
    mock_credentials_service.return_value.get_credentials.return_value = 'test_credentials'
    mock_config_service.return_value.tables = ['table1', 'table2']
    mock_config = Mock()
    mock_config.credential.datacenter = 'test_datacenter'
    mock_config_service.return_value.config_generate.return_value = mock_config
    mock_open_connection.return_value = None

    # Inicialização do serviço de conexão
    connection_service = ConnectionService('test_topic', mock_logger.return_value)
    connection_service.open_connection()

    # Verifica se os métodos foram chamados corretamente
    mock_logger.return_value.info.assert_called()
    mock_credentials_service.return_value.get_credentials.assert_called()
    mock_config_service.return_value.config_generate.assert_called()

    # Verifica se os valores retornados são corretos
    assert connection_service.get_session() == mock_config_service.return_value.config_generate.return_value
    assert connection_service.get_tables() == ['table1', 'table2']