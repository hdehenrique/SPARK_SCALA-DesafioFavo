import json
import pytest
from unittest.mock import patch
from src.commercial_generic_lambda.infrastructure.credentials.services.credentials import CredentialsService


@pytest.fixture
def mock_aws_client():
    with patch('src.commercial_generic_lambda.infrastructure.credentials.services.credentials.aws_client') as mock:
        yield mock


def test_retrieves_credentials_from_aws_secrets_manager(mock_aws_client):
    # Given
    mock_aws_client.return_value.get_secret_value.return_value = {
        "SecretString": json.dumps({
            "host": "localhost1,localhost2,localhost3",
            "port": 5432,
            "username": "user",
            "password": "pass",
            "dbname": "db",
            "datacenter": "dc"
        })
    }
    credentials_service = CredentialsService("secret")

    # When
    credentials = credentials_service.get_credentials()

    # Then
    assert credentials.hosts == ["localhost1", "localhost2", "localhost3"]
    assert credentials.port == 5432
    assert credentials.user == "user"
    assert credentials.password == "pass"
    assert credentials.keyspace_name == "db"
    assert credentials.datacenter == "dc"


def test_handles_missing_fields_in_secret(mock_aws_client):
    # Given
    mock_aws_client.return_value.get_secret_value.return_value = {
        "SecretString": json.dumps({
            "host": "localhost1,localhost2,localhost3",
            "port": 5432,
            "username": "user",
            "password": "pass",
            "dbname": "db"
        })  # datacenter is missing
    }
    credentials_service = CredentialsService("secret")

    # When
    credentials = credentials_service.get_credentials()

    # Then
    assert credentials.datacenter is None


def test_raises_exception_when_secret_is_empty(mock_aws_client):
    # Given
    mock_aws_client.return_value.get_secret_value.return_value = {
        "SecretString": json.dumps({})
    }
    credentials_service = CredentialsService("secret")

    # When & Then
    with pytest.raises(Exception):
        credentials_service.get_credentials()


def test_raises_exception_when_secret_is_not_found(mock_aws_client):
    # Given
    mock_aws_client.return_value.get_secret_value.side_effect = Exception()
    credentials_service = CredentialsService("secret")
    # When & Then
    with pytest.raises(Exception):
        credentials_service.get_credentials()
