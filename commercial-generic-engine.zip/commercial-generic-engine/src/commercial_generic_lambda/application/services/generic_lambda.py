import uuid
from logging import Logger
from typing import List
import asyncio

from apollo_orm.orm.core import ORMInstance

from src.commercial_generic_lambda.infrastructure.events.interfaces.ievent import IEvent


class GenericLambdaService:

    def __init__(self, logger: Logger, event: IEvent, session: ORMInstance = None, tables: List[str] = None):
        logger.info("GenericLambdaService")
        self._logger = logger
        self._event = event
        self._in_process = []
        self.session: ORMInstance = session
        self._tables = tables

    def handler(self):
        asyncio.run(self._loop_through_event())

    async def _loop_through_event(self):
        tasks = [self._process_table(table) for table in self._tables]
        await asyncio.gather(*tasks)

    async def _process_table(self, table):
        tasks = [self._execute_query(message, table) for message in self._event.get_messages()]
        await asyncio.gather(*tasks)

    async def _execute_query(self, message, table):
        process_hash = hash((str(message), table, uuid.uuid4()))
        self._in_process.append(process_hash)
        self._logger.debug(
            f"ID Process: {process_hash} - Process List: {self._in_process} - Message: {message} - Table: {table}")
        try:
            message = {k: v for k, v in message.items() if v is not None}
            result = self.session.insert(message, table, True)
            result.add_callbacks(callback=self._success, callback_args=(message, table, process_hash),
                                 errback=self._failed,
                                 errback_args=(message, table, process_hash))
            await self._wait_for_finish(process_hash)
        except Exception as e:
            self._failed(e, message, table, process_hash)

    async def _wait_for_finish(self, to_process):
        while to_process in self._in_process:
            await asyncio.sleep(0.001)

    def _success(self, _, message, table, process_hash):
        if process_hash in self._in_process:
            self._logger.debug(
                f"Removing Hash: {process_hash} from In Process: {self._in_process} - Message: {message}")
            self._in_process.remove(process_hash)
        self._logger.debug(f"Inserted message {message} into {table}")

    def _failed(self, exception, message, table, process_hash):
        if process_hash in self._in_process:
            self._logger.debug(
                f"Removing Hash: {process_hash} from In Process: {self._in_process} - Message: {message}")
            self._in_process.remove(process_hash)
        self._event.send_to_failed_topic(f"{message} - Table: {table}", exception)
