import datetime
from logging import Logger
from os import getenv

from apollo_orm.orm.core import ORMInstance

from src.commercial_generic_lambda.infrastructure.configs.services.config import ConfigService
from src.commercial_generic_lambda.infrastructure.credentials.services.credentials import CredentialsService


class ConnectionService:

    def __init__(self, topic_name: str, logger: Logger) -> None:
        logger.debug("ConnectionService")
        self._logger = logger
        self._topic_name = topic_name.replace("-", "_")
        self._config_service = self._get_config()
        self._session = ORMInstance(connection_config=self._config_service.config_generate(), aws_lambda=True)
        self._start_time = datetime.datetime.now()
        self._last_used_time = datetime.datetime.now()

    def time_info(self):
        start = f"Start Time: {self._start_time}"
        last_used = f"Last Used Time: {self._last_used_time}"
        now = f"Now: {datetime.datetime.now()}"
        return f"{start} - {last_used} - {now}"

    def check_idle_time(self):
        return self._last_used_time < datetime.datetime.now() - datetime.timedelta(minutes=5)

    def set_last_used_time(self):
        self._last_used_time = datetime.datetime.now()

    def reconnect(self):
        self._session.reconnect()

    def get_session(self) -> ORMInstance:
        return self._session

    def get_tables(self) -> list:
        return self._config_service.tables

    def _get_config(self) -> ConfigService:
        self._logger.debug(f"Getting config for {self._topic_name}")
        string_connection = getenv(f"{self._topic_name}_secret")
        if not string_connection:
            raise ValueError(f"Secret for {self._topic_name} not found")
        self._tables = getenv(f"{self._topic_name}_tables")
        if not self._tables:
            raise ValueError(f"Tables for {self._topic_name} not found")
        self._logger.debug(f"Connection String: {string_connection}")
        self._logger.debug(f"Tables: {self._tables}")
        credentials = CredentialsService(string_connection).get_credentials()
        self._logger.debug(f"Keyspace: {credentials.keyspace_name}")
        self._logger.debug(f"Datacenter: {credentials.datacenter}")
        return ConfigService(credentials, self._tables)
