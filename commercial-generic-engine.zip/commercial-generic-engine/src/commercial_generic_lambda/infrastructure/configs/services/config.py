from apollo_orm.domains.models.entities.connection_config.entity import ConnectionConfig
from apollo_orm.domains.models.entities.credentials.entity import Credentials


class ConfigService:
    def __init__(self, credentials: Credentials, tables: str):
        if not tables or tables.isspace():
            raise ValueError("Tables cannot be empty")
        self.credentials = credentials
        self.tables = tables.split(",")

    def config_generate(self) -> ConnectionConfig:
        return ConnectionConfig(self.credentials, self.tables)
