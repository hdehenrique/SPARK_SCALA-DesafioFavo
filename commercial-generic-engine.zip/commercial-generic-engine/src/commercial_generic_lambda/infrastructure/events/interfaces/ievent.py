from abc import abstractmethod, ABC
from typing import Dict, Any, List, AsyncIterable


class IEvent(ABC):
    @abstractmethod
    def get_messages(self) -> List[Dict[str, Any]]:
        """Get messages from event"""

    @abstractmethod
    def get_event(self) -> Dict[str, Any]:
        """Get event"""

    @abstractmethod
    def send_to_failed_topic(self, message: str, error: Exception = None):
        """Send message to failed topic"""
