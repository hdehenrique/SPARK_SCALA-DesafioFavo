import json
from logging import Logger
from typing import Any, Dict, List, AsyncIterable

from src.commercial_generic_lambda.infrastructure.events.interfaces.ievent import IEvent


class SQSEventException(Exception):
    def __init__(self, message="Failed to read Records"):
        self.message = message
        super().__init__(self.message)


class SQSService(IEvent):

    def __init__(self, event: Dict[str, Any], logger: Logger):
        logger.info("SQSService")
        self._logger = logger
        self._event = event
        self.topic_name = None

    def get_event(self) -> Dict[str, Any]:
        return self._event

    def send_to_failed_topic(self, message: str, error: Exception = None):
        self._logger.error(f"Failed to insert message: {message} - {error}")
        raise error

    def get_messages(self) -> List[Dict[str, Any]]:
        try:
            for record in self._event['Records']:
                try:
                    body = json.loads(record['body'])
                    received_message = body['Message']
                    if isinstance(received_message, str):
                        received_message = json.loads(received_message)
                    yield received_message
                except Exception as e:
                    self._logger.error(f"Failed to parse Record: {e}")
                    raise e
        except Exception as e:
            self._logger.error(f"Failed to read Records in Event: {self._event}")
            raise SQSEventException(f"Error message: {e}")
