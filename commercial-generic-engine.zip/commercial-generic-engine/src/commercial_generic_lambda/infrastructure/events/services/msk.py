import json
from base64 import b64decode
from logging import Logger
from os import getenv
from typing import Any, Dict, List
from kafka import KafkaProducer

from src.commercial_generic_lambda.infrastructure.events.interfaces.ievent import IEvent


class MSKService(IEvent):

    def __init__(self, event: Dict[str, Any], logger: Logger, topic_name, producer: KafkaProducer):
        logger.info("MSKService")
        self._logger = logger
        self._event = event
        self._producer = producer
        self._topic_name = topic_name

    def get_event(self) -> Dict[str, Any]:
        return self._event

    def send_to_failed_topic(self, message: str, error: Exception = None):
        self._logger.error(f"Failed to process message: {message} - {error}")
        try:
            self._producer.send(getenv("failed_topic_name"), str.encode(json.dumps(
                {"lambda": getenv("lambda_name"), "topicSource": self._topic_name,
                 "message": message.replace("\u0027", "'"),
                 "error": str(error)}).replace("\u0027", "'")))
            self._producer.flush()
        except Exception as e:
            self._logger.error(f"Failed to send message to {getenv('failed_topic_name')}: {message}")
            raise e

    def get_messages(self) -> List[Dict[str, Any]]:
        try:
            event_records = self._event.get("records", {})

            for partition, event_messages in event_records.items():
                for event_message in event_messages:
                    message = event_message.get("value")
                    if message:
                        try:
                            message = b64decode(message).decode('utf-8')
                        except Exception as e:
                            self._logger.debug(f"Message is not encrypted: {e}")
                        try:
                            yield json.loads(message)
                        except Exception as e:
                            self._logger.error(f"Failed to parse message: {message} - {e}")
                            self.send_to_failed_topic(message, e)
        except Exception as e:
            self._logger.error(f"Failed to read Records in Event: {self._event}")
            self.send_to_failed_topic(json.dumps(self._event), e)
