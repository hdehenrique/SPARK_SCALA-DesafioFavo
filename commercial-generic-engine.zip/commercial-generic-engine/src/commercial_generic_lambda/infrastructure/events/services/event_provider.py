from logging import Logger

from kafka import KafkaProducer

from src.commercial_generic_lambda.infrastructure.events.interfaces.ievent import IEvent
from src.commercial_generic_lambda.infrastructure.events.services.msk import MSKService
from src.commercial_generic_lambda.infrastructure.events.services.sqs import SQSService


class EventSourceException(Exception):
    def __init__(self, message="Unknown Event Source"):
        self.message = message
        super().__init__(self.message)


class EventProvideService:
    def __init__(self, event, logger: Logger, producer: KafkaProducer) -> None:
        logger.info("EventProvideService")
        self._logger = logger
        self._event = event
        self._producer = producer
        self.type_event = None
        self.topic_name = None
        self._event_provider_factory()
        self._logger.debug(f"Event Source: {self.type_event}")
        self._logger.debug(f"Topic Name: {self.topic_name}")

    def _event_provider_factory(self) -> None:
        if 'Records' in self._event and 'eventSourceARN' in self._event['Records'][0] and 'sqs' in \
                self._event['Records'][0]['eventSourceARN']:
            self.topic_name = self._event['Records'][0]['eventSourceARN'].split(":")[-1]
            self.type_event = 'sqs'
        elif 'records' in self._event and 'eventSource' in self._event and self._event['eventSource'] in ['aws:kafka',
                                                                                                          'aws:msk']:
            self.topic_name = list(list(self._event['records'].values())[0])[0]['topic']
            self.type_event = 'kafka'
        else:
            raise EventSourceException(f"Unknown event source: {self._event}")

    def parse_event(self) -> IEvent:
        if self.type_event == 'sqs':
            return SQSService(self._event, self._logger)
        else:
            return MSKService(self._event, self._logger, self.topic_name, self._producer)
