import datetime
import logging
from logging import Logger

from kafka import KafkaProducer


def retry(attempts: int):
    def decorator(func):
        def wrapper(*args, **kwargs):
            for _ in range(attempts):
                try:
                    return func(*args, **kwargs)
                except ProducerException as e:
                    logging.exception(f"Error to create producer: {e}")
                    raise e

        return wrapper

    return decorator


class ProducerException(Exception):
    def __init__(self, message="Unknown Producer Error"):
        self.message = message
        super().__init__(self.message)


class ProducerService:

    def __init__(self, bootstrap: str, logger: Logger):
        logger.info("ProducerService")
        self._logger = logger
        self._bootstrap = bootstrap
        self._start_time = datetime.datetime.now()
        self._last_used_time = datetime.datetime.now()
        self.producer = self._create_producer()

    @retry(attempts=5)
    def _create_producer(self) -> KafkaProducer:
        try:
            return KafkaProducer(bootstrap_servers=self._bootstrap, api_version=(2, 6, 1))
        except Exception as e:
            raise ProducerException(f"Error to create producer: {e}")

    def time_info(self):
        start = f"Start Time: {self._start_time}"
        last_used = f"Last Used Time: {self._last_used_time}"
        now = f"Now: {datetime.datetime.now()}"
        return f"{start} - {last_used} - {now}"

    def check_idle_time(self):
        return self._last_used_time < datetime.datetime.now() - datetime.timedelta(minutes=5)

    def set_last_used_time(self):
        self._last_used_time = datetime.datetime.now()

    def reconnect(self):
        self._create_producer()
