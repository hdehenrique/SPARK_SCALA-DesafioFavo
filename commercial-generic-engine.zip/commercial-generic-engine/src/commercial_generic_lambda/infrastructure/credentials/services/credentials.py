import json

from apollo_orm.domains.models.entities.credentials.entity import Credentials
from boto3 import client as aws_client


class CredentialsException(Exception):
    def __init__(self, message="Unknown Event Source"):
        self.message = message
        super().__init__(self.message)


class CredentialsService:
    def __init__(self, secret: str) -> None:
        self._secret = secret

    def get_credentials(self) -> Credentials:
        aws_client_secret = aws_client("secretsmanager")
        try:
            secret_value = json.loads(aws_client_secret.get_secret_value(SecretId=self._secret)["SecretString"])
            if not secret_value:
                raise CredentialsException("Secret is empty")
            return Credentials(
                hosts=secret_value.get("host").split(","),
                port=secret_value.get("port"),
                user=secret_value.get("username"),
                password=secret_value.get("password"),
                keyspace_name=secret_value.get("dbname"),
                datacenter=secret_value.get("datacenter")
            )
        except Exception as e:
            raise CredentialsException(f"Failed to create Credentials: {e}")
