package br.com.natura.settings

import br.com.natura.commercial.performance.commons.credentials.Credentials
import br.com.natura.commercial.performance.commons.enums.enumsCredentials
import br.com.natura.settings.Settings.oracle_o05_credentials
import com.typesafe.config.ConfigFactory
import org.joda.time.DateTimeZone

import java.util
object Settings {
  private val config = ConfigFactory.load()
  private val weblogGen = config.getConfig("business-relation-oracle")
  private val hadoopSettings = config.getConfig("hadoop_settings")
  private val cassandraSettings = config.getConfig("scylla_conn")
  private val oracle05Settings = config.getConfig("oracle05")
  private val oracle02Settings = config.getConfig("oracle02")
  private val kafkaSettings = config.getConfig("kafka_settings")
  private val kafkaAmbariSettings = config.getConfig("kafka_ambari_settings")
  private val environmentSettings = config.getConfig("environment")
  lazy val batch_size = weblogGen.getInt("batch_size")
  lazy val kafka_bootstrap_servers: String = environmentSettings.getString("kafka_bootstrap_servers")
  lazy val max_retry = weblogGen.getInt("max_retry")
  lazy val scylla_ttl = weblogGen.getInt("scyllaTtl")

  //////SECRET MANAGER /////////////////
  val environment: String = System.getProperty("spark.master")  // retorna ambiente da execução  local("local[*]") ou cluster("yarn")
  val region =  environmentSettings.getString("region")
  val scyllaSecretName = environmentSettings.getString("scylla_secret_name")
  val oracleo02SecretName = environmentSettings.getString("oracle02_secret_name")
  ////////////////////////////////////


  lazy val appName: String = weblogGen.getString("appName")
  lazy val cdUserUpdate =   weblogGen.getString("user_update")
  lazy val logLevel = weblogGen.getString("logLevel")
  lazy val winUtils: String = hadoopSettings.getString("winUtils")
  lazy val kafka_microbatch_duration: Int = weblogGen.getInt("microbatch_duration")
  lazy val countryToProcess = weblogGen.getString("countryToProcess").split(",")


  lazy val kafka_topic_read: String = kafkaSettings.getString("kafka_topic_send_oracle")
  lazy val kafka_topic_reprocess = kafkaSettings.getString("kafka_topic_reprocess")
  lazy val kafka_topic_failed = kafkaSettings.getString("kafka_topic_failed")
  lazy val kafka_consumer_fetchsizebytes: String = kafkaSettings.getString("consumer_fetchsizebytes")
  lazy val kafka_consumer_fillfreqms: String = kafkaSettings.getString("consumer_fillfreqms")
  lazy val kafka_consumer_num_fetch_to_buffer: String = kafkaSettings.getString("consumer_num_fetch_to_buffer")

  val scylla_performance_credentials =  if (environment == enumsCredentials.cluster){
    /// Caso a execução seja no cluster buscará as credenciais no secret manager
    Credentials.getFromSecretManagger(enumsCredentials.dataBaseTypeScylla,scyllaSecretName,region)
  } else {
    // caso a execução seja local buscará as credenciais de acesso no arquivo de configuração
    Credentials.getFromFile(enumsCredentials.dataBaseTypeScylla,cassandraSettings)
  }


  lazy val cassandraServerAddress: String = scylla_performance_credentials.host
  lazy val cassandraUser: String = scylla_performance_credentials.userName
  lazy val cassandraPass: String = scylla_performance_credentials.password
  lazy val cassandraOrigin = scylla_performance_credentials.origin
  lazy val cassandraInputConsistency: String = cassandraSettings.getString("input_consistency")
  lazy val cassandraOutputConsistency: String = cassandraSettings.getString("output_consistency")


  val oracle_o02_credentials =
   if (environment == enumsCredentials.cluster){
    Credentials.getFromSecretManagger(enumsCredentials.dataBaseTypeScylla,oracleo02SecretName,region)
  }  else {
    Credentials.getFromFile(enumsCredentials.dataBaseTypePostgresql,oracle02Settings)
   }

  lazy val oracle02Host: String = oracle_o02_credentials.host

  lazy val oracle02User: String = oracle_o02_credentials.userName
  lazy val oracle02Pass: String = oracle_o02_credentials.password
  lazy val oracleo02Driver = oracle02Settings.getString("driver")
  lazy val oracleo02Port = oracle02Settings.getString("port")
  lazy val oracleo02ServiceName = oracle02Settings.getString("servicename")

  lazy val oracle02Url = oracleo02Driver + oracle02Host + ":" + oracleo02Port + "/" + oracleo02ServiceName + "?ApplicationName=" + appName


  //val oracle_o02_credentials = Credentials.getFromFile(enumsCredentials.dataBaseTypePostgresql,oracle02Settings)
//  lazy val oracle02Url: String = oracle_o02_credentials.conectionURL
//  lazy val oracle02User: String = oracle_o02_credentials.userName
//  lazy val oracle02Pass: String =  oracle_o02_credentials.password

  val oracle_o05_credentials = Credentials.getFromFile(enumsCredentials.dataBaseTypePostgresql,oracle05Settings)


  lazy val oracle05Url: String = oracle_o05_credentials.conectionURL
  lazy val oracle05User: String = oracle_o05_credentials.userName
  lazy val oracle05Pass: String = oracle_o05_credentials.password

  lazy val oracleNumPartitions: Int = oracle05Settings.getInt("numPartitions")
  lazy val oracleBatchSize: String = oracle05Settings.getString("batchsize")
  lazy val oracleFetchSize: String = oracle05Settings.getString("fetchsize")

  lazy val kafka_ambari_protocol: String = kafkaAmbariSettings.getString("protocol")
  lazy val kafka_ambari_port: String = kafkaAmbariSettings.getString("port")
  lazy val kafka_ambari_hostsAPI: String = kafkaAmbariSettings.getString("hostsAPI")
  lazy val kafka_ambari_user: String = kafkaAmbariSettings.getString("user")
  lazy val kafka_ambari_pass: String = kafkaAmbariSettings.getString("pass")

  //NOVOS
  private val sparkSettings = config.getConfig("spark_conn")
  lazy val cassandraTimeout: String = cassandraSettings.getString("timeout_ms")
  lazy val cassandraReconnectionDelayMax: String = cassandraSettings.getString("reconnection_delay_ms_max")
  lazy val cassandraReconnectionDelayMin: String = cassandraSettings.getString("reconnection_delay_ms_min")
  lazy val cassandraRetryCount: String = cassandraSettings.getString("retry_count")
  lazy val sparkMaxFailures: String = sparkSettings.getString("maxFailures")
  lazy val maxRate = weblogGen.getString("maxRate")
  lazy val partitions = weblogGen.getString("partitions")

  //Params
  lazy val paramQtyCycles = weblogGen.getInt("param_qty_cycles")
  lazy val paramOrderValue = weblogGen.getInt("param_order_value")
  lazy val paramTypeValue = weblogGen.getInt("param_type_value")
  lazy val paramTypeMonetaryValue = weblogGen.getInt("param_type_monetary_value")
  lazy val groupedSize = weblogGen.getInt("groupedSize")
  lazy val engine_id = weblogGen.getInt("engine_id")
  lazy val useOffset = weblogGen.getBoolean("useOffset") //indica se o motor deve usar o offset gravado quando iniciar
  lazy val recordOffset = weblogGen.getBoolean("recordOffset") //indica se o motor deve atualizar o offset na tabela apos processar
  val zoneUTC: DateTimeZone = DateTimeZone.UTC
  lazy val kafka_spec_failed_messages = kafkaSettings.getString("kafka_topic_spec_failed_messages")


  val summitParameters = config.getConfig("summit_parameters")
  val summitEngine = summitParameters.getConfig("business-relation-oracle")

  val spark_cassandra_read_timeout_ms = summitEngine.getString("spark_cassandra_read_timeout_ms")
  val spark_cassandra_connection_compression = summitEngine.getString("spark_cassandra_connection_compression")
  val connection_connections_per_executor_max = summitEngine.getString("connection_connections_per_executor_max")
  val spark_cassandra_concurrent_reads = summitEngine.getString("spark_cassandra_concurrent_reads")
  val spark_shuffle_service_enabled = summitEngine.getString("spark_shuffle_service_enabled")
  val spark_cassandra_input_split_size_in_mb = summitEngine.getString("spark_cassandra_input_split_size_in_mb")
  val spark_cassandra_input_fetch_size_in_rows = summitEngine.getString("spark_cassandra_input_fetch_size_in_rows")
  val spark_cassandra_output_batch_size_rows = summitEngine.getString("spark_cassandra_output_batch_size_rows")
  val spark_cassandra_output_concurrent_writes = summitEngine.getString("spark_cassandra_output_concurrent_writes")
  val spark_memory_fraction = summitEngine.getString("spark_memory_fraction")
  val spark_memory_storageFraction = summitEngine.getString("spark_memory_storageFraction")
  val spark_locality_wait = summitEngine.getString("spark_locality_wait")
  val spark_serializer = summitEngine.getString("spark_serializer")
  val trigger_next_page_fetching_at = summitEngine.getString("trigger_next_page_fetching_at")
  val spark_dynamicAllocation_enabled: String = summitEngine.getString("spark_dynamicAllocation_enabled")
  val maxExecutors: String = weblogGen.getString("max_executors")





}

