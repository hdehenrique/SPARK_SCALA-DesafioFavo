package br.com.natura.handlers.kafka

import java.io.InputStream
import java.net.{HttpURLConnection, URL}
import java.util.UUID.randomUUID
import br.com.natura.settings.Settings
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.TopicPartition
import org.apache.kafka.common.serialization.{StringDeserializer}
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
//import sun.misc.BASE64Encoder

object Kafka {
  val readTopic: Set[String] = Set(Settings.kafka_topic_read,Settings.kafka_topic_reprocess)
  val properties: Map[String, Object] = this.setConsumerProperties

  def setCalculationDirectStream(ssc: StreamingContext,fromOffsets :Map[TopicPartition, Long], useOffset : Boolean): InputDStream[ConsumerRecord[String, String]] = {
    KafkaUtils.createDirectStream[String, String](
      ssc,
      PreferConsistent,
      if (fromOffsets.size == 0 || useOffset == false )
        Subscribe[String, String](this.readTopic, this.properties)
      else
        Subscribe[String, String](this.readTopic, this.properties,fromOffsets)
    )
  }


  @throws(classOf[java.io.IOException])
  @throws(classOf[java.net.SocketTimeoutException])
  def request(url: String,
              connectTimeout: Int = 5000,
              readTimeout: Int = 5000,
              requestMethod: String = "GET"): String = {
    val encodedPassword = (Settings.kafka_ambari_user + ":" + Settings.kafka_ambari_pass).getBytes
    val conn = new URL(url).openConnection.asInstanceOf[HttpURLConnection]
    conn.setConnectTimeout(connectTimeout)
    conn.setReadTimeout(readTimeout)
    conn.setRequestMethod(requestMethod)
    //conn.setRequestProperty("Authorization", "Basic " + new BASE64Encoder().encode(encodedPassword))

    val inputStream: InputStream = conn.getInputStream
    val content: String = scala.io.Source.fromInputStream(inputStream).mkString

    if (inputStream != null) inputStream.close()

    content
  }

  def setConsumerProperties: Map[String, Object] = {

    val id = randomUUID().toString
    val groupID = Settings.appName + "-" + id

    Map(
      "bootstrap.servers" -> Settings.kafka_bootstrap_servers,
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "auto.offset.reset" -> "latest",
      "group.id" -> groupID,
      "enable.auto.commit" -> (false: java.lang.Boolean)
    )
  }


}
