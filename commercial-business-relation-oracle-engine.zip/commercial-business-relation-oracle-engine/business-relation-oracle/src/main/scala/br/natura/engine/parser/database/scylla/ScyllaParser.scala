package br.com.natura.engine.parser.database.scylla


import br.com.natura.domain.cassandra.KafkaProcessedOffSet
import br.natura.domain.application.CountryCodes
import br.natura.domain.cassandra.Orders
import com.datastax.driver.core.Row

import java.sql.Timestamp


object ScyllaParser {
  def parseRowToKafkaProcessedOffSet(r: Row): KafkaProcessedOffSet = {
    KafkaProcessedOffSet (
      topic = r.getString("topic"),
      partition = r.getInt("partition"),
      offset = r.getLong("offset")
    )
  }

  def parseRowToCountryCodes(r: Row): CountryCodes = {
    CountryCodes (
      country = r.getInt("country"),
      country_iso = r.getString("country_iso"),
      country_name = r.getString("country_name")
    )
  }


  def parseRowToOrders(r: Row): Orders = {
    Orders (
      order_id = r.getInt("order_id"),
      order_points = r.getInt("order_points"),
      order_calculation_date = r.getTimestamp("order_calculation_date")
    )
  }


}
