package br.com.natura.helpers

import java.sql
import java.sql.Timestamp
import java.util.Date
import java.util.Calendar

import org.joda.time.DateTime
import org.slf4j.LoggerFactory

object Helpers {

  def getLogger(classType: Class[_ <: Any]): LoggerLocal = {
    val logger = LoggerFactory.getLogger(classType.getCanonicalName)
    new LoggerLocal(Option(logger))
  }

  def currentTimestamp(date: Date): Timestamp = {
    new Timestamp(date.getTime)
  }

  def currentDate(): Date = {
    Calendar.getInstance.getTime
  }


  def stringToDate(date : String): sql.Date = {
    Helpers.currentSQLDate(java.sql.Date.valueOf(date))
  }

  def currentSQLDate(date: Date): sql.Date = {
    new sql.Date(date.getTime)
  }

  def getHourRange(timestamp: Timestamp): Int = {
    val calendar: Calendar = Calendar.getInstance
    calendar.setTime(timestamp)

    calendar.get(Calendar.HOUR_OF_DAY)
  }

  def getYearMonth (timestamp: Timestamp): Int = {
    val calendar: Calendar = Calendar.getInstance
    calendar.setTime(timestamp)

   val year =  calendar.get(Calendar.YEAR)
   val month =  calendar.get(Calendar.MONTH)

    val yearmonth = year.toString + month.toString

    yearmonth.toInt
  }



  def getHourRange2(hourRange: DateTime): Int = {

    hourRange.getHourOfDay


  }


}
