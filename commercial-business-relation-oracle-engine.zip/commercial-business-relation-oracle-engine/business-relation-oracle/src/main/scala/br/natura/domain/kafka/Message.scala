package src.main.scala.br.natura.domain.kafka

import br.com.natura.domain.cassandra.KafkaProcess
import br.com.natura.settings.Settings

import java.util.UUID
case class MessageRecived(
  uuid: String,
  country: String,
  company : Int,
  business_model: Int,
  structure_level : Int,
  structure_code : Int,
  cycle : Int,
  person_code : Int,
  person_id : String,
  business_status_code : Int,
  function : Int,
  role : Int,
  start_date : String,
  end_date : String,
  operation : String,
  operation_date : String,
  kafka_process : KafkaProcess
                  )

object MessageRecived {
  def emputy(message : String): MessageRecived ={
    MessageRecived (
      country = "XX",
      uuid = UUID.randomUUID().toString,
      business_model = 0 ,
      company = 0,
      structure_level = 0,
      structure_code = 0,
      cycle = 0,
      person_code = 0,
      person_id =  UUID.randomUUID().toString,
      business_status_code = 0,
      function = 0,
      role = 0,
      start_date = " ",
      end_date = " ",
      operation = " ",
      operation_date = " ",
      kafka_process = KafkaProcess(Settings.kafka_topic_read,0,0," ",0)
    )
  }
}

case class JsonEloToProcess(
                             json_to_elo : String,
                             elo_parameter : Boolean
                           )

case class FatherStructureToProcess (
                                country: Int,
                                company_id: Int,
                                business_model: Int,
                                structure_level: Int,
                                structure_code: Int,
                                cycle: Int,
                                uuid: String,
                                messageToSend: String,
                                originalMessage: String
                              )