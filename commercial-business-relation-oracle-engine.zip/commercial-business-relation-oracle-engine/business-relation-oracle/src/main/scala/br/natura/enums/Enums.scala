package br.natura.enums

object Enums extends Enumeration {
  val STATUS_CODE_CN = 3
  val operation: String = "R"

}