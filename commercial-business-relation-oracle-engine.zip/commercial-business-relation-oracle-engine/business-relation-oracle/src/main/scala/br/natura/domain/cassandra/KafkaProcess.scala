package br.com.natura.domain.cassandra

import java.sql.Timestamp

case class KafkaProcess(topic : String, partition : Int, offset : Long,message : String, retry : Int)
case class KafkaProcessedOffSet(topic : String, partition : Int, offset : Long)
case class KafkaProcessToRecord(topic : String, engine_id: Int, partition : Int, offset : Long , process_data : Timestamp)