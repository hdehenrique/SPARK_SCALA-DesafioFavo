package br.com.natura.engine.data

import java.sql.Timestamp
import java.util.Date
import br.com.natura.domain.cassandra.{KafkaProcess, KafkaProcessToRecord}
import br.com.natura.handlers.database.ScyllaWrite
import br.com.natura.settings.Settings
import br.natura.domain.application.{MessageHistory, PedidoRedeHeader, PedidoRedeItem, PsPapelPessoaInsert}
import br.natura.engine.data.Oracle
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

class DataWrite(ss: SparkSession, sc: SparkContext) {
  import ss.implicits._

  private val scylla = new ScyllaWrite(sc)
  private val Oracle = new Oracle()

  def setPapelPessoa(business_relations: RDD[PsPapelPessoaInsert]): Unit = {
    if (!business_relations.isEmpty) {
//      println("setPapelPessoa")
     //business_relations.toDS().show(false)
      Oracle.setTPsPapelPessoa(business_relations.toDS(), Settings.oracle02Url, Settings.oracle02User, Settings.oracle02Pass)
    }
  }
  def writekafkaOffsetControl(rdd: RDD[KafkaProcess]) = {

    // PROJ-OFFSET GROUP BY PARA GRAVAR O MENOR OFF SET DO TOPICO E PARTITION
    //USEI O MENOR PARA GARANTIR QUE TODOS OS PEDIDOS SERÃO PROCESSADOS
    val offSetToRecord: RDD[KafkaProcessToRecord] = rdd.groupBy(r => (r.topic,r.partition)).mapValues(_.map(_.offset).min).map(x => {
      KafkaProcessToRecord(x._1._1,Settings.engine_id,x._1._2,x._2,new Timestamp(new Date().getTime))
    })
    offSetToRecord.foreach(println)
    scylla.saveTokafkaOffsetControl(offSetToRecord.toDS(), Settings.scylla_ttl)
  }


  def saveToMessageHistory(rdd : RDD[MessageHistory]) = {
    try {
      scylla.saveToMessageHistory(rdd)
    }catch {
    case _: Exception => println("Erro na gravação da message history")
    }
  }


}