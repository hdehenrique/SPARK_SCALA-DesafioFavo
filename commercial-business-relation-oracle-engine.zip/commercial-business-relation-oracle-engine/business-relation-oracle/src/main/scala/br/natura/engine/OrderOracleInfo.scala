package br.natura.engine
import br.com.natura.engine.data.DataCollectorSerializable
import br.natura.domain.application.{OrderItemPedidoRede, OrdersPedidoRede}
import org.apache.spark.SparkConf
import src.main.scala.br.natura.domain.kafka.MessageRecived
import src.main.scala.br.natura.handlers.database.connection.Oracle

class OrderOracleInfo(config: SparkConf) extends Serializable {

  def checkOracleInfo(businessRelations : List[MessageRecived]) = {

    val oracle02Connection = Oracle.getOracle02Connection()
    val oracle05Connection = Oracle.getOracle05Connection()

    val dc = new DataCollectorSerializable(config)
    val consultants = businessRelations.map(_.person_code)

    ///BUSCA CN NA T_PESSOA
    val t_pessoa = dc.getTPessoa(consultants,oracle02Connection)
    ///BUSCA A CN NA T_PS_CONSULTORA
    val t_ps_consultora = dc.getTPsConsultora(consultants,oracle02Connection)
    //BUSCA A CONSULTORA NA T_CONSULTORA NO o05
    val t_consultora = dc.getConsultora(consultants,oracle05Connection)
    //BUSCA A CONSULTORA NA T_PESSOA_RELACAO_COMERCIAL
    val t_pessoa_relaca_comercial = dc.getPessoaRelacaoComercial(consultants,oracle02Connection)
    //BUSCA A CONSULTORA NA  T_PS_PAPEL_PESSOA
    val t_ps_papel_pessoa = dc.getPsPapelPessoa(consultants,oracle02Connection)

    (t_ps_consultora,t_consultora,t_pessoa_relaca_comercial,t_ps_papel_pessoa,t_pessoa)
  }

}
