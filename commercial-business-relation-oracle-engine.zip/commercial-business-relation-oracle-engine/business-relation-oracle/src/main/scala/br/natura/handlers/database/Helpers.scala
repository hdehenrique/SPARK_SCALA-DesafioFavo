package br.natura.handlers.database

import com.datastax.spark.connector.{ColumnName, SomeColumns}
import com.datastax.spark.connector.{ColumnName, SomeColumns}
import org.joda.time.DateTime
import org.joda.time.format.{DateTimeFormat, DateTimeFormatter}
import org.slf4j.{Logger, LoggerFactory}
import scala.util.parsing.json.JSON
import scala.reflect.runtime.universe._
object Helpers {

  private def fieldList[T: TypeTag]: List[String] = typeOf[T].members.collect {
    case m: MethodSymbol if m.isCaseAccessor => m.name.toString
  }.toList

  private def getAsColumnNames(columnNames: Seq[String]): Seq[ColumnName] = {
    columnNames.map(ColumnName(_))
  }

  def getAsColumnNamesFromClass[T: TypeTag]: SomeColumns = {
    val columnNames = getAsColumnNames(fieldList[T])
    SomeColumns(columnNames: _*)
  }
}
