package br.natura.app

import br.com.natura.domain.cassandra._
import br.com.natura.engine.data.{DataCollectorSerializable, DataWrite}
import br.com.natura.handlers.kafka.Kafka
import br.com.natura.handlers.spark.Spark
import br.com.natura.helpers.Helpers
import br.com.natura.settings.Settings
import br.natura.domain.application.{Consultora, CountryCodes, OrderItemPedidoRede, OrdersPedidoRede, PSConsultora, PedidoRedeHeader, PedidoRedeItem, Pessoa, PessoaRelacaoComercial, PsPapelPessoaInsert, PsPapelPessoaSelect, PsPapelPessoaUpdate}
import br.natura.engine.OrderOracleInfo
import br.natura.engine.data.Updater
import br.natura.engine.parser.kafka.Message
import br.natura.enums.Enums
import br.natura.handlers.KafkaSink
import br.natura.handlers.kafka.OutputParser
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.TopicPartition
import org.apache.spark.SparkContext
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.{Duration, Seconds, StreamingContext}
import src.main.scala.br.natura.domain.kafka.MessageRecived
import src.main.scala.br.natura.engine.EngineSerializable
import src.main.scala.br.natura.handlers.database.connection.Oracle

import java.util.Properties
import java.util.UUID.randomUUID


object StreamingApp extends App{
  val sc: SparkContext = Spark.getSparkContext
  val ss: SparkSession = Spark.getSparkSession
  val dc: DataWrite = new DataWrite(ss,sc)
  val dcSer = new DataCollectorSerializable(sc.getConf)
  val ssc: StreamingContext = Spark.getStreamingContext(streamingApp, Seconds(Settings.kafka_microbatch_duration))
  sc.setLogLevel(Settings.logLevel)
  ssc.start()
  ssc.awaitTermination()

  def streamingApp(sc: SparkContext, batchDuration: Duration): StreamingContext = {
    val id = randomUUID().toString
    val groupID = Settings.appName + "-" + id
    val props = new Properties()
    props.put("bootstrap.servers", Settings.kafka_bootstrap_servers)
    props.put("client.id", groupID)
    props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    props.put("group.id", groupID)
    props.put("auto.offset.reset", "latest")
    props.put("enable.auto.commit", false: java.lang.Boolean)
    println("ENVIRONMENT: " + Settings.environment)
    println("AMBIENTE: " +  Settings.kafka_bootstrap_servers)
    println("LEITURA: " + Settings.kafka_topic_read)
    println("MAXRATE: " +  Settings.maxRate)
    println("KAFKA_MICROBATCH_DURATION: " +  Settings.kafka_microbatch_duration)

    println("BATCHS POR EXECUÇÃO: " +Settings.maxRate.toInt *  Settings.kafka_microbatch_duration.toInt * 3 )

    println("GROUPEDSIZE: " + Settings.groupedSize)
    println("USA OFF QUANDO INICIOU: " +  Settings.useOffset)
    println("GRAVA OFFSET APOS PROCESSAMENTO: " +  Settings.recordOffset)
    println("ENGINE: " +  Settings.engine_id)
    //println("oracleo02SecretName " + Settings.oracleo02SecretName)
    println("oracle02Url: " + Settings.oracle02Url)
    println("oracle05Url: " + Settings.oracle05Url)
    println("BATCH_SIZE: " + Settings.batch_size)


    val kafkaSink: Broadcast[KafkaSink] = sc.broadcast(KafkaSink(props))


    val countryToProcess = Settings.countryToProcess.map(x => x).toList

    println("countryToProcess " +  countryToProcess.mkString(","))

    val ssc: StreamingContext = new StreamingContext(sc, batchDuration)

    // PROJ-OFFSET CONSULTO NO BANCO DE DADOS O OFFSET CADASTRADO PARA O TOPICO E O MOTOR
    val topicReadList = List(Settings.kafka_topic_read,Settings.kafka_topic_reprocess)
    val offsets= try {
      dcSer.getKafkaOffsetControl(Settings.engine_id,topicReadList )
    } catch {
      case _: Exception =>  List(KafkaProcessedOffSet(Settings.kafka_topic_read,0,2))
    }

    val countryCodes: List[CountryCodes] = dcSer.getCountry()

    countryCodes.foreach(println)
    println("----------------")

    // PROJ-OFFSET TRANSFORMO O RESULTADO DA CONSULTA PARA O FORMATO ESPERADO PELO METODO DE CONSULMO DO KAFKA
    val fromOffsets: Map[TopicPartition, Long] = offsets.map { resultSet =>
      new TopicPartition(resultSet.topic, resultSet.partition) -> resultSet.offset
    }.toMap

    println("fromOffsets -> " + fromOffsets)

    val stream: InputDStream[ConsumerRecord[String, String]] = Kafka.setCalculationDirectStream(ssc,fromOffsets,Settings.useOffset)
    //val kafkaSink: Broadcast[KafkaSink] = sc.broadcast(KafkaSink(props))

    val parsedMessage: DStream[MessageRecived] = stream.mapPartitions(Message.processPartition).filter(m =>
      countryToProcess.contains(m.country) && m.business_status_code == Enums.STATUS_CODE_CN && m.operation == Enums.operation )


    val messageToProcess =  this.handleMessageDuplicate(parsedMessage).repartition(Settings.partitions.toInt)

    val getOracleInfo = new OrderOracleInfo(sc.getConf)

    val engine = new EngineSerializable(sc.getConf)

    val results = messageToProcess.transform { rdd =>
      rdd.mapPartitions { partition =>partition.grouped(Settings.batch_size)}}.flatMap { batches =>
        val info: (List[Pessoa], List[Pessoa], List[Pessoa], List[PsPapelPessoaSelect], List[Pessoa]) = getOracleInfo.checkOracleInfo(batches.toList)
        batches.map(engine.processBusinessRelation(_,info,countryCodes))
    }.cache()


    val t_ps_consultora_update =results.mapPartitions(_.map(r => r._1))
    val t_consultora_update = results.mapPartitions(_.map(r => r._2))
    val t_pessoa_relaca_comercial_update = results.mapPartitions(_.map(r => r._3))
    val t_ps_papel_pessoa_candidate_update: DStream[PsPapelPessoaUpdate] = results.mapPartitions(_.map(r => r._4))
    val t_ps_papel_pessoa_cn_insert: DStream[PsPapelPessoaInsert] = results.mapPartitions(_.map(r => r._5).filter(x => x.insert == true && x.update == false))
    val t_ps_papel_pessoa_cn_update: DStream[PsPapelPessoaInsert] = results.mapPartitions(_.map(r => r._5).filter(x => x.insert == false && x.update == true))
    val kafkaProcess: DStream[KafkaProcess] = results.mapPartitions(_.map(r => r._6.kafka_process))
    val failed = results.filter(_._7 == false).mapPartitions(_.map(r => r._6)) //CN NÃO EXISTE NA T_PESSOA
    val messageHistory = results.mapPartitions(_.map(_._8))



    ///ATUALIZA A TABELA T_CONSULTORA NO BANCO O05PR
    t_consultora_update.foreachRDD { rdd =>
      rdd.foreachPartition { order =>
        val OracleCon =Oracle.getOracle05Connection()
        order.foreach { r =>
          new Updater().updateTConsultora(OracleCon,r)
        }
      }
    }

    t_ps_consultora_update.foreachRDD { rdd =>
      rdd.foreachPartition { order =>
        val OracleCon =Oracle.getOracle02Connection()
        order.foreach { r =>
          new Updater().updateTPsConsultora(OracleCon,r)
        }
      }
    }

    t_pessoa_relaca_comercial_update.foreachRDD { rdd =>
      rdd.foreachPartition { order =>
        val OracleCon =Oracle.getOracle02Connection()
        order.foreach { r =>
          new Updater().updateTPessoaRelacaoComercial(OracleCon,r)
        }
      }
    }

    ///FECHA O PAPEL DE AGUARDANDO PRIMEIRO PEDIDO NA T_PS_PAPEL_PESSOA
    t_ps_papel_pessoa_candidate_update.foreachRDD { rdd =>
      rdd.foreachPartition { order =>
        val OracleCon =Oracle.getOracle02Connection()
        order.foreach { r =>
          new Updater().updateTPsPapelPessoaCandidate(OracleCon,r)
        }
      }
    }

    //INSERE RELACAO DE CN NA T_PS_PAPEL_PESSOA
    t_ps_papel_pessoa_cn_insert.foreachRDD(rdd => {
      dc.setPapelPessoa(rdd)
    })


    t_ps_papel_pessoa_cn_update.foreachRDD { rdd =>
      rdd.foreachPartition { order =>
        val OracleCon =Oracle.getOracle02Connection()
        order.foreach { r =>
          new Updater().updateTPsPapelPessoaCn(OracleCon,r)
        }
      }
    }



    failed.foreachRDD(rdd => {
      rdd.foreach(r => {
        val jsonOut: (String, Int) = OutputParser.setJson(r)
        if (jsonOut._2 <= Settings.max_retry){
          kafkaSink.value.send(Settings.kafka_topic_reprocess,jsonOut._1 )
        }
        if (jsonOut._2 > Settings.max_retry ){
          kafkaSink.value.send(Settings.kafka_topic_failed,jsonOut._1 )
        }
      })
    })


    messageHistory.foreachRDD(rdd => {
      dc.saveToMessageHistory(rdd)
    })

    // PROJ-OFFSET MAP DAS INFORMAÇÕES RETORNADA DO KAFKA PARA A CLASSE
    if (Settings.recordOffset == true) {
      // PROJ-OFFSET TRANSFORMAÇÃO PARA A GRAVAÇÃO NO BANCO
      kafkaProcess.foreachRDD(rdd => dc.writekafkaOffsetControl(rdd))
    }



    ssc
  }

  def handleMessageDuplicate(personActivation: DStream[MessageRecived]): DStream[MessageRecived] = {

    val groupedRDD: DStream[MessageRecived] = personActivation.repartition(1).mapPartitions(
      mp => {
        val groupedPart = mp.toList.groupBy(r => {
          (
            r.country,
            r.company,
            r.business_model,
            r.person_code
          )
        })
        groupedPart.map(r => r._2.head).iterator
      }
    )

    groupedRDD.transform(rdd => rdd.distinct())
  }
}
