package br.natura.domain.application

case class OrdersPedidoRede (
                              nm_pedido : Int,
                              cd_consultora_trad : Int,
                              id_situacao_pedido : Int
                            )



object OrdersPedidoRede {
  def empty(): OrdersPedidoRede =
    OrdersPedidoRede(0,0,0)
}
