package br.natura.domain.application

case class MessageHistoryPayload (

                                 t_pessoa: Boolean,
                                 t_consultora : Boolean,
                                 t_ps_consultora: Boolean,
                                 t_pessoa_relacao_comercial : Boolean,
                                 t_ps_papel_pessoa_candidata : Boolean,
                                 t_ps_papel_pessoa_cn : Boolean,
                                 payload_recived: String
                                 )
