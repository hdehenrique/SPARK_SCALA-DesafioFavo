package br.natura.domain.application

case class Pessoa( cd_pessoa : Int)
