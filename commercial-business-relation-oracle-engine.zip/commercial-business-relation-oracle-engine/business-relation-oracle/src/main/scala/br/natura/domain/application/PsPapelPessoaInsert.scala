package br.natura.domain.application

import java.sql.Timestamp

case class PsPapelPessoaInsert(cd_pessoa : Int,
                               cd_tipo_papel : Int,
                               dt_inicio_papel_pessoa : Timestamp,
                               nm_ciclo_inicio_papel_pessoa  : Int,
                               cd_usuario_atualizacao  : String,
                               dt_ultima_atualizacao : Timestamp,
                               insert : Boolean,
                               update :Boolean)



case class PsPapelPessoaUpdate(cd_pessoa : Int,
                               cd_tipo_papel : Int,
                               dt_termino_papel_pessoa : Timestamp,
                               nm_ciclo_termino_papel_pessoa : Int,
                               cd_motivo_termino_papel: Int,
                               cd_usuario_atualizacao  : String,
                               dt_ultima_atualizacao : Timestamp
                              )


case class PsPapelPessoaSelect(cd_pessoa : Int,
                               cd_tipo_papel : Int,
                               dt_inicio_papel_pessoa : String,
                               dt_termino_papel_pessoa : String
                           )


object PsPapelPessoaSelect {
  def empty(): PsPapelPessoaSelect =
    PsPapelPessoaSelect(0,0," " , " ")
}
