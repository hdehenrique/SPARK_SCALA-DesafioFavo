package br.natura.engine.data

import br.com.natura.handlers.database.Database
import br.natura.app.StreamingApp.ss
import br.natura.domain.application.{PedidoRedeHeader, PedidoRedeItem, PsPapelPessoaInsert}
import org.apache.spark.sql.{Dataset, SparkSession}

class Oracle() extends Database(ss: SparkSession) {
  val tb_t_ps_papel_pessoa = "SISCAD.T_PS_PAPEL_PESSOA"

  def setTPsPapelPessoa(dataset: Dataset[PsPapelPessoaInsert],
                        url: String,
                        user: String,
                        password: String): Unit = {

    val primaryKeyColumns: Seq[String] = Seq("CD_PESSOA","CD_TIPO_PAPEL","DT_INICIO_PAPEL_PESSOA")


    this.writeTable_oracle(dataset, tb_t_ps_papel_pessoa, url, user, password,primaryKeyColumns)
  }




}
