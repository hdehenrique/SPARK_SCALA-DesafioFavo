package br.natura.domain.application

import java.sql.Timestamp

case class PedidoRedeItem (
                            nm_pedido	: Int,
                            nm_item_pedido	: Int,
                            cd_produto	: Int,
                            cd_venda_produto	: Int,
                            qt_item_pedido	: Int,
                            qt_pontos_produto	: Int,
                            vl_unitario_sem_lucratividade	: Double,
                            vl_unitario_tabela	: Double,
                            vl_unitario_final	: Double,
                            vl_desconto_ecommerce	: Double,
                            vl_desconto_cnd	: Double,
                            vl_desconto_natura	: Double,
                            cd_venda_kit	: Option[Int] = None,
                            cd_produto_kit	: Option[Int] = None,
                            qt_item_kit		: Option[Int] = None,
                            cd_forma_pagamento	: String,
                            id_origem_item_pedido	: Int,
                            id_situacao_verificacao_item	: Int,
                            id_estoque_transito	: Int,
                            cd_centro	: Int,
                            cd_promocao		: Option[Int] = None,
                            qt_item_pedido_cortado	: Int,
                            cd_usuario_atualizacao	:Int,
                            ts_ultima_atualizacao : Timestamp,
                            nm_item_externo	:String,
                            id_fornecedor	: Int,
                            qt_solicitada	: Int,
                            cd_ano_mes	: Int,
                            cd_usuario_manutencao	:String,
                            dt_geracao_movimento : Timestamp,
                            ts_primeira_replica : Timestamp,
                            dt_ultima_atualizacao : Timestamp,
                            insert : Boolean
  )