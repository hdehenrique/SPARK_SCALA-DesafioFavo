package br.natura.domain.application

import org.joda.time.DateTime

import java.sql
import java.sql.Timestamp
import java.util.{Date, UUID}

case class PedidoRedeHeader(
                             nm_pedido : Int,
                             cd_consultora_rede :Int,
                             cd_consultora_trad :Int,
                             nm_ciclo_pedido :Int,
                             nm_ciclo_estatistica :Int,
                             vl_total_pedido : Double,
                             qt_ponto_pedido :Int,
                             qt_item_pedido :Int,
                             id_situacao_pedido :Int,
                             id_tipo_pedido :Int,
                             id_tipo_operacao :Int,
                             id_operacao :Int,
                             cd_ano_mes :Int,
                             cd_setor :Int,
                             cd_tipo_estrutura_comercial :Int,
                             cd_estrutura_comercial :Int,
                             dt_estatistica : Timestamp,
                             dt_geracao_movimento : Timestamp,
                             ts_ultima_atualizacao : Timestamp,
                             dt_inicio_digitacao_pedido : sql.Date,
                             dt_recebimento_pedido : Timestamp,
                             dt_alteracao_pedido : Timestamp,
                             dt_finalizacao_pedido : sql.Date,
                             dt_ultima_atualizacao : Timestamp,
                             cd_usuario_atualizacao : String,
                             vl_lucratividade_pedido :Double,
                             ts_primeira_replica :Timestamp,
                             insert :Boolean,
                             update : Boolean

                           )
