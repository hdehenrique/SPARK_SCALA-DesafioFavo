package br.com.natura.engine.data


import java.sql.Connection
import br.com.natura.engine.parser.database.scylla.ScyllaParser
import br.com.natura.handlers.database.ScyllaDBSerializable
import br.natura.domain.application.{OrderItemPedidoRede, OrdersPedidoRede, PSConsultora, Pessoa, PsPapelPessoaSelect}
import br.natura.handlers.database.OracleSerializable
import org.apache.spark.SparkConf

import collection.JavaConverters._
import scala.collection.mutable.ListBuffer


class DataCollectorSerializable(conf: SparkConf) extends Serializable {

  private val scylla = new ScyllaDBSerializable(conf)
  private val oracle = new OracleSerializable



  ///T_PESSOA
  def getTPessoa(consultant: List[Int], conn: Connection): List[Pessoa] = {

    //println("getTPessoa")

    val ordersInDataBase = ListBuffer[Pessoa]()
    val resultOrcale  = oracle.getTPessoa(conn, consultant)

    while (resultOrcale.next) {
      val orderInDataBase = Pessoa(
        cd_pessoa = resultOrcale.getInt("CD_PESSOA")
      )
      ordersInDataBase += orderInDataBase
    }

    if (ordersInDataBase.isEmpty) {
      List(Pessoa(0))
    } else {
      ordersInDataBase.toList
    }


  }


  ///T_PS_CONSULTORA
  def getTPsConsultora(consultant: List[Int], conn: Connection): List[Pessoa] = {

   //println("getTPsConsultora")

    val ordersInDataBase = ListBuffer[Pessoa]()
    val resultOrcale  = oracle.getTPsConsultora(conn, consultant)

    while (resultOrcale.next) {
      val orderInDataBase = Pessoa(
        cd_pessoa = resultOrcale.getInt("CD_PESSOA")
      )
      ordersInDataBase += orderInDataBase
    }

    if (ordersInDataBase.isEmpty) {
      List(Pessoa(0))
    } else {
      ordersInDataBase.toList
    }


  }

  //T_CONSULTORA
  def getConsultora(consultant: List[Int], conn: Connection): List[Pessoa] = {

    //println("getConsultora")

    val ordersInDataBase = ListBuffer[Pessoa]()
    val resultOrcale  = oracle.getTConsultora(conn, consultant)

    while (resultOrcale.next) {
      val orderInDataBase = Pessoa(
        cd_pessoa = resultOrcale.getInt("CD_CONSULTORA")
      )
      ordersInDataBase += orderInDataBase
    }

    if (ordersInDataBase.isEmpty) {
      List(Pessoa(0))
    } else {
      ordersInDataBase.toList
    }


  }

  //T_PESSOA_RELACAO_COMERCIAL
  def getPessoaRelacaoComercial(consultant: List[Int], conn: Connection): List[Pessoa] = {

    //println("getPessoaRelacaoComercial")

    val ordersInDataBase = ListBuffer[Pessoa]()
    val resultOrcale  = oracle.getPessoaRelacaoComercial(conn, consultant)

    while (resultOrcale.next) {
      val orderInDataBase = Pessoa(
        cd_pessoa = resultOrcale.getInt("CD_PESSOA")
      )
      ordersInDataBase += orderInDataBase
    }

    if (ordersInDataBase.isEmpty) {
      List(Pessoa(0))
    } else {
      ordersInDataBase.toList
    }


  }

  def getPsPapelPessoa(consultants: List[Int], conn: Connection): List[PsPapelPessoaSelect] = {

    //println("getPsPapelPessoa")

    val ordersInDataBase = ListBuffer[PsPapelPessoaSelect]()
    val resultOrcale  = oracle.getPsPapelPessoa(conn, consultants)

    while (resultOrcale.next) {
      val orderInDataBase = PsPapelPessoaSelect(
        cd_pessoa = resultOrcale.getInt("CD_PESSOA"),
        cd_tipo_papel = resultOrcale.getInt("CD_TIPO_PAPEL"),
        dt_inicio_papel_pessoa = resultOrcale.getString("DT_INICIO_PAPEL_PESSOA"),
        dt_termino_papel_pessoa = resultOrcale.getString("DT_TERMINO_PAPEL_PESSOA")


      )
      ordersInDataBase += orderInDataBase
    }

    if (ordersInDataBase.isEmpty) {
      List(PsPapelPessoaSelect.empty())
    } else {
      ordersInDataBase.toList
    }


  }

  def getKafkaOffsetControl(engine_id: Int,
                            topicList: List[String])  = {

    scylla.getKafkaOffsetControl(topicList.map(t => {"'" + t + "'"}).mkString(","),engine_id)
      .asScala
      .map(ScyllaParser.parseRowToKafkaProcessedOffSet)
      .toList


  }

  def getCountry()  = {

    scylla.getCountry()
      .asScala
      .map(ScyllaParser.parseRowToCountryCodes)
      .toList


  }

  def getFirstOrderID(country: Int,
                      company_id : Int,
                      business_model : Int,
                      consultant_code : Int,
                      order_cycle: Int
                     )  = {

    scylla.getFirstOrderID(country,company_id,business_model,consultant_code,order_cycle)
      .asScala
      .map(ScyllaParser.parseRowToOrders)
      .toList


  }


}
