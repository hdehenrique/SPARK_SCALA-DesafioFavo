package br.natura.domain.application

import java.sql.Timestamp

case class PessoaRelacaoComercial(cd_consultora : Int,
                                  nm_ciclo_inicio : Int,
                                  cd_tipo_estrutura_comercial : Int,
                                  cd_estrutura_comercial : Int,
                                  cd_tipo_estrutura_segmento : Int,
                                  cd_estrutura_segmento : Int,
                                  cd_usuario_atualizacao : String,
                                  dt_ultima_atualizacao : Timestamp)