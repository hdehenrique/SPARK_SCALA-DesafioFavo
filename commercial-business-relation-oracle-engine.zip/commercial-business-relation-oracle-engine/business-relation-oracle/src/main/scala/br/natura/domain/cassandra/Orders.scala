package br.natura.domain.cassandra

import java.sql.{Timestamp}
import java.util.Date

case class Orders(order_id : Int ,order_points : Int ,order_calculation_date : Date)
