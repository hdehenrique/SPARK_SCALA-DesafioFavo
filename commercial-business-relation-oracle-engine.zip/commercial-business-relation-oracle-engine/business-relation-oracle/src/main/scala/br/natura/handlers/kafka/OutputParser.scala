package br.natura.handlers.kafka

import br.com.natura.domain.cassandra.KafkaProcess
import src.main.scala.br.natura.domain.kafka.MessageRecived

object OutputParser {

  def setJson(message : MessageRecived) = {

    val retry = try { message.kafka_process.retry + 1 }  catch {case _: Exception => 1 }

    val json: String =     s"""{
        "uuid":"${message.uuid}",
        "country":"${message.country}",
        "company":${message.company},
        "business_model":${message.business_model},
        "structure_level":${message.structure_level},
        "structure_code":${message.structure_code},
        "cycle":${message.cycle},
        "person_code":${message.person_code},
        "person_id":"${Option(message.person_id).getOrElse(null)}",
        "business_status_code":${message.business_status_code},
        "function":${message.function},
        "role":${message.role},
        "StartDate":"${message.start_date}",
        "EndDate":${message.end_date},
        "operation":"R",
        "operationDate":"${message.operation_date}",
        "retry":${retry},
        }""".stripMargin

    (json,retry)
  }

}
