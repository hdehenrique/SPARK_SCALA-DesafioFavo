package br.com.natura.handlers.database

import br.com.natura.settings.Settings
import org.apache.spark.sql.{DataFrame, Dataset, SaveMode, SparkSession}

abstract class Database(ss: SparkSession) {

  val format_oracle: String = "jdbc"

  def writeTable_oracle[T](dataset: Dataset[T],
                           tableName: String,
                           url: String,
                           user: String,
                           password: String,
                           primaryKeyColumns: Seq[String],
                           saveMode: SaveMode = SaveMode.Append

                          ): Unit = {
    val options = Map(
      "url" -> url,
      "dbtable" -> tableName,
      "user" -> user,
      "password" -> password,
      "driver" -> "oracle.jdbc.OracleDriver"
    )

    val df = dataset.toDF().drop("insert", "update")
    val dataWithoutDuplicates = df.dropDuplicates(primaryKeyColumns)

    if (!dataWithoutDuplicates.isEmpty) {
      dataWithoutDuplicates
        .coalesce(Settings.oracleNumPartitions)
        .write.format(format_oracle)
        .options(options)
        .mode(saveMode)
        .option("fetchsize", Settings.oracleFetchSize)
        .option("batchsize", Settings.oracleBatchSize)
        .option("numPartitions", Settings.oracleNumPartitions.toString)
        .option("isolationLevel", "READ_COMMITTED")
        .save()
    }
  }

  val format: String = "org.apache.spark.sql.cassandra"

  // TFED-4398
  def writeTableOffSet[T](dataset: Dataset[T], options: Map[String, String], saveMode: SaveMode = SaveMode.Append): Unit = {
    dataset
      .write
      .format(this.format)
      .options(options)
      .mode(saveMode)
      .save()
  }

  def writeTableUsingTTL[T](dataset: Dataset[T], ttl: Int, options: Map[String, String], saveMode: SaveMode = SaveMode.Append): Unit = {
    dataset
      .write
      .format(this.format)
      .options(options)
      .option("spark.cassandra.output.ttl", ttl)
      .mode(saveMode)
      .save()
  }
}
