package src.main.scala.br.natura.handlers.database.connection

import br.com.natura.settings.Settings
import org.apache.commons.dbcp2.BasicDataSource


object Oracle {
  private val maxConnectionAttempts = 3
  private val connectionAttemptDelay = 5000

  private var oracle02: Option[java.sql.Connection] = None
  private var oracle05: Option[java.sql.Connection] = None

  def getOracle02Connection(): java.sql.Connection = {
    if (oracle02.isEmpty || !oracle02.get.isValid(5)) {
      oracle02 = createConnection(Settings.oracle02Url, Settings.oracle02User, Settings.oracle02Pass)
    }
    oracle02.getOrElse(throw new Exception("Failed to obtain Oracle_02 connection."))
  }

  def getOracle05Connection(): java.sql.Connection = {
    if (oracle05.isEmpty || !oracle05.get.isValid(5)) {
      oracle05 = createConnection(Settings.oracle05Url, Settings.oracle05User, Settings.oracle05Pass)
    }
    oracle05.getOrElse(throw new Exception("Failed to obtain Oracle_05 connection."))
  }


  private def createConnection(url: String, user: String, password: String): Option[java.sql.Connection] = {
    var connection: Option[java.sql.Connection] = None
    var attempts = 0

    while (connection.isEmpty && attempts < maxConnectionAttempts) {
      attempts += 1
      try {
        val ds = new BasicDataSource()
        ds.setUrl(url)
        ds.setUsername(user)
        ds.setPassword(password)
        ds.setDefaultQueryTimeout(180)
        connection = Some(ds.getConnection())
      } catch {
        case e: Exception =>
          println(s"Failed to establish connection. Attempt $attempts/${maxConnectionAttempts}. Retrying in ${connectionAttemptDelay / 1000} seconds.")
          Thread.sleep(connectionAttemptDelay)
      }
    }

    connection
  }

}
