package src.main.scala.br.natura.engine

import br.com.natura.engine.data.DataCollectorSerializable

import java.sql.Timestamp
import java.util.Date
import br.com.natura.helpers.Helpers
import br.com.natura.settings.Settings
import br.natura.domain.application.{Consultora, CountryCodes, MessageHistory, MessageHistoryPayload, OrderItemPedidoRede, OrdersPedidoRede, PSConsultora, PedidoRedeHeader, PedidoRedeItem, Pessoa, PessoaRelacaoComercial, PsPapelPessoaInsert, PsPapelPessoaSelect, PsPapelPessoaUpdate}
import com.google.gson.Gson
import org.apache.spark.SparkConf
import org.joda.time.DateTime
import src.main.scala.br.natura.domain.kafka.MessageRecived

class EngineSerializable(conf: SparkConf) extends Serializable {


  def processBusinessRelation(relation: MessageRecived, info : (List[Pessoa], List[Pessoa], List[Pessoa], List[PsPapelPessoaSelect], List[Pessoa]),countryCodes: List[CountryCodes]) = {

    //println("processando " + relation)
    val dc = new DataCollectorSerializable(conf)

    val countryCode = try { countryCodes.filter(c => c.country_iso == relation.country).head.country } catch {case _: Exception => 1 }

    //BUSCO TODOS DOS PEDIDOS DA CONSULTORA NO CICLO
    val orders = dc.getFirstOrderID(countryCode,relation.company,relation.business_model,relation.person_code,relation.cycle)
    // VERIFICO SE POSSUI ALGUM PEDIDO CANCEDO
    val cancelledOrder = orders.filter(_.order_points < 0).map(_.order_id)
    //ENCONTRO O PRIMEIRO PEDIDO FATURADO(NÃO CANCELADO) DA CONSULTORA NO CICLO
    val firstOrder = try {orders.filter(o => !cancelledOrder.contains(o.order_id)).sortBy(x => x.order_calculation_date).head.order_id } catch {case _: Exception => 0 }

   ///VALIDA SE A CN EXISTE NA T_PS_CONSULTORA
    val checkTable_t_ps_consultora =  if ( info._1.filter(_.cd_pessoa == relation.person_code).size  > 0) true else false
    ///VALIDA SE A CN EXISTE NA T_CONSULTORA
    val checkTable_t_consultora = if (info._2.filter(_.cd_pessoa == relation.person_code).size > 0) true else false
    ///VALIDA SE A CN EXISTE NA T_PESSOA_RELACAO_COMERCIAL
    val checkTable_t_pessoa_relaca_comercial = if (info._3.filter(_.cd_pessoa == relation.person_code).size > 0) true else false
    ///VALIDA SE A CN EXISTE NA T_PS_PAPEL_PESSOA COM PAPEL 4 NÃO FECHADO
    val checkTable_t_ps_papel_pessoa_candidate = if (info._4.filter(p => p.cd_pessoa == relation.person_code && p.cd_tipo_papel == 4 && p.dt_termino_papel_pessoa == null).size > 0) true else false
    ///VALIDA SE A CN EXISTE NA T_PS_PAPEL_PESSOA COM PAPEL 2 NÃO FECHADO
    val checkTable_t_ps_papel_pessoa_consultant = if (info._4.filter(p => p.cd_pessoa == relation.person_code && p.cd_tipo_papel == 2 && p.dt_termino_papel_pessoa == null ).size > 0) true else false
    ///VALIDA SE A CN EXISTE NA T_PESSOA
    val checkTable_t_pessoa = if (info._5.filter(_.cd_pessoa == relation.person_code).size > 0 ) true else false

    val t_ps_consultora_update =  PSConsultora(cd_pessoa = relation.person_code,
                                              id_tipo_gerado_pedido = 1,
                                              cd_usuario_atualizacao = Settings.cdUserUpdate,
                                              dt_ultima_atualizacao =  new Timestamp(new java.util.Date().getTime))

    val t_consultora_update = Consultora(cd_consultora = relation.person_code,
      id_tipo_gerador_pedido = 1,
      nm_ciclo_inicio = relation.cycle,
      nm_ciclo_inicio_segmento = relation.cycle,
      dt_inicio_cn  = new Timestamp(new java.util.Date().getTime),
      dt_inicio_segmento  = new Timestamp(new java.util.Date().getTime),
      dt_primeiro_pedido_cn = new Timestamp(new java.util.Date().getTime),
      nm_primeiro_pedido_cn  = firstOrder,
      nm_primeiro_pedido_segmento = firstOrder,
      cd_tipo_estrutura_comercial = relation.structure_level,
      cd_estrutura_comercial = relation.structure_code,
      cd_usuario_atualizacao = Settings.cdUserUpdate,
      dt_ultima_atualizacao = new Timestamp(new java.util.Date().getTime))

    //println("t_consultora_update " +t_consultora_update)


    val t_pessoa_relaca_comercial_update = PessoaRelacaoComercial(cd_consultora = relation.person_code,
      nm_ciclo_inicio = relation.cycle,
      cd_tipo_estrutura_comercial = relation.structure_level,
      cd_estrutura_comercial = relation.structure_code,
      cd_tipo_estrutura_segmento = relation.structure_level,
      cd_estrutura_segmento = relation.structure_code,
      cd_usuario_atualizacao = Settings.cdUserUpdate,
      dt_ultima_atualizacao = new Timestamp(new java.util.Date().getTime))


    //println("t_pessoa_relaca_comercial_update " +t_pessoa_relaca_comercial_update)

    val t_ps_papel_pessoa_update =  PsPapelPessoaUpdate(cd_pessoa = relation.person_code,
      cd_tipo_papel  = 4,
      dt_termino_papel_pessoa  = new Timestamp(new java.util.Date().getTime),
      nm_ciclo_termino_papel_pessoa = relation.cycle,
      cd_motivo_termino_papel = 12 ,
      cd_usuario_atualizacao  = Settings.cdUserUpdate,
      dt_ultima_atualizacao =new Timestamp(new java.util.Date().getTime)
    )


    //SOMENTE INSERE SE A PESSOA JÁ EXISTE NA T_PESSOA E NÃO POSSUI UM PAPEL DE CN JÁ ABERTO
    val insert_papel_pessoa = if (checkTable_t_pessoa == true && checkTable_t_ps_papel_pessoa_consultant == false ) true else false
    ///SE JÁ EXISTIR UM PAPEL DE CN ABERTO EU ATUALIZO O CICLO E DATA DE ABERTURA
    val update_papel_pessoa = if (checkTable_t_pessoa == true && checkTable_t_ps_papel_pessoa_consultant == true ) true else false

//    println("checkTable_t_pessoa " + checkTable_t_pessoa)
//    println("checkTable_t_ps_papel_pessoa_consultant " + checkTable_t_ps_papel_pessoa_consultant)
//    println("insert_papel_pessoa " + insert_papel_pessoa)
//    println("update_papel_pessoa " + update_papel_pessoa)
//    println("  ")

    val t_ps_papel_pessoa_insert =  PsPapelPessoaInsert(
      cd_pessoa = relation.person_code,
      cd_tipo_papel = 2,
      dt_inicio_papel_pessoa = new Timestamp(new java.util.Date().getTime),
      nm_ciclo_inicio_papel_pessoa  = relation.cycle,
      cd_usuario_atualizacao  = Settings.cdUserUpdate,
      dt_ultima_atualizacao = new Timestamp(new java.util.Date().getTime),
      insert = insert_papel_pessoa,
      update = update_papel_pessoa
    )


    val log = MessageHistoryPayload (
      payload_recived = relation.kafka_process.message,
      t_pessoa = checkTable_t_pessoa ,
      t_consultora = checkTable_t_consultora ,
      t_ps_consultora = checkTable_t_ps_consultora,
      t_pessoa_relacao_comercial = checkTable_t_pessoa_relaca_comercial,
      t_ps_papel_pessoa_candidata = checkTable_t_ps_papel_pessoa_candidate,
      t_ps_papel_pessoa_cn = checkTable_t_ps_papel_pessoa_consultant
    )

    val messageHistory = MessageHistory(engine_id = Settings.engine_id,
      history_date = new DateTime().withZone(Settings.zoneUTC),
      hour_range = getHourRange(new DateTime().withZone(Settings.zoneUTC)),
      uuid = relation.person_id,
      last_update = new DateTime().withZone(Settings.zoneUTC),
      payload = setJsonLog(log))



    (t_ps_consultora_update,t_consultora_update,t_pessoa_relaca_comercial_update,t_ps_papel_pessoa_update,t_ps_papel_pessoa_insert,relation,checkTable_t_pessoa,messageHistory)
  }


  def getHourRange(hourRange: DateTime): Int = {

    hourRange.getHourOfDay
  }

  def setJsonLog(log : MessageHistoryPayload) = {

    new Gson().toJson(log)
  }






}
