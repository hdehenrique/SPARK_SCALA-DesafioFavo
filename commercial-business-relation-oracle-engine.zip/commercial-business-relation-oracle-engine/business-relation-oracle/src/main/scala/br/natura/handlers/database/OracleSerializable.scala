package br.natura.handlers.database
import java.sql.{Connection, ResultSet}

class OracleSerializable extends Serializable {

  def getTPessoa(conn: Connection, consultants: List[Int]): ResultSet = {
    val statement =
      s"""
         |SELECT
         |CD_PESSOA
         |FROM
         |SISCAD.T_PESSOA
         |WHERE
         |CD_PESSOA in (${consultants.mkString(",")})
         |""".stripMargin

    //        println("\n--getPedidoRede: \n" + statement)
    //        println("=" * 100)
    val query = conn.prepareStatement(statement, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE)
    query.executeQuery()

  }

  def getTPsConsultora(conn: Connection, consultants: List[Int]): ResultSet = {
    val statement =
      s"""
         |SELECT
         |CD_PESSOA
         |FROM
         |SISCAD.T_PS_CONSULTORA
         |WHERE
         |CD_PESSOA in (${consultants.mkString(",")})
         |""".stripMargin

//        println("\n--getPedidoRede: \n" + statement)
//        println("=" * 100)
    val query = conn.prepareStatement(statement, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE)
    query.executeQuery()

  }

  def getTConsultora(conn: Connection, consultants: List[Int]  ): ResultSet = {
    val statement =
      s"""
         |SELECT
         |CD_CONSULTORA
         |FROM
         |SISESTAT.T_CONSULTORA
         |WHERE
         |CD_CONSULTORA in (${consultants.mkString(",")})
         |""".stripMargin

//    println("\n--getItemPedidoRede: \n" + statement)
//    println("=" * 100)
    val query = conn.prepareStatement(statement, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE)
    query.executeQuery()

  }

  def getPessoaRelacaoComercial(conn: Connection, consultants: List[Int] ): ResultSet = {

    val statement =
      s"""
         |SELECT
         |CD_PESSOA
         |FROM
         |SISCAD.T_PESSOA_RELACAO_COMERCIAL
         |WHERE
         |CD_PESSOA in (${consultants.mkString(",")})
         |""".stripMargin



//        println("\n--getItemPedidoRede: \n" + statement)
//        println("=" * 100)
    val query = conn.prepareStatement(statement, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE)
    query.executeQuery()

  }

  def getPsPapelPessoa(conn: Connection, consultants: List[Int] ): ResultSet = {
    val statement =
      s"""
         |SELECT
         |CD_PESSOA,
         |CD_TIPO_PAPEL,
         |DT_INICIO_PAPEL_PESSOA,
         |DT_TERMINO_PAPEL_PESSOA
         |FROM
         |SISCAD.T_PS_PAPEL_PESSOA
         |WHERE
         |CD_PESSOA in (${consultants.mkString(",")})
         |""".stripMargin

    //        println("\n--getItemPedidoRede: \n" + statement)
    //        println("=" * 100)
    val query = conn.prepareStatement(statement, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE)
    query.executeQuery()

  }

}
