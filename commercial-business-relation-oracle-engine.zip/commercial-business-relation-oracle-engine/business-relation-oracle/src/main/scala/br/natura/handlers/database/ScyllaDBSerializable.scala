package br.com.natura.handlers.database


import com.datastax.driver.core.{ResultSet}
import com.datastax.spark.connector.cql.CassandraConnector
import org.apache.spark.SparkConf
class ScyllaDBSerializable(config: SparkConf) extends Serializable {

  val connector: CassandraConnector = CassandraConnector(config)
  val ksSpec = "performance"
  val kafkaOffsetControl_Table: String = "kafka_offset_control"
  val country_codes_table = "country_codes"
  val orders_table = "consultant_orders"



  def getKafkaOffsetControl(topic: String,
                            engine_id: Int
                           ): ResultSet = {


    val table = ksSpec + "." + kafkaOffsetControl_Table
    connector.withSessionDo(s => {
      s.execute(
        s"SELECT topic,partition,offset FROM $table " +
          s"WHERE topic in ($topic) "+
          s"AND engine_id = $engine_id "
      )
    })
  }

  def getCountry( ): ResultSet = {


    val table = ksSpec + "." + country_codes_table
    connector.withSessionDo(s => {
      s.execute(
        s"SELECT country,country_iso,country_name FROM $table "
      )
    })
  }

  def getFirstOrderID(country: Int,
                      company_id : Int,
                      business_model : Int,
                      consultant_code : Int,
                      order_cycle: Int
                           ): ResultSet = {


    val table = ksSpec + "." + orders_table
    connector.withSessionDo(s => {
      s.execute(
        s"SELECT order_id,order_points,order_calculation_date FROM $table " +
          s"WHERE country =  $country "+
          s"AND company_id = $company_id " +
          s"AND business_model = $business_model " +
          s"AND consultant_code = $consultant_code " +
          s"AND order_cycle = $order_cycle "
      )
    })
  }


}
