package br.natura.domain.application
import java.sql.Timestamp

case class Consultora(cd_consultora : Int,
                      id_tipo_gerador_pedido : Int,
                      nm_ciclo_inicio : Int,
                      nm_ciclo_inicio_segmento : Int,
                      dt_inicio_cn : Timestamp,
                      dt_inicio_segmento : Timestamp,
                      dt_primeiro_pedido_cn : Timestamp,
                      nm_primeiro_pedido_cn : Int,
                      nm_primeiro_pedido_segmento : Int,
                      cd_tipo_estrutura_comercial : Int,
                      cd_estrutura_comercial : Int,
                      cd_usuario_atualizacao : String,
                      dt_ultima_atualizacao : Timestamp)
