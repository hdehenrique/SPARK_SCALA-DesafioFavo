package br.com.natura.handlers.database

import br.com.natura.domain.cassandra._
import br.natura.app.StreamingApp.ss
import br.natura.domain.application.MessageHistory
import br.natura.handlers.database.{Helpers}
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Dataset, SparkSession}
import com.datastax.spark.connector._
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD



class ScyllaWrite(sparkContext: SparkContext) extends Database(ss) {
//  import ss.implicits._

  val ksSpec = "performance"

  val kafkaOffsetControl_Table: String = "kafka_offset_control"
  val messageHistory_Table: String = "message_history"

  val kafkaOffsetControl: Map[String, String] = Map("table" ->  kafkaOffsetControl_Table, "keyspace" -> ksSpec)
  val messageHistory: Map[String, String] = Map("table" ->  messageHistory_Table, "keyspace" -> ksSpec)


  def saveTokafkaOffsetControl(dataset: Dataset[KafkaProcessToRecord], usingTtl: Int = -1): Unit = {
    if (usingTtl == -1) {
      this.writeTableOffSet(dataset, kafkaOffsetControl)
    }
    else {
      this.writeTableUsingTTL(dataset, usingTtl, kafkaOffsetControl)
    }

  }

  def saveToMessageHistory(collection: RDD[MessageHistory]): Unit = {
    try {
      val columnNames = Helpers.getAsColumnNamesFromClass[MessageHistory]
      collection.saveToCassandra(ksSpec, messageHistory_Table, columns = columnNames)
    } catch {
    case _: Exception => println("Erro na gravação da message history")
    }
  }


}
