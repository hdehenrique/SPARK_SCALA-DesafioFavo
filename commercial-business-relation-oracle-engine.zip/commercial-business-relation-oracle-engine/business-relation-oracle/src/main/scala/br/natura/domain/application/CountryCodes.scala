package br.natura.domain.application

case class CountryCodes (country : Int,country_iso : String,country_name : String)