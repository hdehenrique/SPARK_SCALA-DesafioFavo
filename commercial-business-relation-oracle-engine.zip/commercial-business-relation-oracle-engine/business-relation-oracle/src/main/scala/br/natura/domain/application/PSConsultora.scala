package br.natura.domain.application

import java.sql.Timestamp

case class PSConsultora(cd_pessoa : Int,
                        id_tipo_gerado_pedido : Int,
                        cd_usuario_atualizacao : String,
                        dt_ultima_atualizacao : Timestamp)
