package br.natura.engine.parser.kafka

import br.com.natura.domain.cassandra.{KafkaProcess}
import com.mongodb.util.JSON
import com.mongodb.{BasicDBList, DBObject}
import org.apache.kafka.clients.consumer.ConsumerRecord
import src.main.scala.br.natura.domain.kafka.{MessageRecived, Products}

import java.sql.Timestamp
import java.util.{Date, UUID}



object Message {
  def processPartition(messages: Iterator[ConsumerRecord[String, String]]): Iterator[(MessageRecived)] = {
    messages.map(m => Message.parseCalculateStructure(m.value(),m.topic(),m.partition(),m.offset()))
  }

  def parseCalculateStructure(message: String,topic : String, partition : Int, offset : Long): MessageRecived = {

  try {

    val relation: DBObject = JSON.parse(message).asInstanceOf[DBObject]
    val retry = try {relation.get("retry").asInstanceOf[Number].intValue() } catch {case _: Exception => 0 }
     //println(">>>>>>>>>>>>>>>>>>>> RECEBENDO " + relation.toString)


        MessageRecived(
          country = relation.get("country").asInstanceOf[String],
          uuid = relation.get("uuid").asInstanceOf[String],
          business_model = relation.get("business_model").asInstanceOf[Number].intValue(),
          company = relation.get("company").asInstanceOf[Number].intValue(),
          structure_level = relation.get("structure_level").asInstanceOf[Number].intValue(),
          structure_code = relation.get("structure_code").asInstanceOf[Number].intValue(),
          cycle = relation.get("cycle").asInstanceOf[Number].intValue(),
          person_code = relation.get("person_code").asInstanceOf[Number].intValue(),
          person_id =  relation.get("person_id").asInstanceOf[String],
          business_status_code = relation.get("business_status_code").asInstanceOf[Number].intValue(),
          function = try {relation.get("function").asInstanceOf[Number].intValue() } catch {case _: Exception => 0}, ///NAO USA
          role = relation.get("role").asInstanceOf[Number].intValue(), ///NAO USA
          start_date = relation.get("StartDate").asInstanceOf[String], ///NAO USA
          end_date = relation.get("EndDate").asInstanceOf[String], ///NAO USA
          operation = relation.get("operation").asInstanceOf[String],
          operation_date =relation.get("operationDate").asInstanceOf[String],///NAO USA
          kafka_process = KafkaProcess(topic,partition,offset,message,retry)
        )

  } catch {
      case _: Exception =>
        MessageRecived.emputy(message)
    }
  }
}
