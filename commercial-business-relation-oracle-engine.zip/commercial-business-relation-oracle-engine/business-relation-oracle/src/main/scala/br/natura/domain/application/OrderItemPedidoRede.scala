package br.natura.domain.application

case class OrderItemPedidoRede (
    nm_pedido : Int,
    nm_item_pedido : Int,
    cd_produto : Int

                               )


object OrderItemPedidoRede {
  def empty(): OrderItemPedidoRede =
    OrderItemPedidoRede(0,0,0)
}
