package br.natura.domain.application

import org.joda.time.DateTime

case class MessageHistory(  engine_id: Int,
                            history_date: DateTime,
                            hour_range: Int,
                            uuid: String,
                            last_update: DateTime,
                            payload: String)
