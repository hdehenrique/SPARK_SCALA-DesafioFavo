package br.natura.engine.data

import br.natura.domain.application.{Consultora, PSConsultora, PedidoRedeHeader, PessoaRelacaoComercial, PsPapelPessoaInsert, PsPapelPessoaUpdate}

import java.sql.{Connection, PreparedStatement}

class Updater() extends Serializable {

  ///////////T_PS_CONSULTORA
  def updateTPsConsultora(connection: Connection, consultant: PSConsultora): Unit = {
    val updateColumns: List[String] = {

      var columns: List[String] = List(
        "ID_TIPO_GERADOR_PEDIDO = ?",
        "CD_USUARIO_ATUALIZACAO = ?",
        "DT_ULTIMA_ATUALIZACAO = ? "
      )

      columns
    }

    val updateSQL: String =
      s"""update SISCAD.T_PS_CONSULTORA
         |set
         |   ${updateColumns.mkString(",\n   ")}
         |where CD_PESSOA = ?
         |""".stripMargin

   // println("updateTPsConsultora " + updateSQL)

    updateTPsConsultoraWithConnection(updateSQL, connection, consultant)
  }
  private def updateTPsConsultoraWithConnection(queryTable: String, connection: Connection, consultant: PSConsultora): Unit = {
    var preparedStatement: PreparedStatement = null

    try {
      preparedStatement = connection.prepareStatement(queryTable)
      preparedStatement.setInt(1, consultant.id_tipo_gerado_pedido)
      preparedStatement.setString(2, consultant.cd_usuario_atualizacao)
      preparedStatement.setTimestamp(3, consultant.dt_ultima_atualizacao)
      preparedStatement.setInt(4, consultant.cd_pessoa)

      preparedStatement.execute()

    } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      if (preparedStatement != null) {
        preparedStatement.close()
      }
    }
  }

  /////////////////////////T_CONSULTORA
  def updateTConsultora(connection: Connection, consultant: Consultora): Unit = {
    val updateColumns: List[String] = {

      var columns: List[String] = List(
        "ID_TIPO_GERADOR_PEDIDO = ?",
        "NM_CICLO_INICIO = ?",
        "NM_CICLO_INICIO_SEGMENTO = ? ",
        "DT_INICIO_CN = ? ",
        "DT_INICIO_SEGMENTO = ? ",
        "DT_PRIMEIRO_PEDIDO_CN = ? ",
        "NM_PRIMEIRO_PEDIDO_CN = ? ",
        "NM_PRIMEIRO_PEDIDO_SEGMENTO = ? ",
        "CD_TIPO_ESTRUTURA_COMERCIAL = ? ",
        "CD_ESTRUTURA_COMERCIAL = ? ",
        "DT_ULTIMA_ATUALIZACAO = ? "
      )

      columns
    }

    val updateSQL: String =
      s"""update SISESTAT.T_CONSULTORA
         |set
         |   ${updateColumns.mkString(",\n   ")}
         |where CD_CONSULTORA = ?
         |""".stripMargin

   // println("updateTConsultora " + updateSQL)

    updateTConsultoraWithConnection(updateSQL, connection, consultant)
  }
  private def updateTConsultoraWithConnection(queryTable: String, connection: Connection, consultant: Consultora): Unit = {
    var preparedStatement: PreparedStatement = null

    try {
      preparedStatement = connection.prepareStatement(queryTable)
      preparedStatement.setInt(1, consultant.id_tipo_gerador_pedido)
      preparedStatement.setInt(2, consultant.nm_ciclo_inicio)
      preparedStatement.setInt(3, consultant.nm_ciclo_inicio_segmento)
      preparedStatement.setTimestamp(4, consultant.dt_inicio_cn)
      preparedStatement.setTimestamp(5, consultant.dt_inicio_segmento)
      preparedStatement.setTimestamp(6, consultant.dt_primeiro_pedido_cn)
      preparedStatement.setInt(7, consultant.nm_primeiro_pedido_cn)
      preparedStatement.setInt(8, consultant.nm_primeiro_pedido_segmento)
      preparedStatement.setInt(9, consultant.cd_tipo_estrutura_comercial)
      preparedStatement.setInt(10, consultant.cd_estrutura_comercial)
      preparedStatement.setTimestamp(11, consultant.dt_ultima_atualizacao)
      preparedStatement.setInt(12, consultant.cd_consultora)

      preparedStatement.execute()

    } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      if (preparedStatement != null) {
        preparedStatement.close()
      }
    }
  }

  /////////////////////////T_PESSOA_RELACAO_COMERCIAL
  def updateTPessoaRelacaoComercial(connection: Connection, consultant: PessoaRelacaoComercial): Unit = {
    val updateColumns: List[String] = {

      var columns: List[String] = List(
        "CD_TIPO_ESTRUTURA_COMERCIAL = ? ",
        "CD_ESTRUTURA_COMERCIAL = ? ",
        "CD_TIPO_ESTRUTURA_SEGMENTO = ? ",
        "CD_ESTRUTURA_SEGMENTO = ? ",
        "CD_USUARIO_ATUALIZACAO = ? ",
        "DT_ULTIMA_ATUALIZACAO = ? "
      )

      columns
    }

    val updateSQL: String =
      s"""update SISCAD.T_PESSOA_RELACAO_COMERCIAL
         |set
         |   ${updateColumns.mkString(",\n   ")}
         |where CD_PESSOA = ?
         |""".stripMargin

   // println("updateTPessoaRelacaoComercial " + updateSQL)


    updateTPessoaRelacaoComercialWithConnection(updateSQL, connection, consultant)
  }
  private def updateTPessoaRelacaoComercialWithConnection(queryTable: String, connection: Connection, consultant: PessoaRelacaoComercial): Unit = {
    var preparedStatement: PreparedStatement = null

    try {
      preparedStatement = connection.prepareStatement(queryTable)
      preparedStatement.setInt(1, consultant.cd_tipo_estrutura_comercial)
      preparedStatement.setInt(2, consultant.cd_estrutura_comercial)
      preparedStatement.setInt(3, consultant.cd_tipo_estrutura_segmento)
      preparedStatement.setInt(4, consultant.cd_estrutura_segmento)
      preparedStatement.setString(5, consultant.cd_usuario_atualizacao)
      preparedStatement.setTimestamp(6, consultant.dt_ultima_atualizacao)
      preparedStatement.setInt(7, consultant.cd_consultora)

      preparedStatement.execute()

    } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      if (preparedStatement != null) {
        preparedStatement.close()
      }
    }
  }

  /////////////////////////T_PS_PAPEL_PESSOA FECHA PAPEL 2
  def updateTPsPapelPessoaCandidate(connection: Connection, consultant: PsPapelPessoaUpdate): Unit = {
    val updateColumns: List[String] = {

      var columns: List[String] = List(
        "DT_TERMINO_PAPEL_PESSOA = ? ",
        "NM_CICLO_TERMINO_PAPEL_PESSOA = ? ",
        "CD_MOTIVO_TERMINO_PAPEL = ? ",
        "CD_USUARIO_ATUALIZACAO = ? ",
        "DT_ULTIMA_ATUALIZACAO = ? "
      )

      columns
    }

    val updateSQL: String =
      s"""update SISCAD.T_PS_PAPEL_PESSOA
         |set
         |   ${updateColumns.mkString(",\n   ")}
         |where CD_PESSOA = ? AND CD_TIPO_PAPEL = 4 AND DT_TERMINO_PAPEL_PESSOA IS NULL
         |""".stripMargin

   // println("updateTPsPapelPessoaCandidate " + updateSQL )

    updateTPsPapelPessoaCandidateWithConnection(updateSQL, connection, consultant)
  }
  private def updateTPsPapelPessoaCandidateWithConnection(queryTable: String, connection: Connection, consultant: PsPapelPessoaUpdate): Unit = {
    var preparedStatement: PreparedStatement = null

    try {
      preparedStatement = connection.prepareStatement(queryTable)
      preparedStatement.setTimestamp(1, consultant.dt_termino_papel_pessoa)
      preparedStatement.setInt(2, consultant.nm_ciclo_termino_papel_pessoa)
      preparedStatement.setInt(3, consultant.cd_motivo_termino_papel)
      preparedStatement.setString(4, consultant.cd_usuario_atualizacao)
      preparedStatement.setTimestamp(5, consultant.dt_ultima_atualizacao)
      preparedStatement.setInt(6, consultant.cd_pessoa)

      preparedStatement.execute()

    } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      if (preparedStatement != null) {
        preparedStatement.close()
      }
    }
  }

  /////////////////////////T_PS_PAPEL_PESSOA ATUALIZA DATA DE INICIO DO PAPEL 2
  def updateTPsPapelPessoaCn(connection: Connection, consultant: PsPapelPessoaInsert): Unit = {
    val updateColumns: List[String] = {

      var columns: List[String] = List(
        "DT_INICIO_PAPEL_PESSOA = ? ",
        "NM_CICLO_INICIO_PAPEL_PESSOA = ? ",
        "CD_USUARIO_ATUALIZACAO = ? ",
        "DT_ULTIMA_ATUALIZACAO = ? "
      )

      columns
    }

    val updateSQL: String =
      s"""update SISCAD.T_PS_PAPEL_PESSOA
         |set
         |   ${updateColumns.mkString(",\n   ")}
         |where CD_PESSOA = ? AND CD_TIPO_PAPEL = 2 AND DT_TERMINO_PAPEL_PESSOA IS NULL
         |""".stripMargin


    updateTPsPapelPessoaCnWithConnection(updateSQL, connection, consultant)
  }
  private def updateTPsPapelPessoaCnWithConnection(queryTable: String, connection: Connection, consultant: PsPapelPessoaInsert): Unit = {
    var preparedStatement: PreparedStatement = null

    try {
      preparedStatement = connection.prepareStatement(queryTable)
      preparedStatement.setTimestamp(1, consultant.dt_inicio_papel_pessoa)
      preparedStatement.setInt(2, consultant.nm_ciclo_inicio_papel_pessoa)
      preparedStatement.setString(3, consultant.cd_usuario_atualizacao)
      preparedStatement.setTimestamp(4, consultant.dt_ultima_atualizacao)
      preparedStatement.setInt(5, consultant.cd_pessoa)

      preparedStatement.execute()

    } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      if (preparedStatement != null) {
        preparedStatement.close()
      }
    }
  }

}
