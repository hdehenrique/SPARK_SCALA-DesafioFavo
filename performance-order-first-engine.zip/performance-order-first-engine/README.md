#PERFORMANCE

Motor de apuração do primeiro pedido da consultora no ciclo.

## Buildar o motor em spark 2.4.7
acessar a documentação no [Confluence](https://natura.atlassian.net/wiki/spaces/GCP/pages/3048505416/Build+Spark+2.4.7+com+Scylla+Driver)
