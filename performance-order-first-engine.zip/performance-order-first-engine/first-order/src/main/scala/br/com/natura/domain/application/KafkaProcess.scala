package br.com.natura.domain.application

import java.sql.Timestamp

case class KafkaProcess(topic : String, partition : Int, offset : Long)
case class KafkaProcessedOffSet(topic : String, partition : Int, offset : Long)
case class KafkaProcessToRecord(topic : String, engine_id: Int, partition : Int, offset : Long , process_data : Timestamp)