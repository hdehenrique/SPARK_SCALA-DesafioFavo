package br.com.natura.domain.application

import java.util.UUID

import br.com.natura.settings.Settings
import org.joda.time.DateTime

case class OrdersToProcess(uuid: String,
                           company_id: Int,
                           country: Int,
                           countryISO: String,
                           orderUUID: Option[UUID],
                           system_source: Int,
                           business_model: Int,
                           order_id: Int,
                           order_number: String,
                           consultant_code: Int,
                           order_cycle: Int,
                           structure_level: Int,
                           structure_code: Int,
                           channel_id: Int,
                           order_status: Int,
                           order_calculation_date: DateTime,
                           order_date: String,
                           order_itens: Int,
                           order_points: Int,
                           order_value: Double,
                           structure_tree: String,
                           first_order_cycle: Boolean,
                           status_activity: Int,
                           person_status: Int,
                           engine_id: Int,
                           jason_received: String,
                           initial: Int,
                           valid: Boolean)


object OrdersToProcess {
  def empty(): OrdersToProcess = {
    OrdersToProcess(
      uuid = UUID.randomUUID().toString,
      company_id = -1,
      country = -1,
      countryISO = " ",
      orderUUID = None,
      system_source = -1,
      business_model = -1,
      order_id = -1,
      order_number = " ",
      consultant_code = 0,
      order_cycle = 0,
      structure_level = 0,
      structure_code = 0,
      channel_id = 0,
      order_status = 0,
      order_calculation_date = new DateTime().withZone(Settings.zoneUTC),
      order_date = " ",
      order_itens = 0,
      order_points = 0,
      order_value = 0,
      structure_tree = " ",
      first_order_cycle = false,
      status_activity = 0,
      person_status = 0,
      engine_id = 0,
      jason_received = " ",
      initial = 1,
      valid = false
    )
  }
}