package br.com.natura.handlers.database.connection

import br.com.natura.settings.Settings
import org.apache.commons.dbcp2.BasicDataSource

object PostgreSQL {
  val driver = "org.postgresql.Driver"

  def brm() = {
    val ds = new BasicDataSource()

    ds.setDriverClassName(this.driver)
    ds.setUrl(Settings.postgresql_brm_url)
    ds.setUsername(Settings.postgresql_brm_user)
    ds.setPassword(Settings.postgresql_brm_pass)
    ds.setMaxTotal(Settings.max_total)
    ds.setMaxIdle(Settings.max_idle)


    ds
  }

  def cmm() = {
    val ds = new BasicDataSource()

    ds.setDriverClassName(this.driver)
    ds.setUrl(Settings.postgresql_cmm_url)
    ds.setUsername(Settings.postgresql_cmm_user)
    ds.setPassword(Settings.postgresql_cmm_pass)

    ds
  }
}