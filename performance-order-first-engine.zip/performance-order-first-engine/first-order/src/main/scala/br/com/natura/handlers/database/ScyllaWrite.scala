package br.com.natura.handlers.database

import br.com.natura.domain.application.KafkaProcessToRecord
import br.com.natura.domain.cassandra._
import com.datastax.spark.connector.SomeColumns
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Dataset, SparkSession}
import com.datastax.spark.connector._
import com.datastax.spark.connector.writer.WriteConf

class ScyllaWrite(ss: SparkSession) extends Database(ss) {

  val ksSpec = "performance"

  private val tables = Map(
    "messageHistory" -> "message_history",
    "consultantOrders" -> "consultant_orders",
    "consultantOrdersId" -> "consultant_orders_id",
    "structureOrders" -> "structure_orders",
    "structureOrdersId" -> "structure_orders_id",
    "orders" -> "orders",
    "ordersId" -> "orders_id",
    "orderHistory" -> "order_history",
    "orderIdHistory" -> "order_id_history",
    "kafkaOffsetControl" -> "kafka_offset_control"
  )

  val messageHistory: Map[String, String] = Map("table" -> tables("messageHistory"), "keyspace" -> ksSpec)
  private val kafkaOffsetControl: Map[String, String] = Map("table" -> tables("kafkaOffsetControl"), "keyspace" -> ksSpec)

  override val format: String = "org.apache.spark.sql.cassandra"

  def setMessageHistory(collection: RDD[MessageHistory]): Unit = {
    collection.saveToCassandra(ksSpec, tables("messageHistory"))
  }

  def saveFirstOrder(collection: RDD[Orders], columns: SomeColumns): Unit = {

    List(
        tables("orders"),
        tables("consultantOrders"),
        tables("structureOrders")
      ).foreach(table => collection.saveToCassandra(ksSpec, table, columns))
  }

  def saveFirstOrderUUID(collection: RDD[OrdersUUID], columns: SomeColumns): Unit = {

    List(
      tables("ordersId"),
      tables("consultantOrdersId"),
      tables("structureOrdersId")
    ).foreach(table => collection.saveToCassandra(ksSpec, table, columns))
  }

  def saveToOrderHistory(collection: RDD[OrderHistory], columns: SomeColumns): Unit = {
    collection.saveToCassandra(ksSpec, tables("orderHistory"), columns, writeConf = WriteConf(ignoreNulls = true))
  }

  def saveToOrderHistoryUUID(collection: RDD[OrderHistoryUUID], columns: SomeColumns): Unit = {
    collection.saveToCassandra(ksSpec, tables("orderIdHistory"), columns, writeConf = WriteConf(ignoreNulls = true))
  }

  def saveToKafkaOffsetControl(dataset: Dataset[KafkaProcessToRecord]): Unit = {
    this.writeTable(dataset, kafkaOffsetControl)
  }
}
