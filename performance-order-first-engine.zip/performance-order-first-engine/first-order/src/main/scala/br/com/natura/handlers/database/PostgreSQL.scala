package br.com.natura.handlers.database

import java.util.Properties

import br.com.natura.domain.cassandra.parameterValues
import br.com.natura.domain.postgresql.StructureChildren
import br.com.natura.settings._
import org.apache.spark.sql.{Dataset, SparkSession}

class PostgreSQL(ss: SparkSession) extends Database(ss) {
  import ss.implicits._

  override val format: String = "jdbc"
  val propBRM = new java.util.Properties
  propBRM.setProperty("driver", "org.postgresql.Driver")
  propBRM.setProperty("user", Settings.postgresql_brm_user)
  propBRM.setProperty("password", Settings.postgresql_brm_pass)


  val propCMM: Properties = new java.util.Properties
  propCMM.setProperty("driver", "org.postgresql.Driver")
  propCMM.setProperty("user", Settings.postgresql_cmm_user)
  propCMM.setProperty("password", Settings.postgresql_cmm_pass)


}
