package br.com.natura.domain.application

class StructureIndexValue (
  index_code: Int,
  index_value: Double
)
