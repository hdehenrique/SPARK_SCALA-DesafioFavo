package br.com.natura.handlers.spark

import br.com.natura.settings.Settings
import org.apache.spark.sql.{SQLContext, SparkSession}
import org.apache.spark.streaming.{Duration, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

object Spark {
  System.setProperty("hadoop.home.dir", Settings.winUtils)

  val sparkConf: SparkConf = new SparkConf()
    .set("spark.cassandra.connection.host", Settings.cassandraServerAddress)
    .set("spark.cassandra.auth.username", Settings.cassandraUser)
    .set("spark.cassandra.auth.password", Settings.cassandraPass)
    .set("spark.cassandra.input.consistency.level", Settings.cassandraInputConsistency)
    .set("spark.cassandra.output.consistency.level", Settings.cassandraOutputConsistency)
    .set("spark.cassandra.connection.reconnection_delay_ms.max", Settings.cassandraReconnectionDelayMax)
    .set("spark.cassandra.connection.reconnection_delay_ms.min", Settings.cassandraReconnectionDelayMin)
    .set("spark.task.maxFailures", Settings.sparkMaxFailures)
    .set("spark.cassandra.query.retry.count", Settings.cassandraRetryCount)
    .set("spark.streaming.backpressure.enabled", "true")
    .set("spark.streaming.backpressure.initialRate", "1")
    .set("spark.streaming.receiver.maxRate", Settings.maxRate)
    .set("spark.streaming.kafka.maxRatePerPartition", Settings.maxRate)
    .set("spark.cassandra.connection.compression", Settings.spark_cassandra_connection_compression)
    .set("connection.connections_per_executor_max", Settings.connection_connections_per_executor_max)
    .set("spark.cassandra.read.timeout_ms", Settings.spark_cassandra_read_timeout_ms)
    .set("spark.cassandra.concurrent.reads", Settings.spark_cassandra_concurrent_reads)
    .set("spark.shuffle.service.enabled", Settings.spark_shuffle_service_enabled)
    .set("spark.cassandra.input.split.size_in_mb", Settings.spark_cassandra_input_split_size_in_mb)
    .set("spark.cassandra.input.fetch.size_in_rows", Settings.spark_cassandra_input_fetch_size_in_rows)
    .set("spark.cassandra.output.batch.size.rows", Settings.spark_cassandra_output_batch_size_rows)
    .set("spark.cassandra.output.concurrent.writes", Settings.spark_cassandra_output_concurrent_writes)
    .set("spark.memory.fraction", Settings.spark_memory_fraction)
    .set("spark.memory.storageFraction", Settings.spark_memory_storageFraction)
    .set("spark.locality.wait", Settings.spark_locality_wait)


  val sparkSession: SparkSession = SparkSession
    .builder()
    .config(sparkConf)
    .appName(Settings.appName)
    .getOrCreate()

  def getSparkSession: SparkSession = {
    sparkSession
  }

  def getSparkContext: SparkContext = {
    getSparkSession.sparkContext
  }

  def getSparkSQLContext: SQLContext = {
    getSparkSession.sqlContext
  }

  def getApplicationId: String = {
    getSparkContext.applicationId
  }

  def getStreamingContext(streamingApp: (SparkContext, Duration) => StreamingContext, batchDuration: Duration): StreamingContext = {
    val sc: SparkContext = getSparkContext

    val creatingFunc: () => StreamingContext = () => streamingApp(sc, batchDuration)
    val ssc = sc.getCheckpointDir match {
      case Some(checkpointDir) => StreamingContext.getActiveOrCreate(checkpointDir, creatingFunc, sc.hadoopConfiguration, createOnError = true)
      case None => StreamingContext.getActiveOrCreate(creatingFunc)
    }

    sc.getCheckpointDir.foreach(cp => ssc.checkpoint(cp))

    ssc
  }
}