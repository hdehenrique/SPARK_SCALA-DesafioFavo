package br.com.natura.domain.application

import java.sql.Timestamp

case class MessageToDLQ( engine_id : Int,
                         process_date : String,
                         topic : String,
                         partition : Int,
                         offset : Long,
                         message_create_time: String,
                         message : String)
