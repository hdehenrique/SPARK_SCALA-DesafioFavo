package br.com.natura.handlers.kafka

import java.io.InputStream
import java.net.{HttpURLConnection, URL}
import java.util.Properties
import java.util.UUID.randomUUID

import br.com.natura.engine.parser.kafka.Hostname
import br.com.natura.enums.KafkaHostCategory
import br.com.natura.settings.Settings
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import org.apache.kafka.common.TopicPartition
import org.apache.kafka.common.serialization.{StringDeserializer, StringSerializer}
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent


object Kafka {

  private val readTopic: Set[String] = Set(Settings.kafka_topic_read)
  private val properties: Map[String, Object] = this.setConsumerProperties()

  def setCalculationDirectStream(ssc: StreamingContext ,fromOffsets :Map[TopicPartition, Long]): InputDStream[ConsumerRecord[String, String]] = {

    val Offsets: Map[TopicPartition, Long] = fromOffsets.filter(m => m._2 > 0)

    val isProduction = Settings.kafka_bootstrap_servers contains "prd"

    KafkaUtils.createDirectStream[String, String](
      ssc,
      PreferConsistent,
      if (fromOffsets.isEmpty || !isProduction)
        Subscribe[String, String](this.readTopic, this.properties)
      else
        Subscribe[String, String](this.readTopic, this.properties,Offsets)
    )
  }

  private def setProducer(): KafkaProducer[String, String] = {
    new KafkaProducer[String, String](this.setProducerProperties())
  }


  private def setConsumerProperties(): Map[String, Object] = {

    val id = randomUUID().toString
    val groupID = Settings.appName + "-" + id

    Map(
      "bootstrap.servers" -> Settings.kafka_bootstrap_servers,
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "auto.offset.reset" -> "latest",
      "group.id" -> groupID,
      "enable.auto.commit" -> (false: java.lang.Boolean)
    )
  }

  private def setProducerProperties(): Properties = {
    val props = new Properties()

    val id = randomUUID().toString
    val groupID = Settings.appName + "-" + id

    props.put("bootstrap.servers", Settings.kafka_bootstrap_servers)
    props.put("client.id", groupID)
    props.put("key.serializer", classOf[StringSerializer])
    props.put("value.serializer", classOf[StringSerializer])
    props.put("group.id", groupID)
    props.put("auto.offset.reset", "latest")
    props.put("enable.auto.commit", false: java.lang.Boolean)

    props
  }

  private def setProducerRecord(message: String): ProducerRecord[String, String] = {
    new ProducerRecord[String, String](this.readTopic.head, message)
  }

  def send(message: String): Unit = {
    val producer: KafkaProducer[String, String] = this.setProducer()
    val data: ProducerRecord[String, String] = this.setProducerRecord(message)

    producer.send(data)
    producer.close()
  }
}
