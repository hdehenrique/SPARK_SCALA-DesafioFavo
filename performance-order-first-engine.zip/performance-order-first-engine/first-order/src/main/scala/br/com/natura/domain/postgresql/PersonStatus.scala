package br.com.natura.domain.postgresql

case class PersonStatus (
  personStatus: Int,
  cycle : Int
)
