package br.com.natura.domain.cassandra

import java.sql.{Date, Timestamp}

case class StructureIndexHistory (
  engine_id: Int,
  history_date: Date,
  hour_range: Int,
  uuid: String,
  country: Int,
  company_id: Int,
  business_model: Int,
  structure_level: Int,
  structure_code: Int,
  operational_cycle: Int,
  index_code: Int,
  index_value: Double,
  last_update: Timestamp
)
