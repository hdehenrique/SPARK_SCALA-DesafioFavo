package br.com.natura.domain.postgresql

case class StructureChildren (
  structure_level: Int,
  structure_code: Int
)
