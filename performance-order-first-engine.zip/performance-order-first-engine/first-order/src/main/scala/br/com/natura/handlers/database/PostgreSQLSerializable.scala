package br.com.natura.handlers.database

import java.sql.{Connection, ResultSet}

class PostgreSQLSerializable extends Serializable {

  def getPersonsStatus(conn: Connection,
                       person_code: Int,
                       country: Int,
                       company: Int,
                       business_model: Int,
                       role_list: List[Int],
                       function_list: List[Int]): ResultSet = {

    val statement =
      s"""select br.business_status_code,cycle
                    from brm.business_relation br,
                    brm.brm_person person
                    where
                    person.person_code = '${person_code}'
                    and  person.company = br.company
                    and person.country = br.country
                    and br.country = ${country}
                    and br.company = ${company}
                    and br.business_model = ${business_model}
                    and br.function in (${function_list.mkString(",")})
                    and br.role in (${role_list.mkString(",")})
                    and br.brm_person_uid = person.brm_person_uid
                    and br.created_at = (select max(br2.created_at) from brm.business_relation br2
                                                       where br2.brm_person_uid = br.brm_person_uid
                                                                and br2.function = br.function
                                                                and br2.role = br.role
                                                                and br2.country = br.country
                                                                and br2.company = br.company
                                                                and br2.business_model = br.business_model)"""


    val query = conn.prepareStatement(statement)


    query.executeQuery()
  }

  def getPersonBeginner(conn: Connection,
                       person_code: Int,
                       country: Int,
                       company: Int,
                       business_model: Int,
                       role_list: List[Int],
                       function_list: List[Int],
                       cycle: Int): ResultSet = {


    val statement =
      s"""with pessoa as (
                select
                    person.person_code,
                    br."cycle",
                    br.created_at,
                    br.business_status_code
                from
                    brm.business_relation br
                inner join brm.brm_person person on
                    br.brm_person_uid = person.brm_person_uid
                    and person.company = br.company
                    and person.country = br.country
                where
                    br.function in (${function_list.mkString(",")})
                    and br.role in (${role_list.mkString(",")})
                    and br.country = ?
                    and br.company = ?
                    and br.business_model = ?
                    and br.person_code = ?
            ),
            max_dois as (
                select
                    max(created_at) as created_at
                from
                    pessoa
                where
                    business_status_code = 2
            ),
            min_tres as (
                select
                    min(created_at) as created_at
                from
                    pessoa
                where
                    business_status_code = 3
                    and "cycle" = ?
                    and created_at > (select created_at from max_dois)
            ),
            max_created_at as(
              select max(created_at) as created_at
              from pessoa
            )
            select
                dois.person_code
            from
                pessoa dois
            inner join max_created_at on 1 = 1
            where
                dois.business_status_code = 2
                and dois.created_at = max_created_at.created_at
            union
            select
                tres.person_code
            from
                pessoa tres
            inner join max_dois on 1 = 1
            inner join min_tres on 1 = 1
            where
                tres.business_status_code = 3
                and tres.created_at = min_tres.created_at
                and not exists (
                    select
                        1
                    from
                        pessoa quatro
                    where
                        quatro.business_status_code = 4
                        and quatro.created_at > max_dois.created_at
                        and quatro.created_at < min_tres.created_at
                )
            """

    val query = conn.prepareStatement(statement)
    query.setInt(1, country)
    query.setInt(2, company)
    query.setInt(3, business_model)
    query.setInt(4, person_code)
    query.setInt(5, cycle)

    query.executeQuery()
  }

}