package br.com.natura.app.streaming

import java.util.Properties
import java.util.UUID.randomUUID
import br.com.natura.domain.application.{CountryCodes, KafkaProcess, KafkaProcessedOffSet, MessageToDLQ, OrdersToProcess, ValidateMessage}
import br.com.natura.domain.cassandra._
import br.com.natura.engine.EngineSerializable
import br.com.natura.engine.data.{DataCollectorSerializable, DataWrite}
import br.com.natura.engine.parser.kafka.PreParser
import br.com.natura.handlers.database.{PostgreSQL, PostgreSQLSerializable, ScyllaDBSerializable, ScyllaWrite}
import br.com.natura.handlers.kafka.Kafka
import br.com.natura.handlers.spark.Spark
import br.com.natura.helpers.Helpers
import br.com.natura.settings.Settings
import br.com.natura.handlers.kafka.KafkaSink
import com.google.gson.Gson
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.TopicPartition
import org.apache.spark.SparkContext
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.{Duration, Seconds, StreamingContext}
import org.joda.time.DateTime

object StreamingApp extends App {
  val sc: SparkContext = Spark.getSparkContext
  val ss: SparkSession = Spark.getSparkSession
  val cassandra: ScyllaWrite = new ScyllaWrite(ss)
  val postgresql: PostgreSQL = new PostgreSQL(ss)
  val dc: DataWrite = new DataWrite(ss, cassandra)

  private val postgresqlser = new PostgreSQLSerializable()
  private val scylladb = new ScyllaDBSerializable(sc.getConf)
  private val dcSer = new DataCollectorSerializable(scylladb, postgresqlser)

  sc.setLogLevel(Settings.logLevel)

  val ssc: StreamingContext = Spark.getStreamingContext(streamingApp, Seconds(Settings.kafka_microbatch_duration))

  ssc.start()
  ssc.awaitTermination()


  def streamingApp(sc: SparkContext, batchDuration: Duration): StreamingContext = {

    val id = randomUUID().toString
    val groupID = Settings.appName + "-" + id
    val logger = Helpers.getLogger(this.getClass)
    val props = new Properties()


    props.put("bootstrap.servers", Settings.kafka_bootstrap_servers)
    props.put("client.id", groupID)
    props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    props.put("group.id", groupID)
    props.put("auto.offset.reset", "latest")
    props.put("enable.auto.commit", false: java.lang.Boolean)

    val kafka_topic_send: String = Settings.kafka_topic_send
    val kafka_topic_re_send: String = Settings.kafka_topic_read


    logger.debug("Settings.appName  " + Settings.appName)
    logger.debug(Settings.kafka_bootstrap_servers)
    logger.debug("TOPIC READ " + Settings.kafka_topic_read)
    logger.debug("TOPIC SEND " + kafka_topic_send)
    logger.debug("kafka_microbatch_duration " + Settings.kafka_microbatch_duration)
    logger.debug("Log Level " + Settings.logLevel)


    // PROJ-OFFSET CONSULTO NO BANCO DE DADOS O OFFSET CADASTRADO PARA O TOPICO E O MOTOR
    val topicReadList = List(Settings.kafka_topic_read)
    val offsets = try {
      dcSer.getKafkaOffsetControl(Settings.engine_id, topicReadList)
    } catch {
      case _: Exception => List(KafkaProcessedOffSet(Settings.kafka_topic_read, 0, 0))
    }

    // PROJ-OFFSET TRANSFORMO O RESULTADO DA CONSULTA PARA O FORMATO ESPERADO PELO METODO DE CONSULMO DO KAFKA
    val fromOffsets: Map[TopicPartition, Long] = offsets.map { resultSet =>
      new TopicPartition(resultSet.topic, resultSet.partition) -> resultSet.offset
    }.toMap

    logger.debug("fromOffsets -> " + fromOffsets)

    val countryCodes: List[CountryCodes] = dcSer.getCountry

    val ssc: StreamingContext = new StreamingContext(sc, batchDuration)
    val stream: InputDStream[ConsumerRecord[String, String]] = Kafka.setCalculationDirectStream(ssc, fromOffsets)
    val kafkaSink: Broadcast[KafkaSink] = sc.broadcast(KafkaSink(props))


    // Parse das mensagens do Kafka
    val parsedMessages: DStream[ValidateMessage] =
      stream.mapPartitions(p => p.map(m => PreParser.validateMessage(m, countryCodes)))

    // Mensagens fora do padrão
    val failedMessages: DStream[String] = parsedMessages.mapPartitions(p => p.filter(!_.valid)
      .map(x => {
        val gson = new Gson()
        val messageToDLQ = MessageToDLQ(
          Settings.engine_id,
          new DateTime().withZone(Settings.zoneUTC).toString(),
          x.topic,
          x.partition,
          x.offset,
          new DateTime(x.message_create_time).withZone(Settings.zoneUTC).toString(),
          x.value
        )
        gson.toJson(messageToDLQ)
      }))

    // Mensagens válidads para processamento
    val validMessages: DStream[OrdersToProcess] = parsedMessages.mapPartitions(p => p.filter(_.valid).map(_.message_parsed))

    val result: DStream[(OrdersUUID, OrderHistoryUUID, Orders, OrderHistory, MessageHistory)] =
      validMessages.mapPartitions(new EngineSerializable(dcSer).processPartition).cache()

    val orderIdToRecord: DStream[OrdersUUID] = result.mapPartitions(_.map(r => r._1))
    val orderIdHistory: DStream[OrderHistoryUUID] = result.mapPartitions(_.map(r => r._2))
    val orderToRecord: DStream[Orders] = result.mapPartitions(_.map(r => r._3))
    val ordersHistory: DStream[OrderHistory] = result.mapPartitions(_.map(_._4))
    val messageHistory: DStream[MessageHistory] = result.mapPartitions(_.map(_._5))

    orderIdToRecord.filter(_.order_id.isDefined).foreachRDD(rdd => dc.saveToOrdersUUID(rdd))
    orderToRecord.filter(_.order_id > 0).foreachRDD(rdd => dc.saveToOrders(rdd))
    orderIdHistory.filter(_.order_id.isDefined).foreachRDD(rdd => dc.writeOrderIndexHistoryUUID(rdd))
    ordersHistory.filter(_.order_id > 0).foreachRDD(rdd => dc.writeOrderIndexHistory(rdd))
    messageHistory.foreachRDD(rdd => dc.setMessageHistoryRDD(rdd))


    orderIdToRecord.foreachRDD(rdd => if (!rdd.isEmpty()) {
      //Only send to next topic first processed order and after all orders be cancelled
      rdd.foreach(m => {
        kafkaSink.value.send(kafka_topic_send, m.json_message_send)
      })
    })


//    orderIdToRecord.foreachRDD(rdd => if (!rdd.isEmpty()) {
//      rdd.filter(x => {
//        x.resend_person
//      }).foreach(m => {
//        kafkaSink.value.send(kafka_topic_re_send, m.json_message_received)
//      })
//    })


    //PROJ-OFFSET MAP DAS INFORMAÇÕES RETORNADA DO KAFKA PARA A CLASSE
    val offSetsToProcess: DStream[KafkaProcess] = stream.mapPartitions(it => {
      it.map(m => {
        KafkaProcess(m.topic(), m.partition(), m.offset())
      })
    })
    // PROJ-OFFSET TRANSFORMAÇÃO PARA A GRAVAÇÃO NO BANCO
    offSetsToProcess.foreachRDD(rdd => if (!rdd.isEmpty()) dc.writeKafkaOffsetControl(rdd))

    failedMessages.foreachRDD(jason => if (!jason.isEmpty()) {
      jason.foreach(m => {
        kafkaSink.value.send(Settings.kafka_spec_failed_messages, new Gson().toJson(m))
      })
    })


    ssc
  }
}
