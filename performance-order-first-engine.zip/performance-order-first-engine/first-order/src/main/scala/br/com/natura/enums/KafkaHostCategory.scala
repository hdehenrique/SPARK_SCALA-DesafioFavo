package br.com.natura.enums

object KafkaHostCategory extends Enumeration {
  val HEADNODE: String  = "hn"
  val BROKER: String = "wn"
  val ZOOKEEPER: String = "zk"
}
