package br.com.natura.domain.cassandra

case class RoleFunction (country: Int,
                         company_id: Int,
                         business_model: Int,
                         structure_level: Int,
                         role_id: Int,
                         function_id: Int)