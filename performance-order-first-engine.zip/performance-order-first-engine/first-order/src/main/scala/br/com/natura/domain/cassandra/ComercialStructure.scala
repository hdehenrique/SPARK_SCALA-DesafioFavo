package br.com.natura.domain.cassandra

import org.joda.time.DateTime

case class ComercialStructure (
  country: Int,
  business_model: Int,
  company_id: Int,
  operational_cycle: Int,
  structure_level: Int,
  structure_code: Int,
  end_cycle: DateTime,
  start_cycle: DateTime,
  structure_tree: String
                              )
