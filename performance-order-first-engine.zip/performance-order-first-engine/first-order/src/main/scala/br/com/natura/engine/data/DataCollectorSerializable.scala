package br.com.natura.engine.data

import java.sql.Connection
import java.util.UUID
import br.com.natura.domain.application.{CountryCodes, KafkaProcessedOffSet, OrdersToProcess}
import br.com.natura.domain.cassandra.{ConsultantIndex, OrdersSalved, RoleFunction, StructureIndex}
import br.com.natura.domain.kafka.CalculateStructure
import br.com.natura.domain.postgresql.PersonStatus
import br.com.natura.engine.parser.database.scylla.ScyllaParser
import br.com.natura.handlers.database.{PostgreSQLSerializable, ScyllaDBSerializable}
import com.datastax.driver.core.{ResultSet, Row}

import collection.JavaConverters.{iterableAsScalaIterableConverter, _}
import scala.collection.mutable
import scala.collection.mutable.ListBuffer

class DataCollectorSerializable(scylla: ScyllaDBSerializable, postgres: PostgreSQLSerializable) extends Serializable {
//

  def getPersonBeginner(conn: Connection,
                         person_code: Int,
                         country: Int,
                         company: Int,
                         business_model: Int,
                         publicAllowedList: List[RoleFunction],
                         cycle : Int): Int = {




    val codes = ListBuffer[Int]()
    val result = postgres.getPersonBeginner(conn,
      person_code,
      country,
      company,
      business_model,
      publicAllowedList.map(p => p.role_id).distinct,
      publicAllowedList.map(p => p.function_id).distinct,
      cycle
    )



    if(result != null) {
      while(result.next()) {
        codes += result.getInt("person_code")
      }
    } else {
      codes += -1
    }

    if(result != null) result.close()

    codes.count(f => f > 0)


  }

  def getPersonStatusBRM(conn: Connection,
                         person_code: Int,
                         country: Int,
                         company: Int,
                         business_model: Int,
                         publicAllowedList: List[RoleFunction]): PersonStatus = {




    val codes = ListBuffer[PersonStatus]()
    val result = postgres.getPersonsStatus(conn,
      person_code,
      country,
      company,
      business_model,
      publicAllowedList.map(p => p.role_id).distinct,
      publicAllowedList.map(p => p.function_id).distinct
    )

    if(result != null) {
      while(result.next()) {
        codes += PersonStatus(result.getInt("business_status_code"),result.getInt("cycle"))
      }
    } else {
      codes += PersonStatus(-1,0)
    }

    if(result != null) result.close()

    codes.toList.head
  }

  def getCountry: List[CountryCodes] = {

    scylla.getCountry
      .asScala
      .map(this.parseRowToCountryCodes)
      .toList


  }

  private def parseRowToCountryCodes(r: Row): CountryCodes = {
    CountryCodes (
      country = r.getInt("country"),
      country_iso = r.getString("country_iso"),
      country_name = r.getString("country_name")
    )
  }

  def getAllOrders(company_id: Int,
                   country: Int,
                   business_model: Int,
                   consultant_code: Int,
                   order_cycle: Int): List[OrdersSalved] =  {

    scylla
      .getAllOrders(
        company_id,
        country,
        business_model,
        consultant_code,
        order_cycle
      )
      .asScala
      .map(ScyllaParser.fromRowToOrdersSalved)
      .toList



  }

  def getAllOrdersUuid(company_id: Int,
                   country: String,
                   business_model: Int,
                   consultant_code: Int,
                   order_cycle: Int): List[OrdersSalved] =  {

    scylla
      .getAllOrders(
        company_id,
        country,
        business_model,
        consultant_code,
        order_cycle
      )
      .asScala
      .map(ScyllaParser.fromRowToOrdersSalved)
      .toList



  }

  def getParameterDetails(company_id: Int,
                          country_id: Int,
                          businessModel: Int,
                          structureLevel: Int,
                          structureCode: Int,
                          parameter_id: Int) : List[Int] ={



    val result: ResultSet =  scylla.getParameter(company_id,
      country_id,
      businessModel,
      parameter_id,
      structureLevel,
      structureCode)

    if(result != null) {
      result.asScala.map(r => r.getInt("value")).toList
    } else {
      List(0)
    }
  }

  def getPublicAllowed(order: OrdersToProcess) : List[RoleFunction] ={

    scylla.getPublicAllowed(order.company_id,
      order.country,
      order.business_model).asScala
      .map(ScyllaParser.parseRowToPublicAllowed)
      .toList
  }


  def getKafkaOffsetControl(engine_id: Int,
                            topicList: List[String]): List[KafkaProcessedOffSet] = {

    scylla.getKafkaOffsetControl(topicList.map(t => {"'" + t + "'"}).mkString(","),engine_id)
      .asScala
      .map(ScyllaParser.parseRowToKafkaProcessedOffSet)
      .toList


  }


}
