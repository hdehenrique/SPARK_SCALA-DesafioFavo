package br.com.natura.enums

object KafkaHostPort extends Enumeration {
  val HEADNODE: String  = ":8080"
  val BROKER: String = ":9092"
  val ZOOKEEPER: String = ":2181"

  def getPort(category: String): String = {
    category match {
      case KafkaHostCategory.HEADNODE => this.HEADNODE
      case KafkaHostCategory.BROKER => this.BROKER
      case KafkaHostCategory.ZOOKEEPER => this.ZOOKEEPER
    }
  }
}
