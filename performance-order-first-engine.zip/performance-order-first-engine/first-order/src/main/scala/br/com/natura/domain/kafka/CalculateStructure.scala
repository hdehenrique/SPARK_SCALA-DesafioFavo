package br.com.natura.domain.kafka

import org.joda.time.DateTime

case class CalculateStructure (
  country: Int,
  company_id: Int,
  business_model: Int,
  structure_level: Int,
  structure_code: Int,
  cycle: Int,
  uuid: String,
  message: String
)



case class FatherStructureToProcess (
                                country: Int,
                                company_id: Int,
                                business_model: Int,
                                structure_level: Int,
                                structure_code: Int,
                                cycle: Int,
                                uuid: String,
                                messageToSend: String
                              )