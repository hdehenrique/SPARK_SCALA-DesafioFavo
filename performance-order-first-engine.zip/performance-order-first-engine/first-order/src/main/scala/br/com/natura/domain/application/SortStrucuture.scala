package br.com.natura.domain.application

case class SortStrucuture(structure_level: Int,
                          structure_code: Int)

case class ParentStrucuture(structure_level: Int,
                          structure_code: Int)