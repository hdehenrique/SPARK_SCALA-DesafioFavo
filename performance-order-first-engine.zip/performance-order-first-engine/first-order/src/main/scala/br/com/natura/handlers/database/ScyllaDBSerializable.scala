package br.com.natura.handlers.database

import br.com.natura.domain.cassandra.RoleFunction
import br.com.natura.domain.postgresql._
import com.datastax.driver.core.{ResultSet, Row}
import com.datastax.spark.connector.cql.CassandraConnector
import org.apache.spark.SparkConf

class ScyllaDBSerializable(config: SparkConf) extends Serializable {

  val connector: CassandraConnector = CassandraConnector(config)

  val ksSpec = "performance"

  val tbConsultantIndex = "consultant_index"
  val tbMessageHistory = "message_history"
  val tbStructureIndex = "structure_index"
  val tbStructureIndexHistory = "structure_index_history"
  val tbOperationalStructureTable =  "comercial_structure"
  val country_codes_table = "country_codes"
  val person_orders = "consultant_orders"
  val person_orders_id = "consultant_orders_id"
  val masterData_keyspace = "masterdata"
  val personCodeTable = "person_code"
  val net_parameters_table = "parameters_net"
  val publicAllowedTable  =  "public_allowed"

  val kafkaOffsetControl_Table: String = "kafka_offset_control"

  def getPersonCode(company_id: Int,
                    country_id: Int,
                    businessModel: Int,
                    person_code: Int): ResultSet = {
    val table = masterData_keyspace + "." + personCodeTable


    connector.withSessionDo(s => {
      s.execute(
        s"SELECT person_id FROM $table " +
          s"WHERE company = $company_id " +
          s"AND country = $country_id " +
          s"AND business_model = $businessModel " +
          s"AND person_code = $person_code "
      )
    })
  }

  def getCountry: ResultSet = {

    val table = ksSpec + "." + country_codes_table
    connector.withSessionDo(s => {
      s.execute(
        s"SELECT country,country_iso,country_name FROM $table "
      )
    })
  }


  def getAllOrders(company_id: Int,
                   country: Int,
                   business_model: Int,
                   consultant_code: Int,
                   order_cycle: Int): ResultSet = {
    val table = ksSpec + "." + person_orders


    connector.withSessionDo(s => {
      s.execute(
        s"SELECT order_id, channel_id, order_status FROM $table " +
          s"WHERE company_id = $company_id " +
          s"AND country = $country " +
          s"AND business_model = $business_model " +
          s"AND consultant_code = $consultant_code " +
          s"AND order_cycle = $order_cycle"
      )
    })
  }

  def getAllOrders(company_id: Int,
                   country: String,
                   business_model: Int,
                   consultant_code: Int,
                   order_cycle: Int): ResultSet = {
    val table = ksSpec + "." + person_orders_id


    connector.withSessionDo(s => {
      s.execute(
        s"SELECT order_id, channel_id, order_status FROM $table " +
          s"WHERE company_id = $company_id " +
          s"AND country = '$country' " +
          s"AND business_model = $business_model " +
          s"AND consultant_code = $consultant_code " +
          s"AND order_cycle = $order_cycle"
      )
    })
  }

  def getStructureTree(company_id: Int,
                       country_id: Int,
                       business_model: Int,
                       operational_cycle: Int,
                       structure_level: Int,
                       structure_code: Int): Row = {

    val table: String = ksSpec + "." + tbOperationalStructureTable

    connector.withSessionDo(s => {
      s.execute(
        s"SELECT * FROM $table " +
          s"WHERE country = $country_id " +
          s"AND company_id = $company_id " +
          s"AND business_model = $business_model " +
          s"AND structure_level = $structure_level " +
          s"AND structure_code = $structure_code " +
          s"AND operational_cycle = $operational_cycle"
      ).one()
    })
  }

  def getConsultantsIndexes(country: Int,
                            company_id: Int,
                            business_model: Int,
                            operational_cycle: Int,
                            consultantCodes: List[Int]): ResultSet = {
    val table: String = ksSpec + "." + tbConsultantIndex

    connector.withSessionDo(s => {
      s.execute(
        s"SELECT     country , company_id , business_model , consultant_code , operational_cycle , index_code , index_value FROM $table " +
          s"WHERE country = $country " +
          s"AND company_id = $company_id " +
          s"AND business_model = $business_model " +
          s"AND consultant_code in (${consultantCodes.mkString(",")}) " +
          s"AND operational_cycle = $operational_cycle"
      )
    })
  }

  def getConsultantsIndex(country: Int,
                          company_id: Int,
                          business_model: Int,
                          operational_cycle: Int,
                          consultantCodes: List[Int],
                          index_code: Int): ResultSet = {
    val table: String = ksSpec + "." + tbConsultantIndex

    connector.withSessionDo(s => {
      s.execute(
        s"SELECT     country , company_id , business_model , consultant_code , operational_cycle , index_code , index_value FROM $table " +
          s"WHERE country = $country " +
          s"AND company_id = $company_id " +
          s"AND business_model = $business_model " +
          s"AND consultant_code in (${consultantCodes.mkString(",")}) " +
          s"AND operational_cycle = $operational_cycle " +
          s"AND index_code = $index_code "
      )
    })
  }

  def getStructuresIndexes(country: Int,
                           company_id: Int,
                           business_model: Int,
                           structure_level: Int,
                           structure_codes: List[Int],
                           operational_cycle: Int): ResultSet = {
    val table: String = ksSpec + "." + tbStructureIndex

    connector.withSessionDo(s => {
      s.execute(
        s"SELECT * FROM $table " +
          s"WHERE country = $country " +
          s"AND company_id = $company_id " +
          s"AND business_model = $business_model " +
          s"AND structure_level = $structure_level " +
          s"AND structure_code in (${structure_codes.mkString(",")}) " +
          s"AND operational_cycle = $operational_cycle"
      )
    })
  }

  def getStructuresIndex(country: Int,
                         company_id: Int,
                         business_model: Int,
                         structure_level: Int,
                         structure_codes: List[Int],
                         operational_cycle: Int,
                         index_code: List[Int]): ResultSet = {
    val table: String = ksSpec + "." + tbStructureIndex

    connector.withSessionDo(s => {
      s.execute(
        s"SELECT * FROM $table " +
          s"WHERE country = $country " +
          s"AND company_id = $company_id " +
          s"AND business_model = $business_model " +
          s"AND structure_level = $structure_level " +
          s"AND structure_code in (${structure_codes.mkString(",")}) " +
          s"AND operational_cycle = $operational_cycle " +
          s"AND index_code in (${index_code.mkString(",")}) "
      )
    })
  }

  def getStructuresIndex(country: Int,
                         company_id: Int,
                         business_model: Int,
                         structure_level: Int,
                         structure_codes: List[Int],
                         operational_cycle: Int,
                         index_code: Int): ResultSet = {
    val table: String = ksSpec + "." + tbStructureIndex

    connector.withSessionDo(s => {
      s.execute(
        s"SELECT * FROM $table " +
          s"WHERE country = $country " +
          s"AND company_id = $company_id " +
          s"AND business_model = $business_model " +
          s"AND structure_level = $structure_level " +
          s"AND structure_code in (${structure_codes.mkString(",")}) " +
          s"AND operational_cycle = $operational_cycle " +
          s"AND index_code = $index_code "
      )
    })
  }

  def getStructuresIndexValue(country: Int,
                              company_id: Int,
                              business_model: Int,
                              structure_level: Int,
                              structure_code: Int,
                              operational_cycle: Int,
                              index_code: Int): ResultSet = {
    val table: String = ksSpec + "." + tbStructureIndex

    connector.withSessionDo(s => {
      s.execute(
        s"SELECT * FROM $table " +
          s"WHERE country = $country " +
          s"AND company_id = $company_id " +
          s"AND business_model = $business_model " +
          s"AND structure_level = $structure_level " +
          s"AND operational_cycle = $operational_cycle " +
          s"AND structure_code = $structure_code " +
          s"AND index_code = $index_code "
      )
    })
  }

  def getParameter(company_id: Int,
                   country_id: Int,
                   businessModel: Int,
                   parameter_id: Int,
                   structure_level: Int,
                   structure_code: Int
                  ): ResultSet = {
    val table = ksSpec + "." + net_parameters_table

    connector.withSessionDo(s => {
      s.execute(
        s"SELECT value,description FROM $table " +
          s"WHERE company_id = $company_id " +
          s"AND country = $country_id " +
          s"AND business_model = $businessModel " +
          s"AND parameter_id = $parameter_id " +
          s"AND structure_level = $structure_level " +
          s"AND structure_code = $structure_code "
      )
    })
  }

  def getPublicAllowed(company_id: Int,
                       country_id: Int,
                       businessModel: Int
                      ): ResultSet = {

    val table = ksSpec + "." + publicAllowedTable

    connector.withSessionDo(s => {
      s.execute(
        s"SELECT country,company,business_model,role,function FROM $table " +
          s"WHERE company = $company_id " +
          s"AND country = $country_id " +
          s"AND business_model = $businessModel "
      )
    })
  }

  def getKafkaOffsetControl(topic: String,
                            engine_id: Int
                           ): ResultSet = {


    val table = ksSpec + "." + kafkaOffsetControl_Table
    connector.withSessionDo(s => {
      s.execute(
        s"SELECT topic,partition,offset FROM $table " +
          s"WHERE topic in ($topic) "+
          s"AND engine_id = $engine_id "
      )
    })
  }

}
