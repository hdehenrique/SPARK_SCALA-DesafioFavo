package br.com.natura.engine.parser.database.scylla

import java.sql.Timestamp
import br.com.natura.domain.cassandra.{ConsultantIndex, OrdersSalved, RoleFunction, StructureIndex}
import com.datastax.driver.core.Row

import java.util.{Date, UUID}
import br.com.natura.domain.application.KafkaProcessedOffSet

object ScyllaParser {
  def fromRowToConsultantIndex(r: Row): ConsultantIndex = {
    ConsultantIndex(
      country = r.getInt("country"),
      company_id = r.getInt("company_id"),
      business_model = r.getInt("business_model"),
      consultant_code = r.getInt("consultant_code"),
      operational_cycle = r.getInt("operational_cycle"),
      index_code = r.getInt("index_code"),
      index_value = r.getDouble("index_value")
    )
  }

  def fromRowToStructureIndex(r: Row): StructureIndex = {
    StructureIndex (
      country = r.getInt("country"),
      company_id = r.getInt("company_id"),
      business_model = r.getInt("business_model"),
      structure_level = r.getInt("structure_level"),
      structure_code = r.getInt("structure_code") ,
      operational_cycle = r.getInt("operational_cycle"),
      index_code = r.getInt("index_code"),
      index_value = r.getDouble("index_value")
    )
  }

  def fromRowToOrdersSalved(r : Row): OrdersSalved = {
    OrdersSalved (
      r.getObject("order_id").toString,
      r.getInt("channel_id"),
      r.getInt("order_status")
    )
  }

  def fromRowToUUID(r: Row): UUID = {

     val  person_id = r.getUUID("person_id")

    person_id

  }

  def parseRowToPublicAllowed(r: Row): RoleFunction = {
    RoleFunction (
      country = r.getInt("country"),
      company_id = r.getInt("company"),
      business_model = r.getInt("business_model"),
      structure_level = 0 ,
      function_id = r.getInt("function"),
      role_id =  r.getInt("role")
    )
  }

  def parseRowToKafkaProcessedOffSet(r: Row): KafkaProcessedOffSet = {
    KafkaProcessedOffSet (
      topic = r.getString("topic"),
      partition = r.getInt("partition"),
      offset = r.getLong("offset")
    )
  }


}
