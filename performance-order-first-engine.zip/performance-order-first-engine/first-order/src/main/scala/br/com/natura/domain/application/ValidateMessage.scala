package br.com.natura.domain.application

case class ValidateMessage (topic : String,
                            partition : Int,
                            offset : Long,
                            valid: Boolean,
                            message_create_time: Long,
                            message_parsed: OrdersToProcess,
                            value : String)