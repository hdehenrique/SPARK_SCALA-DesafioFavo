package br.com.natura.engine.parser.kafka

import br.com.natura.domain.application.{CountryCodes, OrdersToProcess, ValidateMessage}
import org.apache.kafka.clients.consumer.ConsumerRecord

object PreParser {
  def validateMessage(m: ConsumerRecord[String, String], countryCodes: List[CountryCodes]): ValidateMessage = {
    val parsedMessage = toOrdersToProcess(m, countryCodes)

    ValidateMessage(topic = m.topic(),
      partition = m.partition(),
      offset = m.offset(),
      valid = parsedMessage.valid,
      message_create_time = m.timestamp(),
      message_parsed = parsedMessage,
      value = m.value()
    )
  }

  private def toOrdersToProcess(m: ConsumerRecord[String, String], countryCodes: List[CountryCodes]): OrdersToProcess = {
    try {
      Message.parse(m.value(), countryCodes)
    } catch {
      case _: Exception =>
        OrdersToProcess.empty()
    }
  }

}
