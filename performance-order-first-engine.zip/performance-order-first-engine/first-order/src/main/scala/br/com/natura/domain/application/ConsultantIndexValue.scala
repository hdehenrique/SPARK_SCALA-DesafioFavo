package br.com.natura.domain.application

case class ConsultantIndexValue (
  index_code: Int,
  index_value: Double
)
