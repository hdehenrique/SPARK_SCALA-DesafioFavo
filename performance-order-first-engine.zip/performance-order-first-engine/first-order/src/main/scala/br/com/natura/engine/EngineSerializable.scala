package br.com.natura.engine

import java.sql.Timestamp
import java.util.Date
import br.com.natura.domain.application.OrdersToProcess
import br.com.natura.domain.cassandra.{OrdersProcesses, _}
import br.com.natura.domain.postgresql.PersonStatus
import br.com.natura.engine.data.DataCollectorSerializable
import br.com.natura.handlers.database.connection.PostgreSQL
import br.com.natura.helpers.Helpers
import br.com.natura.settings.Settings
import org.joda.time.DateTime

class EngineSerializable(dc: DataCollectorSerializable) extends Serializable {
  val date: Date = Helpers.currentDate()
  val timestamp: Timestamp = Helpers.currentTimestamp(date)

  private val statusAllowedVD = List(17, 3) // status de pedidos faturados

  def processPartition(messages: Iterator[OrdersToProcess]): Iterator[(OrdersUUID, OrderHistoryUUID, Orders, OrderHistory, MessageHistory)] = {
    messages.map(k => this.processMessage(k))
  }

  private def processMessage(order: OrdersToProcess): (OrdersUUID, OrderHistoryUUID, Orders, OrderHistory, MessageHistory) = {

    val brmConn = PostgreSQL.brm().getConnection


    val engine_id = 11


    val allOrders: List[OrdersSalved] = if (Settings.read_uuid_table) {
      dc.getAllOrdersUuid(order.company_id, order.countryISO, order.business_model, order.consultant_code, order.order_cycle)
    } else {
      dc.getAllOrders(order.company_id, order.country, order.business_model, order.consultant_code, order.order_cycle)
    }

    //consultar o channel id do rede natura
    val netChannelIds: List[Int] = try {
      dc.getParameterDetails(order.company_id, order.country, order.business_model, 0, 1, 4)
    } catch {
      case _: Exception => List(0)
    }

    //Consulta os status de pedido permitidos do rede
    val netStatus = try {
      dc.getParameterDetails(order.company_id, order.country, order.business_model, 0, 1, 5)
    } catch {
      case _: Exception => List(0)
    }


    val allOrdersStatus: List[OrdersProcesses] = allOrders.map(x => {
      OrdersProcesses(x.order_id, checkFaturedOrder(x.channel_id, x.order_status, netChannelIds, netStatus))
    })


    //VERIFICA A QUANTIDADE DE PEDIDOS FATURADOS E CANCELADOS
    val countOrdersBilled = allOrdersStatus.count(f => f.fatured)
    val countCancelled = allOrdersStatus.count(f => !f.fatured)
    val countOrders = countOrdersBilled - countCancelled

    val firstOrderCycle = if (countOrders == 1) true else false
    val noOrderCycle = if (countOrders == 0) true else false


    //CONSULTA O PARAMETRO DE ROLE E FUNCTION DOS PEDIDOS PERMITIDOS POR PAIS
    val publicAllowedList: List[RoleFunction] = dc.getPublicAllowed(order)


    //Consulto status da consultora no BRM
    val personStatusReturn = try {
      dc.getPersonStatusBRM(brmConn, order.consultant_code, order.country, order.company_id, order.business_model, publicAllowedList)
    } catch {
      case _: Exception => PersonStatus(-1, order.order_cycle)
    }


    val personsBeginnerThisCycle: Boolean = try {
      val isBeginner = dc.getPersonBeginner(brmConn, order.consultant_code, order.country, order.company_id, order.business_model, publicAllowedList, order.order_cycle)
      if (isBeginner > 0) true else false
    } catch {
      case _: Exception => false
    }


    val personStatusBRM = try {
      personStatusReturn.personStatus
    } catch {
      case _: Exception => -1
    }

    val personStatusCycle = try {
      personStatusReturn.cycle
    } catch {
      case _: Exception => order.order_cycle
    }


    val isCeased = if (personStatusBRM == 4 && personStatusCycle < order.order_cycle) true else false


    val orderDateSubtring: String =
      try {
        order.order_date.substring(0, 10)
      } catch {
        case _: Exception => new DateTime(new DateTime().withZone(Settings.zoneUTC)).toString()
      }


    val toleranceToResend = if (
      new DateTime(orderDateSubtring).getMillis >= new DateTime(new DateTime().withZone(Settings.zoneUTC)).minusHours(Settings.minusHour).getMillis
    ) true else false


    val personStatus = if (personStatusBRM == -1 || isCeased) {
      if (!toleranceToResend) 99 else personStatusBRM
    } else {
      personStatusBRM
    }


    val jsonMessage: String =
      s"""{"engine_id":${order.engine_id},
         |"uuid":"${order.uuid}",
         |"company_id":${order.company_id},
         |"country":${order.country},
         |"country_iso":"${order.countryISO}",
         |"business_model":${order.business_model},
         |"order_id":${order.order_id},
         |"order_number":"${order.order_number}",
         |"order_uuid":${if(order.orderUUID.isDefined) "\"" + order.orderUUID.get + "\"" else null},
         |"order_date":"${order.order_date}",
         |"order_status":${order.order_status},
         |"consultant_code":${order.consultant_code},
         |"order_cycle":${order.order_cycle},
         |"structure_level":${order.structure_level},
         |"structure_code":${order.structure_code},
         |"channel_id":${order.channel_id},
         |"order_points":${order.order_points},
         |"order_value":${order.order_value},
         |"order_itens":${order.order_itens},
         |"status_activity":$countOrders,
         |"person_status":$personStatus,
         |"person_beginner":$personsBeginnerThisCycle,
         |"initial":${order.initial},
         |"system_source":${order.system_source},
         |"structure_tree":${order.structure_tree} }""".stripMargin

    val firstOrderUUID =
      OrdersUUID(order.uuid,
        order.company_id,
        order.countryISO,
        order.business_model,
        order.orderUUID,
        order.consultant_code,
        order.order_cycle,
        order.structure_level,
        order.structure_code,
        order.channel_id,
        order.order_status,
        order.order_calculation_date.toString,
        order.order_date,
        order.order_itens,
        order.order_points,
        order.order_value,
        order.structure_tree,
        firstOrderCycle,
        countOrders,
        personStatus,
        noOrderCycle,
        jsonMessage,
        if (personStatus == -1 && toleranceToResend) true else false,
        order.jason_received
      )

    val firstOrder =
      Orders(order.uuid,
        order.company_id,
        order.country,
        order.business_model,
        order.order_id,
        order.consultant_code,
        order.order_cycle,
        order.structure_level,
        order.structure_code,
        order.channel_id,
        order.order_status,
        order.order_calculation_date.toString,
        order.order_date,
        order.order_itens,
        order.order_points,
        order.order_value,
        order.structure_tree,
        firstOrderCycle,
        countOrders,
        personStatus,
        noOrderCycle,
        jsonMessage,
        if (personStatus == -1 && toleranceToResend) true else false,
        order.jason_received
      )

    val dateProcess = new DateTime().withZone(Settings.zoneUTC)

    val orderHistoryUUID = OrderHistoryUUID(engine_id,
      dateProcess,
      getHourRange2(dateProcess),
      order.uuid,
      order.countryISO,
      order.company_id,
      order.business_model,
      order.orderUUID,
      order.order_number,
      order.consultant_code,
      order.order_cycle,
      order.structure_level,
      order.structure_code,
      order.channel_id,
      order.order_status,
      firstOrderCycle,
      new DateTime().withZone(Settings.zoneUTC),
      order.order_calculation_date,
      order.order_date,
      order.order_itens,
      order.order_points,
      order.order_value,
      order.person_status,
      order.structure_tree,
      order.system_source)

    val orderHistory = OrderHistory(engine_id,
      dateProcess,
      getHourRange2(dateProcess),
      order.uuid,
      order.country,
      order.company_id,
      order.business_model,
      order.order_id,
      order.consultant_code,
      order.order_cycle,
      order.structure_level,
      order.structure_code,
      order.channel_id,
      order.order_status,
      firstOrderCycle,
      new DateTime().withZone(Settings.zoneUTC),
      order.order_calculation_date,
      order.order_date,
      order.order_itens,
      order.order_points,
      order.order_value,
      order.person_status,
      order.structure_tree)


    brmConn.close()


    val messageHistory: MessageHistory = this.setMessageHistory(firstOrderUUID)

    (firstOrderUUID, orderHistoryUUID, firstOrder, orderHistory, messageHistory)
  }

  private def getHourRange2(hourRange: DateTime): Int = {

    hourRange.getHourOfDay

  }


  def setMessageHistory(structure: OrdersUUID): MessageHistory = {
    MessageHistory(
      engine_id = 11,
      history_date = new DateTime().withZone(Settings.zoneUTC),
      hour_range = getHourRange2(new DateTime().withZone(Settings.zoneUTC)),
      uuid = structure.uuid,
      last_update = new DateTime().withZone(Settings.zoneUTC),
      payload = structure.json_message_received
    )
  }

  private def checkFaturedOrder(
                                 channel_id: Int,
                                 order_status: Int,
                                 netChannelIds: List[Int],
                                 netStatus: List[Int]
                               ): Boolean = {

    //Verifica se o pedido é do rede natura
    val isNetOrder = netChannelIds.contains(channel_id)

    val statusAllowed: List[Int] = if (isNetOrder) {
      netStatus
    } else statusAllowedVD


    statusAllowed.contains(order_status)


  }


}
