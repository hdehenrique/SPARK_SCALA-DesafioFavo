package br.com.natura.engine.data

import java.sql.Timestamp
import java.util.Date
import br.com.natura.domain.application.{KafkaProcess, KafkaProcessToRecord}
import br.com.natura.domain.cassandra._
import br.com.natura.handlers.database.ScyllaWrite
import br.com.natura.settings.Settings
import com.datastax.spark.connector.SomeColumns
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

class DataWrite(ss: SparkSession, cassandra: ScyllaWrite) {
  import ss.implicits._

  private val columnsHistory: SomeColumns = SomeColumns(
    "engine_id", "history_date", "hour_range", "uuid", "country", "company_id",
    "business_model", "order_id", "consultant_code", "order_cycle", "structure_level",
    "structure_code", "channel_id", "order_status", "first_order_cycle", "last_update",
    "order_calculation_date", "order_date", "order_itens", "order_points", "order_value",
    "person_status", "structure_tree"
  )

  private val columnsHistoryUUID: SomeColumns = SomeColumns(
    "engine_id", "history_date", "hour_range", "uuid", "country", "company_id",
    "business_model", "order_id", "consultant_code", "order_cycle", "structure_level",
    "structure_code", "channel_id", "order_status", "first_order_cycle", "last_update",
    "order_calculation_date", "order_date", "order_itens", "order_points", "order_value",
    "person_status", "structure_tree", "system_source", "order_number"
  )

  private val columnsOrders: SomeColumns = SomeColumns(
    "company_id", "country", "order_id", "order_cycle", "structure_code", "channel_id",
    "order_status", "business_model", "structure_level", "consultant_code", "first_order_cycle", "person_status"
  )

    def setMessageHistoryRDD(messageHistory: RDD[MessageHistory]): Unit = {
    cassandra.setMessageHistory(messageHistory)
  }

  def saveToOrders(firstOrderRDD: RDD[Orders]): Unit = {
    if (Settings.write_old_table) {
      cassandra.saveFirstOrder(firstOrderRDD, columnsOrders)
    }
  }

  def saveToOrdersUUID(firstOrderRDD: RDD[OrdersUUID]): Unit ={
    cassandra.saveFirstOrderUUID(firstOrderRDD, columnsOrders)
  }

  def writeOrderIndexHistory(orderParameter: RDD[OrderHistory]): Unit = {
    cassandra.saveToOrderHistory(orderParameter, columnsHistory)
  }

  def writeOrderIndexHistoryUUID(orderParameter: RDD[OrderHistoryUUID]): Unit = {
    cassandra.saveToOrderHistoryUUID(orderParameter, columnsHistoryUUID)
  }

  def writeKafkaOffsetControl(rdd: RDD[KafkaProcess]): Unit = {

    // PROJ-OFFSET GROUP BY PARA GRAVAR O MENOR OFF SET DO TOPICO E PARTITION
    //USEI O MENOR PARA GARANTIR QUE TODOS OS PEDIDOS SERÃO PROCESSADOS
    val offSetToRecord: RDD[KafkaProcessToRecord] = rdd.groupBy(r => (r.topic,r.partition)).mapValues(_.map(_.offset).min).map(x => {
      KafkaProcessToRecord(x._1._1,Settings.engine_id,x._1._2,x._2,new Timestamp(new Date().getTime))
    })
    cassandra.saveToKafkaOffsetControl(offSetToRecord.toDS())
  }


}