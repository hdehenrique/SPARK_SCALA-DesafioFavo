package br.com.natura.domain.application

import java.sql.Timestamp

import org.joda.time.DateTime

case class ApplicationLog (
      engine_id: Int,
      id_log: Int,
      log_date: DateTime,
      consultant_code: Int,
      uuid: String,
      ds_message: String)
