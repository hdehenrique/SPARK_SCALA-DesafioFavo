package br.com.natura.domain.cassandra

case class parameterValues(structure_level: Int,
                           structure_code: Int,
                           exception_value: Int)