package br.com.natura.engine.parser.database.application

import br.com.natura.domain.cassandra.{StructureIndex, StructureIndexChildren}

object ApplicationParser {
  def fromStructureIndexToStructureIndexChildren(c: StructureIndex): StructureIndexChildren = {
    StructureIndexChildren(
      country = c.country,
      company_id = c.company_id,
      business_model = c.business_model,
      operational_cycle = c.operational_cycle,
      index_code = c.index_code,
      index_value = c.index_value
    )
  }
}
