package br.com.natura.engine.data

import br.com.natura.domain.application.SortStrucuture
import com.mongodb.{BasicDBList, DBObject}
import com.mongodb.util.JSON

object ParseJason {


  def parseStrucureTree(parameter: String): Array[SortStrucuture] = {

    val jsonData = JSON.parse(parameter).asInstanceOf[DBObject]

    val fieldItems = jsonData.asInstanceOf[BasicDBList]
    val items: Array[SortStrucuture] = fieldItems
      .toArray
      .map((itemAny) => {
        val itemDetail = itemAny.asInstanceOf[DBObject]
        SortStrucuture(
          structure_level = itemDetail.get("structureLevel").asInstanceOf[Number].intValue(),
          structure_code  = itemDetail.get("structureCode").asInstanceOf[Number].intValue()
        )})
    items.reverse
  }

}
