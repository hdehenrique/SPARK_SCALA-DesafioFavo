package br.com.natura.engine.parser.kafka

import br.com.natura.domain.application.{CountryCodes, OrdersToProcess}
import br.com.natura.helpers.Helpers
import br.com.natura.settings.Settings
import org.bson.Document
import org.joda.time.DateTime

import java.util.UUID

object Message {

  private val logger = Helpers.getLogger(this.getClass)

  def parse(message: String, countryCodes: List[CountryCodes]): OrdersToProcess = {

    try {
      val parameter: Document = Document.parse(message)

      val allowedEngineId: List[Int] = List(0, 11)
      val isOrigin = try {
        parameter.get("reprocessing").asInstanceOf[Number].intValue()
      } catch {
        case _: Exception =>
          0
      }
      val structure_level = parameter.get("structure_level").asInstanceOf[Number].intValue()
      val structure_code = parameter.get("structure_code").asInstanceOf[Number].intValue()

      val engineIdJason = parameter.get("engine_id").asInstanceOf[Number].intValue()
      val isOriginReprocessing = if (isOrigin == 1 && allowedEngineId.contains(engineIdJason)) 1 else 0

      val country: Int = parameter.getInteger("country")

      val countryISO: String =
        parameter.getOrDefault("country_iso", countryCodes.find(_.country == country).map(_.country_iso).getOrElse(" ")).asInstanceOf[String]

      val orderUUID: Option[UUID] = try {
        Option(UUID.fromString(parameter.getString("order_uuid")))
      } catch {
        case _: Exception => None
      }

      val systemSource: Int = parameter.getInteger("system_source", 0)

      val orderId: Int = parameter.getInteger("order_id", 0)

      val orderNumber: String = if (parameter.containsKey("order_number")) parameter.getString("order_number") else orderId.toString

      OrdersToProcess(
        uuid = parameter.get("uuid").asInstanceOf[String],
        company_id = parameter.get("company_id").asInstanceOf[Number].intValue(),
        country = country,
        countryISO = countryISO,
        orderUUID = orderUUID,
        system_source = systemSource,
        business_model = parameter.get("business_model").asInstanceOf[Number].intValue(),
        order_id = orderId,
        order_number = orderNumber,
        consultant_code = parameter.get("consultant_code").asInstanceOf[Number].intValue(),
        order_cycle = parameter.get("order_cycle").asInstanceOf[Number].intValue(),
        structure_level = structure_level,
        structure_code = structure_code,
        channel_id = parameter.get("channel_id").asInstanceOf[Number].intValue(),
        order_status = parameter.get("order_status").asInstanceOf[Number].intValue(),
        order_calculation_date = new DateTime().withZone(Settings.zoneUTC),
        order_date = parameter.get("order_date").asInstanceOf[String],
        order_itens = parameter.get("order_itens").asInstanceOf[Number].intValue(),
        order_points = parameter.get("order_points").asInstanceOf[Number].intValue(),
        order_value = parameter.get("order_value").asInstanceOf[Number].doubleValue(),
        structure_tree = s"""[{"structureLevel":$structure_level,"structureCode":$structure_code }]""",
        first_order_cycle = false,
        status_activity = 0,
        person_status = Option(parameter.get("person_status")).getOrElse(-1).asInstanceOf[Number].intValue(),
        engine_id = if (isOriginReprocessing == 1 || allowedEngineId.contains(engineIdJason)) 0 else engineIdJason,
        jason_received = message,
        initial = try {
          parameter.get("initial").asInstanceOf[Number].intValue()
        } catch {
          case _: Exception => 0
        },
        valid = true
      )
    } catch {
      case e: Exception =>
        logger.debug(s"Error parsing message: $message - ${e.getMessage}")
        OrdersToProcess.empty()
    }

  }
}
