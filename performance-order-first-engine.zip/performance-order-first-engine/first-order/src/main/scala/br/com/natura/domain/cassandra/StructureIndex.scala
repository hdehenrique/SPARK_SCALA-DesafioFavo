package br.com.natura.domain.cassandra

case class StructureIndex (
  country: Int,
  company_id: Int,
  business_model: Int,
  structure_level: Int,
  operational_cycle: Int,
  structure_code: Int,
  index_code: Int,
  index_value: Double
)

case class StructureIndexChildren (
                            country: Int,
                            company_id: Int,
                            business_model: Int,
                            operational_cycle: Int,
                            index_code: Int,
                            index_value: Double
                          )

