package br.com.natura.helpers

import java.sql
import java.sql.Timestamp
import java.util.Date
import java.util.Calendar


import com.datastax.spark.connector.{ColumnName, SomeColumns}
import org.joda.time.DateTime
import org.joda.time.format.{DateTimeFormat, DateTimeFormatter}
import org.slf4j.{Logger, LoggerFactory}


import com.datastax.spark.connector.{ColumnName, SomeColumns}
import org.slf4j.LoggerFactory

import scala.tools.scalap.scalax.rules.scalasig.MethodSymbol

object Helpers {


  def getLogger(classType: Class[_ <: Any]): LoggerLocal = {
    val logger = LoggerFactory.getLogger(classType.getCanonicalName)
    new LoggerLocal(Option(logger))
  }

  def currentTimestamp(date: Date): Timestamp = {
    new Timestamp(date.getTime)
  }

  def currentDate(): Date = {
    Calendar.getInstance.getTime
  }

  def currentSQLDate(date: Date): sql.Date = {
    new sql.Date(date.getTime)
  }

  def getHourRange(timestamp: Timestamp): Int = {
    val calendar: Calendar = Calendar.getInstance
    calendar.setTime(timestamp)

    val hour: Int = calendar.get(Calendar.HOUR_OF_DAY)

    if(hour > 0 && hour < 6) {
      1
    }
    else if(hour >= 6 && hour < 12) {
      2
    }
    else if(hour >= 12 && hour < 18) {
      3
    }
    else {
      4
    }
  }
}
