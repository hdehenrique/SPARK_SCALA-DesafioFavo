package br.com.natura.settings

import com.typesafe.config.ConfigFactory
import org.joda.time.DateTimeZone
import br.com.natura.commercial.performance.commons.credentials.Credentials
import br.com.natura.commercial.performance.commons.enums.enumsCredentials

object Settings {
  private val config = ConfigFactory.load()
  private val weblogGen = config.getConfig("ApuracaoPrimeiroPedido")
  private val hadoopSettings = config.getConfig("hadoop_settings")
  private val cassandraSettings = config.getConfig("cassandra_conn")
  private val kafkaSettings = config.getConfig("kafka_settings")
  private val environmentSettings = config.getConfig("environment")

  private val kafkaAmbariSettings = config.getConfig("kafka_ambari_settings")
  private val postgresqlBRMSettings = config.getConfig("postgree_brm")
  lazy val kafka_bootstrap_servers: String = environmentSettings.getString("kafka_bootstrap_servers")
  
  val region =  environmentSettings.getString("region")  //região da secret manager
  val scyllaSecretName = environmentSettings.getString("scylla_secret_name") //nome da secret
  val brmSecretName = environmentSettings.getString("brm_secret_name") //nome da secret
  val cmmSecretName = environmentSettings.getString("cmm_secret_name") //nome da secret
  ////////////////////////////////////


  lazy val engine_id = 11
  lazy val appName: String = weblogGen.getString("appName")
  lazy val logLevel = weblogGen.getString("logLevel")
  lazy val winUtils: String = hadoopSettings.getString("winUtils")
  lazy val kafka_microbatch_duration: Int = weblogGen.getInt("microbatch_duration")
  lazy val read_uuid_table: Boolean = weblogGen.getBoolean("read_uuid_table")
  lazy val write_old_table: Boolean = weblogGen.getBoolean("write_old_table")
  lazy val minusDays: Int = weblogGen.getInt("minusDays")
  lazy val minusHour: Int = weblogGen.getInt("minusHour")
  lazy val kafka_topic_read: String = kafkaSettings.getString("kafka_calculate_channel_indicators")
  lazy val kafka_topic_send: String = kafkaSettings.getString("kafka_topic_first_order")
  lazy val kafka_spec_failed_messages = kafkaSettings.getString("kafka_topic_spec_failed_messages")

  val scylla_performance_credentials =  Credentials.getFromSecretManagger(enumsCredentials.dataBaseTypeScylla,scyllaSecretName,region)

  lazy val cassandraServerAddress: String = scylla_performance_credentials.host
  lazy val cassandraUser: String = scylla_performance_credentials.userName
  lazy val cassandraPass: String = scylla_performance_credentials.password
  lazy val cassandraInputConsistency: String = cassandraSettings.getString("input_consistency")
  lazy val cassandraOutputConsistency: String = cassandraSettings.getString("output_consistency")

  lazy val kafka_ambari_user: String = kafkaAmbariSettings.getString("user")
  lazy val kafka_ambari_pass: String = kafkaAmbariSettings.getString("pass")

  val postgresql_cmm_credentials = Credentials.getFromSecretManagger(enumsCredentials.dataBaseTypePostgresql,cmmSecretName,region)

  lazy val postgresql_cmm_url: String =   postgresql_cmm_credentials.conectionURL
  lazy val postgresql_cmm_user: String =   postgresql_cmm_credentials.userName
  lazy val postgresql_cmm_pass: String =   postgresql_cmm_credentials.password

  val postgresql_brm_credentials = Credentials.getFromSecretManagger(enumsCredentials.dataBaseTypePostgresql, brmSecretName, region)

  lazy val postgresql_brm_url: String = postgresql_brm_credentials.conectionURL
  lazy val postgresql_brm_user: String = postgresql_brm_credentials.userName
  lazy val postgresql_brm_pass: String = postgresql_brm_credentials.password
  lazy val max_total = postgresqlBRMSettings.getInt("max_total")
  lazy val max_idle = postgresqlBRMSettings.getInt("max_idle")

  //NOVOS
  private val sparkSettings = config.getConfig("spark_conn")
  lazy val cassandraReconnectionDelayMax: String = cassandraSettings.getString("reconnection_delay_ms_max")
  lazy val cassandraReconnectionDelayMin: String = cassandraSettings.getString("reconnection_delay_ms_min")
  lazy val cassandraRetryCount: String = cassandraSettings.getString("retry_count")
  lazy val sparkMaxFailures: String = sparkSettings.getString("maxFailures")
  lazy val maxRate = weblogGen.getString("maxRate")
  val zoneUTC: DateTimeZone = DateTimeZone.UTC


  val summitParameters = config.getConfig("summit_parameters")
  val summitEngine = summitParameters.getConfig("ApuracaoPrimeiroPedido")

  val spark_cassandra_read_timeout_ms = summitEngine.getString("spark_cassandra_read_timeout_ms")
  val spark_cassandra_connection_compression = summitEngine.getString("spark_cassandra_connection_compression")
  val connection_connections_per_executor_max = summitEngine.getString("connection_connections_per_executor_max")
  val spark_cassandra_concurrent_reads = summitEngine.getString("spark_cassandra_concurrent_reads")
  val spark_shuffle_service_enabled = summitEngine.getString("spark_shuffle_service_enabled")
  val spark_cassandra_input_split_size_in_mb = summitEngine.getString("spark_cassandra_input_split_size_in_mb")
  val spark_cassandra_input_fetch_size_in_rows = summitEngine.getString("spark_cassandra_input_fetch_size_in_rows")
  val spark_cassandra_output_batch_size_rows = summitEngine.getString("spark_cassandra_output_batch_size_rows")
  val spark_cassandra_output_concurrent_writes = summitEngine.getString("spark_cassandra_output_concurrent_writes")
  val spark_memory_fraction = summitEngine.getString("spark_memory_fraction")
  val spark_memory_storageFraction = summitEngine.getString("spark_memory_storageFraction")
  val spark_locality_wait = summitEngine.getString("spark_locality_wait")

}

