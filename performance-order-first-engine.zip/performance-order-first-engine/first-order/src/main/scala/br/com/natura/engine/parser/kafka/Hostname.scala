package br.com.natura.engine.parser.kafka

import java.util

import br.com.natura.enums.{KafkaHostCategory, KafkaHostPort}
import org.bson.Document

case class KafkaHosts(href: String, kafkaHost: KafkaHost)
case class KafkaHost(cluster_name: String, host_name: String)

object Hostname {

  def parser(json: String): Array[KafkaHost] = {
    val parsed: Document = Document.parse(json)
    val items = parsed.get("items").asInstanceOf[util.ArrayList[KafkaHost]]

    val hosts: Array[KafkaHost] = items.toArray.map(hostname => {
      val hn: Document = hostname.asInstanceOf[Document]
      val host: Document = hn.get("Hosts").asInstanceOf[Document]

      KafkaHost(host.getString("cluster_name"), host.getString("host_name"))
    })

    hosts
  }

  def categorized(json: String): Map[String, String] = {
    val hostnames: Array[KafkaHost] = this.parser(json)

    val head: Map[String, String] = this.hostnamesByCategory(hostnames, KafkaHostCategory.HEADNODE)
    val broker: Map[String, String] = this.hostnamesByCategory(hostnames, KafkaHostCategory.BROKER)
    val zookeeper: Map[String, String] = this.hostnamesByCategory(hostnames, KafkaHostCategory.ZOOKEEPER)

    head ++ broker ++ zookeeper
  }

  def hostnamesByCategory(hostnames: Array[KafkaHost], category: String): Map[String, String] = {
    val hns: Array[KafkaHost] = hostnames.filter(hn => hn.host_name.dropRight(hn.host_name.length - 2) == category)
    val hostPort: String = KafkaHostPort.getPort(category)

    Map(category -> hns.map(h => h.host_name + hostPort).mkString(","))
  }

}
