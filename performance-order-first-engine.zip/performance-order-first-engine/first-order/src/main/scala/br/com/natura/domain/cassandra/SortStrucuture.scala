package br.com.natura.domain.cassandra

case class SortStrucuture(structure_level: Int,
                          structure_code: Int)