package br.com.natura.handlers.database

import org.apache.spark.sql.{DataFrame, Dataset, SaveMode, SparkSession}

abstract class Database(ss: SparkSession) {
  val format: String

  def readTable(options: Map[String, String]): DataFrame = {
    ss.read.format(this.format).options(options).load()
  }

  def writeTable[T](dataset: Dataset[T], options: Map[String, String], saveMode: SaveMode = SaveMode.Append): Unit = {
    dataset.write.format(this.format).options(options).mode(saveMode).save()
  }
}
