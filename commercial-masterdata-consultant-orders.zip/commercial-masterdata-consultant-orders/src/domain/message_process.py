import json

def process_structure_tree(tree):
    return json.dumps(tree)

def message_processing(received_message):
    required_fields = [
        "uuid", "country_iso", "company_id", "business_model", "consultant_code",
        "order_cycle", "order_uuid", "structure_level", "structure_code",
        "channel_id", "order_status", "order_date_release", "order_date",
        "order_itens", "order_number", "order_points", "order_value",
        "person_status", "structure_tree", "system_source"
    ]
    # Valida se todos os campos obrigatórios estão presentes
    for field in required_fields:
        if field not in received_message:
            raise KeyError(f"Missing required field: {field}")

    file_send = {}
    file_send["uuid"] = received_message["uuid"]
    file_send["country"] = received_message["country_iso"] 
    file_send["company_id"] = int(received_message["company_id"])
    file_send["business_model"] = int(received_message["business_model"])
    file_send["consultant_code"] = int(received_message["consultant_code"])
    file_send["order_cycle"] = int(received_message["order_cycle"])
    file_send["order_id"] = received_message["order_uuid"]
    file_send["structure_level"] = int(received_message["structure_level"])
    file_send["structure_code"] = int(received_message["structure_code"])
    file_send["channel_id"] = int(received_message["channel_id"])
    file_send["order_status"] = int(received_message["order_status"])
    file_send["order_calculation_date"] = received_message["order_date_release"]
    file_send["order_cycle_original"] = int(received_message["order_cycle"])
    file_send["order_date"] = received_message["order_date"]
    file_send["order_itens"] = int(received_message["order_itens"])
    file_send["order_number"] = received_message["order_number"]
    file_send["order_points"] = int(received_message["order_points"])
    file_send["order_value"] = float(received_message["order_value"])
    file_send["person_status"] = int(received_message["person_status"])
    file_send["structure_tree"] = process_structure_tree(received_message["structure_tree"])
    file_send["system_source"] = int(received_message["system_source"])

    return json.dumps(file_send)