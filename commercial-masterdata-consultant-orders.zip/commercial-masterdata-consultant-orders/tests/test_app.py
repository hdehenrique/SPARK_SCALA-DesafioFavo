import unittest
from unittest.mock import patch, MagicMock, AsyncMock
import base64
from os import getenv
from app import handler, topic_send, topic_send_fail
import asyncio


class TestApp(unittest.TestCase):

    @patch("app.KafkaProducer")
    @patch("app.getenv")
    def test_kafka_producer_connection_success(self, mock_getenv, mock_kafka_producer):
        # Mock da variável de ambiente
        mock_getenv.side_effect = lambda key: "localhost:9092" if key == "msk_servers" else None

        # Mock do KafkaProducer
        mock_kafka_producer.return_value = MagicMock()

        # Testa se o KafkaProducer é inicializado corretamente dentro do handler
        try:
            handler({"records": {}}, None)
        except Exception:
            self.fail("KafkaProducer initialization failed unexpectedly!")

    @patch("app.KafkaProducer")
    def test_kafka_producer_connection_failure(self, mock_kafka_producer):
        # Testa falha na conexão com o Kafka
        mock_kafka_producer.side_effect = Exception("Connection failed")
        with self.assertRaises(Exception):
            KafkaProducer(bootstrap_servers=["localhost:9092"])

    @patch("app.KafkaProducer")
    @patch("app.process_messages", new_callable=AsyncMock)
    def test_handler_success(self, mock_process_messages, mock_kafka_producer):
        # Mock do KafkaProducer
        mock_producer_instance = MagicMock()
        mock_kafka_producer.return_value = mock_producer_instance

        # Evento com múltiplas partições
        event = {
            "records": {
                "partition1": [
                    {"value": base64.b64encode(b'{"uuid": "123", "order_id": "456", "country_iso": "BR"}').decode("utf-8")}
                ],
                "partition2": [
                    {"value": base64.b64encode(b'{"uuid": "789", "order_id": "101", "country_iso": "US"}').decode("utf-8")}
                ]
            }
        }

        # Chama o handler usando asyncio.run
        asyncio.run(handler(event, None))

        # Verifica se process_messages foi chamado para cada mensagem
        self.assertEqual(mock_process_messages.call_count, 2)

        # Verifica os argumentos passados para cada chamada
        mock_process_messages.assert_any_call(
            {"uuid": "123", "order_id": "456", "country_iso": "BR"},
            mock_producer_instance,
            "commercial-masterdata-consultant-orders",
            "spec-failed-messages",
            "commercial-masterdata-consultant-orders",  # Valor fixo de lambda_name
        )
        mock_process_messages.assert_any_call(
            {"uuid": "789", "order_id": "101", "country_iso": "US"},
            mock_producer_instance,
            "commercial-masterdata-consultant-orders",
            "spec-failed-messages",
            "commercial-masterdata-consultant-orders",  # Valor fixo de lambda_name
        )

    @patch("app.KafkaProducer")
    @patch("src.application.masterdata_consultant_orders.message_processing")
    def test_handler_multiple_partitions(self, mock_message_processing, mock_kafka_producer):
        # Mock do KafkaProducer
        mock_producer_instance = MagicMock()
        mock_kafka_producer.return_value = mock_producer_instance

        # Mock do processamento de mensagens
        mock_message_processing.return_value = '{"processed": "message"}'

        # Evento com múltiplas partições
        event = {
            "records": {
                "partition1": [
                    {"value": base64.b64encode(b'{"uuid": "123", "order_id": "456", "country_iso": "BR"}').decode("utf-8")}
                ],
                "partition2": [
                    {"value": base64.b64encode(b'{"uuid": "789", "order_id": "101", "country_iso": "US"}').decode("utf-8")}
                ]
            }
        }

        # Chama o handler
        handler(event, None)

        # Verifica se o processamento foi chamado para cada mensagem
        self.assertEqual(mock_message_processing.call_count, 2)

        # Verifica os argumentos passados para cada chamada
        mock_message_processing.assert_any_call(
            {"uuid": "123", "order_id": "456", "country_iso": "BR"},
            mock_producer_instance,
            "commercial-masterdata-consultant-orders",
            "spec-failed-messages",
            getenv("lambda_name")
        )
        mock_message_processing.assert_any_call(
            {"uuid": "789", "order_id": "101", "country_iso": "US"},
            mock_producer_instance,
            "commercial-masterdata-consultant-orders",
            "spec-failed-messages",
            getenv("lambda_name")
        )

    @patch("app.KafkaProducer")
    def test_handler_kafka_connection_failure(self, mock_kafka_producer):
        # Simula uma falha na conexão com o Kafka
        mock_kafka_producer.side_effect = Exception("Connection failed")

        # Evento vazio
        event = {"records": {}}

        # Verifica se a exceção é levantada
        with self.assertRaises(Exception) as context:
            asyncio.run(handler(event, None))  # Certifique-se de usar asyncio.run para chamar o handler

        # Verifica se a mensagem da exceção está correta
        self.assertEqual(str(context.exception), "Connection failed")

    @patch("app.KafkaProducer")
    @patch("src.application.masterdata_consultant_orders.message_processing")
    def test_handler_invalid_message(self, mock_message_processing, mock_kafka_producer):
        mock_producer_instance = MagicMock()
        mock_kafka_producer.return_value = mock_producer_instance

        mock_message_processing.side_effect = KeyError("Missing required field: uuid")

        event = {
            "records": {
                "partition1": [
                    {"value": base64.b64encode(b'{"order_id": "123"}').decode("utf-8")}
                ]
            }
        }

        handler(event, None)

        mock_producer_instance.send.assert_called_once_with(
            topic_send_fail,
            b'{"lambda": null, "eventProcessorError": {"message": "Missing required field: uuid"}, "payloadEvent": {"order_id": "123"}}'
        )

    @patch("app.KafkaProducer")
    @patch("src.application.masterdata_consultant_orders.message_processing")
    def test_handler_kafka_send_failure(self, mock_message_processing, mock_kafka_producer):
        # Mock do KafkaProducer
        mock_producer_instance = MagicMock()
        mock_producer_instance.send.side_effect = Exception("Kafka send failed")
        mock_kafka_producer.return_value = mock_producer_instance

        # Mock do processamento de mensagens
        mock_message_processing.return_value = '{"processed": "message"}'

        # Evento com uma mensagem
        event = {
            "records": {
                "partition1": [
                    {"value": base64.b64encode(b'{"order_id": "123", "uuid": "abc"}').decode("utf-8")}
                ]
            }
        }

        # Verifica se a exceção é levantada
        with self.assertRaises(Exception) as context:
            asyncio.run(handler(event, None))

        # Verifica se a mensagem da exceção está correta
        self.assertEqual(str(context.exception), "Kafka send failed")

    @patch("app.set_log_context")
    @patch("app.process_messages")
    @patch("app.KafkaProducer")
    def test_handler_calls_set_log_context(self, mock_kafka_producer, mock_process_messages, mock_set_log_context):
        # Mock do KafkaProducer
        mock_producer_instance = MagicMock()
        mock_kafka_producer.return_value = mock_producer_instance

        # Evento de teste
        event = {"records": {}}

        # Chama o handler
        handler(event, None)

        # Verifica se set_log_context foi chamado
        mock_set_log_context.assert_called_once()
        args, kwargs = mock_set_log_context.call_args
        self.assertIn("correlation_id", kwargs)
        self.assertIn("event_source", kwargs)
        self.assertEqual(kwargs["event_source"], "LAMBDA")

    @patch("app.set_log_context")
    @patch("app.process_messages")
    @patch("app.KafkaProducer")
    def test_handler_calls_set_log_context(self, mock_kafka_producer, mock_process_messages, mock_set_log_context):
        # Mock do KafkaProducer
        mock_producer_instance = MagicMock()
        mock_kafka_producer.return_value = mock_producer_instance

        # Evento de teste
        event = {"records": {}}

        # Chama o handler
        handler(event, None)

        # Verifica se set_log_context foi chamado
        mock_set_log_context.assert_called_once_with(event_source="LAMBDA")

    @patch("app.set_log_context")
    @patch("app.process_messages")
    @patch("app.KafkaProducer")
    def test_handler_calls_set_log_context(self, mock_kafka_producer, mock_process_messages, mock_set_log_context):
        # Mock do KafkaProducer
        mock_producer_instance = MagicMock()
        mock_kafka_producer.return_value = mock_producer_instance

        # Evento de teste
        event = {"records": {}}

        # Chama o handler
        handler(event, None)

        # Verifica se set_log_context foi chamado
        mock_set_log_context.assert_called_once_with(event_source="MSK")


if __name__ == "__main__":
    unittest.main()