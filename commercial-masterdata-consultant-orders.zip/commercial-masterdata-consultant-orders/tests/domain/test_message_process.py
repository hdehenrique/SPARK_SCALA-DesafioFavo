import unittest
import json
from src.domain.message_process import message_processing, process_structure_tree
from unittest.mock import patch

class TestMessageProcess(unittest.TestCase):
    @patch('src.domain.message_process.message_processing')
    def test_message_processing_success(self, mock_message_processing):
        # Mensagem de entrada simulada
        received_message = {
            "uuid": "123e4567-e89b-12d3-a456-426614174000",
            "country_iso": "BR",
            "company_id": "1",
            "business_model": "2",
            "consultant_code": "393772195",
            "order_cycle": "202416",
            "order_uuid": "661b91ad-d715-4735-a0c2-ef3e4dc752a5",
            "structure_level": "5",
            "structure_code": "22005",
            "channel_id": "8",
            "order_status": "3",
            "order_date_release": "2024-10-28 21:49:55",
            "order_date": "2024-10-28 18:49:33",
            "order_itens": "8",
            "order_number": "745080279",
            "order_points": "46",
            "order_value": "409.52",
            "person_status": "2",
            "structure_tree": [{"structureLevel": 5, "structureCode": 22005}],
            "system_source": "1",
        }

        # Resultado esperado
        expected_output = {
            "uuid": "123e4567-e89b-12d3-a456-426614174000",
            "country": "BR",
            "company_id": 1,
            "business_model": 2,
            "consultant_code": 393772195,
            "order_cycle": 202416,
            "order_id": "661b91ad-d715-4735-a0c2-ef3e4dc752a5",
            "structure_level": 5,
            "structure_code": 22005,
            "channel_id": 8,
            "order_status": 3,
            "order_calculation_date": "2024-10-28 21:49:55",
            "order_cycle_original": 202416,
            "order_date": "2024-10-28 18:49:33",
            "order_itens": 8,
            "order_number": "745080279",
            "order_points": 46,
            "order_value": 409.52,
            "person_status": 2,
            "structure_tree": '[{"structureLevel": 5, "structureCode": 22005}]',
            "system_source": 1,
        }

        # Chama a função
        result = message_processing(received_message)

        # Verifica se o resultado é o esperado
        self.assertEqual(json.loads(result), expected_output)
        self.assertEqual(mock_message_processing.call_count, 2)
        mock_message_processing.assert_any_call({"uuid": "123", "order_id": "456", "country_iso": "BR"})
        mock_message_processing.assert_any_call({"uuid": "789", "order_id": "101", "country_iso": "US"})

    def test_message_processing_missing_field(self):
        # Mensagem de entrada com campo ausente
        received_message = {
            "uuid": "123e4567-e89b-12d3-a456-426614174000",
            # Campo "country_iso" ausente
            "company_id": "1",
            "business_model": "2",
            "consultant_code": "393772195",
            "order_cycle": "202416",
            "order_uuid": "661b91ad-d715-4735-a0c2-ef3e4dc752a5",
            "structure_level": "5",
            "structure_code": "22005",
            "channel_id": "8",
            "order_status": "3",
            "order_date_release": "2024-10-28 21:49:55",
            "order_date": "2024-10-28 18:49:33",
            "order_itens": "8",
            "order_number": "745080279",
            "order_points": "46",
            "order_value": "409.52",
            "person_status": "2",
            "structure_tree": [{"structureLevel": 5, "structureCode": 22005}],
            "system_source": "1",
        }

        # Verifica se ocorre um KeyError
        with self.assertRaises(KeyError):
            message_processing(received_message)

    def test_message_processing_invalid_data_type(self):
        # Mensagem de entrada com tipos de dados inválidos
        received_message = {
            "uuid": "123e4567-e89b-12d3-a456-426614174000",
            "country_iso": "BR",
            "company_id": "invalid",  # Tipo inválido
            "business_model": "2",
            "consultant_code": "393772195",
            "order_cycle": "202416",
            "order_uuid": "661b91ad-d715-4735-a0c2-ef3e4dc752a5",
            "structure_level": "5",
            "structure_code": "22005",
            "channel_id": "8",
            "order_status": "3",
            "order_date_release": "2024-10-28 21:49:55",
            "order_date": "2024-10-28 18:49:33",
            "order_itens": "8",
            "order_number": "745080279",
            "order_points": "46",
            "order_value": "409.52",
            "person_status": "2",
            "structure_tree": [{"structureLevel": 5, "structureCode": 22005}],
            "system_source": "1",
        }

        # Verifica se ocorre um ValueError ao tentar converter tipos inválidos
        with self.assertRaises(ValueError):
            message_processing(received_message)

    def test_process_structure_tree(self):
        # Testa a função process_structure_tree
        structure_tree = [{"structureLevel": 5, "structureCode": 22005}]
        expected_output = '[{"structureLevel": 5, "structureCode": 22005}]'

        # Chama a função
        result = process_structure_tree(structure_tree)

        # Verifica se o resultado é o esperado
        self.assertEqual(result, expected_output)

    def test_message_processing_empty_message(self):
        # Mensagem de entrada vazia
        received_message = {}

        # Verifica se ocorre um KeyError
        with self.assertRaises(KeyError):
            message_processing(received_message)

    def test_message_processing_with_extra_fields(self):
        # Mensagem com campos extras
        received_message = {
            "uuid": "123e4567-e89b-12d3-a456-426614174000",
            "country_iso": "BR",
            "company_id": "1",
            "business_model": "2",
            "consultant_code": "393772195",
            "order_cycle": "202416",
            "order_uuid": "661b91ad-d715-4735-a0c2-ef3e4dc752a5",
            "structure_level": "5",
            "structure_code": "22005",
            "channel_id": "8",
            "order_status": "3",
            "order_date_release": "2024-10-28 21:49:55",
            "order_date": "2024-10-28 18:49:33",
            "order_itens": "8",
            "order_number": "745080279",
            "order_points": "46",
            "order_value": "409.52",
            "person_status": "2",
            "structure_tree": [{"structureLevel": 5, "structureCode": 22005}],
            "system_source": "1",
            "extra_field": "extra_value",  # Campo extra
        }

        # Chama a função
        result = message_processing(received_message)

        # Verifica se o campo extra não está no resultado
        self.assertNotIn("extra_field", json.loads(result))

    def test_message_processing_with_empty_values(self):
        # Mensagem com valores vazios
        received_message = {
            "uuid": "",
            "country_iso": "",
            "company_id": "0",
            "business_model": "0",
            "consultant_code": "0",
            "order_cycle": "0",
            "order_uuid": "",
            "structure_level": "0",
            "structure_code": "0",
            "channel_id": "0",
            "order_status": "0",
            "order_date_release": "",
            "order_date": "",
            "order_itens": "0",
            "order_number": "",
            "order_points": "0",
            "order_value": "0.0",
            "person_status": "0",
            "structure_tree": [],
            "system_source": "0",
        }

        # Chama a função
        result = message_processing(received_message)

        # Verifica se os valores vazios foram processados corretamente
        processed_message = json.loads(result)
        self.assertEqual(processed_message["uuid"], "")
        self.assertEqual(processed_message["country"], "")
        self.assertEqual(processed_message["structure_tree"], "[]")

if __name__ == "__main__":
    unittest.main()