import unittest
from unittest.mock import AsyncMock, MagicMock, patch
import base64
import asyncio
from src.application.masterdata_consultant_orders import process_messages
from app import handler, topic_send

class TestMasterdataConsultantOrders(unittest.IsolatedAsyncioTestCase):
    @patch("src.application.masterdata_consultant_orders.message_processing")
    @patch("src.application.masterdata_consultant_orders.KafkaProducer")
    async def test_process_messages_success(self, mock_kafka_producer, mock_message_processing):
        # Mock do KafkaProducer
        mock_producer_instance = MagicMock()
        mock_kafka_producer.return_value = mock_producer_instance

        # Mock do processamento de mensagens
        mock_message_processing.return_value = '{"processed": "message"}'

        # Evento com múltiplas partições
        event = {
            "records": {
                "partition1": [
                    {"value": base64.b64encode(b'{"uuid": "123", "order_id": "456", "country_iso": "BR"}').decode("utf-8")}
                ],
                "partition2": [
                    {"value": base64.b64encode(b'{"uuid": "789", "order_id": "101", "country_iso": "US"}').decode("utf-8")}
                ]
            }
        }

        # Chama a função process_messages
        await process_messages(event, mock_producer_instance, "topic_send", "topic_send_fail", "lambda_name")

        # Verifica se o processamento foi chamado para cada mensagem
        self.assertEqual(mock_message_processing.call_count, 2)

        # Verifica os argumentos passados para cada chamada
        mock_message_processing.assert_any_call(
            {"uuid": "123", "order_id": "456", "country_iso": "BR"}
        )
        mock_message_processing.assert_any_call(
            {"uuid": "789", "order_id": "101", "country_iso": "US"}
        )

        # Verifica se as mensagens foram enviadas para o Kafka
        self.assertEqual(mock_producer_instance.send.call_count, 2)

    @patch("src.application.masterdata_consultant_orders.message_processing")
    @patch("src.application.masterdata_consultant_orders.KafkaProducer")
    async def test_process_messages_failure(self, mock_kafka_producer, mock_message_processing):
        # Mock do KafkaProducer
        mock_producer_instance = MagicMock()
        mock_kafka_producer.return_value = mock_producer_instance

        # Simula uma exceção ao processar a mensagem
        mock_message_processing.side_effect = Exception("Processing error")

        # Evento com uma mensagem
        event = {
            "records": {
                "partition1": [
                    {"value": base64.b64encode(b'{"uuid": "123", "order_id": "456", "country_iso": "BR"}').decode("utf-8")}
                ]
            }
        }

        # Chama a função process_messages
        await process_messages(event, mock_producer_instance, "topic_send", "topic_send_fail", "lambda_name")

        # Verifica se a mensagem de erro foi enviada para o tópico de falhas
        mock_producer_instance.send.assert_called_once_with(
            "topic_send_fail",
            b'{"lambda": "lambda_name", "eventProcessorError": {"message": "Processing error"}, "payloadEvent": {"uuid": "123", "order_id": "456", "country_iso": "BR"}}'
        )

    @patch("app.KafkaProducer")
    @patch("app.message_processing")
    async def test_handler_success(self, mock_message_processing, mock_kafka_producer):
        # Mock do KafkaProducer
        mock_producer_instance = MagicMock()
        mock_kafka_producer.return_value = mock_producer_instance

        # Mock do processamento de mensagens
        mock_message_processing.return_value = '{"processed": "message"}'

        # Evento de teste
        event = {
            "records": {
                "partition1": [
                    {
                        "value": base64.b64encode(
                            b'{"uuid": "123", "order_id": "456", "country_iso": "BR", "company_id": "789", "business_model": "B2C"}'
                        ).decode("utf-8")
                    }
                ]
            }
        }

        # Chama o handler
        await handler(event, None)

        # Verifica se o processamento foi chamado
        mock_message_processing.assert_called_once()

        # Verifica se o KafkaProducer enviou a mensagem
        mock_producer_instance.send.assert_called_once_with(
            topic_send, b'{"processed": "message"}'
        )

    @patch("src.application.masterdata_consultant_orders.message_processing")
    @patch("src.application.masterdata_consultant_orders.KafkaProducer")
    async def test_handler_success(self, mock_kafka_producer, mock_message_processing):
        # Mock do KafkaProducer
        mock_producer_instance = MagicMock()
        mock_kafka_producer.return_value = mock_producer_instance

        # Mock do processamento de mensagens
        mock_message_processing.return_value = '{"processed": "message"}'

        # Evento de teste
        event = {
            "records": {
                "partition1": [
                    {"value": base64.b64encode(b'{"uuid": "123", "order_id": "456", "country_iso": "BR"}').decode("utf-8")}
                ],
                "partition2": [
                    {"value": base64.b64encode(b'{"uuid": "789", "order_id": "101", "country_iso": "US"}').decode("utf-8")}
                ]
            }
        }

        # Chama a função process_messages
        await process_messages(event, mock_producer_instance, "topic_send", "topic_send_fail", "lambda_name")

        # Verifica se o processamento foi chamado
        mock_message_processing.assert_called_once()

        # Verifica se o KafkaProducer enviou a mensagem
        mock_producer_instance.send.assert_called_once_with(
            "topic_send", b'{"processed": "message"}'
        )

    @patch("app.KafkaProducer")
    @patch("app.message_processing")
    async def test_handler_multiple_partitions(self, mock_message_processing, mock_kafka_producer):
        # Mock do KafkaProducer
        mock_producer_instance = MagicMock()
        mock_kafka_producer.return_value = mock_producer_instance

        # Mock do processamento de mensagens
        mock_message_processing.return_value = '{"processed": "message"}'

        # Evento com múltiplas partições
        event = {
            "records": {
                "partition1": [
                    {"value": base64.b64encode(b'{"uuid": "123", "order_id": "456", "country_iso": "BR"}').decode("utf-8")}
                ],
                "partition2": [
                    {"value": base64.b64encode(b'{"uuid": "789", "order_id": "101", "country_iso": "US"}').decode("utf-8")}
                ]
            }
        }

        # Chama o handler
        await handler(event, None)

        # Verifica se o processamento foi chamado para cada mensagem
        self.assertEqual(mock_message_processing.call_count, 2)

        # Verifica se o KafkaProducer enviou as mensagens
        self.assertEqual(mock_producer_instance.send.call_count, 2)

def set_log_context(correlation_id, event_source):
    # Configura o contexto do log
    logging.LoggerAdapter(logging.getLogger(), {
        "correlationId": correlation_id,
        "eventSource": event_source
    })

if __name__ == "__main__":
    unittest.main()