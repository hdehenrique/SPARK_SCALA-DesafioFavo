# README

Lambda responsável pela replicação de pedidos processados pelo sistema **Performance** para a base de dados **Masterdata**, substituindo a solução anterior baseada no Talend.

O Job **TALEND.JOBS.UNIX.BR.TALEND.PERFORMANCE_MDPERPOSTPERFORMANCECONSULTANTORDERS** foi descontinuado e esta Lambda agora realiza as operações de replicação de pedidos. Ela é responsável por:
- Consultar, transformar e inserir dados processados pelo sistema Performance.
- Garantir a consistência e integridade das informações replicadas.
- Inserir os dados nas tabelas de destino no banco de dados **Masterdata**.

---

## Tabelas de Escrita

A Lambda realiza inserções nas seguintes tabelas do banco de dados **Masterdata**:

| Tabela                                   | Descrição                                                                 |
|------------------------------------------|---------------------------------------------------------------------------|
| `masterdata.performance_consultant_orders_id` | Armazena informações detalhadas sobre os pedidos de consultores.          |
| `masterdata.performance_orders_id`       | Armazena informações resumidas sobre os pedidos processados.              |

---

## Fluxo de Operação

1. **Recebimento de Mensagens**:
   - A Lambda é acionada por eventos que contêm mensagens codificadas em Base64.
   - As mensagens são decodificadas e processadas.

2. **Transformação de Dados**:
   - Os dados recebidos são transformados para o formato esperado pelas tabelas de destino.

3. **Inserção no Banco de Dados**:
   - Os dados transformados são inseridos nas tabelas `performance_consultant_orders_id` e `performance_orders_id` no banco **Masterdata**.

---

## Links Úteis

- [Documentação] https://natura.atlassian.net/wiki/spaces/GCP/pages/5583536161/masterdata-consultant-orders

---

## Configuração

### Variáveis de Ambiente

Certifique-se de configurar as seguintes variáveis de ambiente para o funcionamento correto da Lambda:

| Variável            | Descrição                                                                 |
|---------------------|---------------------------------------------------------------------------|
| `LAMBDA_ENV`        | Define o ambiente de execução (ex.: `dev`, `prod`).                      |
| `MSK_SERVERS`       | Lista de servidores Kafka para conexão.                                  |
| `LAMBDA_NAME`       | Nome da Lambda para identificação nos logs e mensagens de erro.          |

---

## Substituição da Solução Anterior

Esta Lambda substitui o Job Talend **TALEND.JOBS.UNIX.BR.TALEND.PERFORMANCE_MDPERPOSTPERFORMANCECONSULTANTORDERS**, que anteriormente era responsável pela replicação de pedidos processados pelo sistema Performance para o banco de dados Masterdata.

---

## Contribuição

Contribuições para melhorias no código ou documentação são bem-vindas. Certifique-se de seguir as diretrizes de contribuição do projeto.
