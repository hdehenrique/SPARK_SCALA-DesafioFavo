#!/usr/bin/env bash
set -ex

# Get root path
origin_dir=$(pwd)

# Remove old zip if exists
if [ -e "${origin_dir}"/function.zip ]; then
  rm -f "${origin_dir}"/function.zip
fi

# Move to function folder
cd function

# Create a zip in root path with all necessary files
zip -r "${origin_dir}"/function.zip .

# Back to the root folder
cd ..

# Remove function folder
rm -rf function