#!/usr/bin/env bash
echo "instalando dependências"

mkdir function

find . -name \*.pyc -delete

cp constants.py function/

cp requirements.txt function/

cp .coveragerc function/

cp app.py function/

cp -r src function/

cp -r tests function/

pip3 install --platform manylinux2014_aarch64 -r requirements.txt --implementation cp --python-version 3.9 --only-binary=:all: -U --target=function

echo "Dependências instaladas"


